using EdgeRetails.Application.Abstractions;
using EdgeRetails.Application.Common;
using EdgeRetails.Application.Features.Identity;
using EdgeRetails.Application.Features.Terminals;
using EdgeRetails.Domain.Finance;
using System.Globalization;

namespace EdgeRetails.Application.Features.Finance;

public sealed record SupplierPaymentResult(Guid PaymentId, string PaymentNumber, bool WasExisting);

public sealed record CreateSupplierPaymentCommand(
    Guid SupplierId,
    decimal Amount,
    SupplierPaymentPurpose Purpose,
    SupplierSettlementMethod Method,
    Guid ActorId,
    Guid ClientOperationId,
    string? ExternalReference = null,
    string? Note = null);

public sealed class CreateSupplierPaymentHandler
{
    private readonly ISupplierAccountRepository _accounts;
    private readonly IPartyRepository _parties;
    private readonly ICashRepository _cash;
    private readonly IOperationLock _operationLock;
    private readonly IResourceLock _resourceLock;
    private readonly IApplicationPermissionAuthorizer _authorization;
    private readonly IDocumentNumberService _numbers;
    private readonly IClock _clock;
    private readonly IBusinessAuditWriter _audit;
    private readonly ITransactionRunner _transactions;
    private readonly IUnitOfWork _unitOfWork;

    public CreateSupplierPaymentHandler(
        ISupplierAccountRepository accounts,
        IPartyRepository parties,
        ICashRepository cash,
        IOperationLock operationLock,
        IResourceLock resourceLock,
        IApplicationPermissionAuthorizer authorization,
        IDocumentNumberService numbers,
        IClock clock,
        IBusinessAuditWriter audit,
        ITransactionRunner transactions,
        IUnitOfWork unitOfWork,
        IOperationOutcomeLedger? outcomeLedger = null)
    {
        _accounts = accounts;
        _parties = parties;
        _cash = cash;
        _operationLock = operationLock;
        _resourceLock = resourceLock;
        _authorization = authorization;
        _numbers = numbers;
        _clock = clock;
        _audit = audit;
        _transactions = transactions;
        _unitOfWork = unitOfWork;
        _outcomeLedger = outcomeLedger;
    }

    private readonly IOperationOutcomeLedger? _outcomeLedger;

    public async Task<Result<SupplierPaymentResult>> HandleAsync(
        CreateSupplierPaymentCommand command,
        CancellationToken cancellationToken)
    {
        if (command.ClientOperationId == Guid.Empty || command.SupplierId == Guid.Empty || command.Amount <= 0 ||
            !Enum.IsDefined(command.Purpose) || !Enum.IsDefined(command.Method))
        {
            return Result<SupplierPaymentResult>.Failure(
                "supplier.payment_invalid",
                "Supplier, positive amount, valid purpose, valid method, and client operation id are required.");
        }

        var result = await _transactions.ExecuteAsync(async ct =>
        {
            var permission = command.Purpose == SupplierPaymentPurpose.Advance
                ? PermissionKeys.SupplierAdvanceCreate
                : PermissionKeys.SupplierPaymentCreate;

            var authorization = await _authorization.AuthorizeAsync(command.ActorId, permission, ct);
            if (!authorization.IsSuccess)
            {
                return Result<SupplierPaymentResult>.Failure(
                    authorization.Error!.Code,
                    authorization.Error.Message);
            }

            var domainProjection = new
            {
                command.SupplierId,
                Amount = decimal.Round(command.Amount, 2, MidpointRounding.AwayFromZero),
                Purpose = command.Purpose.ToString(),
                Method = command.Method.ToString(),
                ExternalReference = Normalize(command.ExternalReference),
                Note = Normalize(command.Note),
                command.ActorId
            };
            var versionedFingerprint = OperationPayloadFingerprint.ComputeVersionedFingerprint("SupplierPayment", domainProjection);
            var fingerprint = OperationPayloadFingerprint.ComputeSha256(
                "1",
                command.SupplierId.ToString("D"),
                command.Amount.ToString("0.00", CultureInfo.InvariantCulture),
                command.Purpose.ToString(),
                command.Method.ToString(),
                Normalize(command.ExternalReference),
                Normalize(command.Note),
                command.ActorId.ToString("D"));

            bool FingerprintMatches(string? fp) =>
                string.Equals(fp, versionedFingerprint, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(fp, fingerprint, StringComparison.OrdinalIgnoreCase);

            await _operationLock.AcquireAsync(command.ClientOperationId, ct);
            if (_outcomeLedger is not null)
            {
                var outcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, ct);
                if (outcome is not null)
                {
                    if (!string.Equals(outcome.OperationType, "SupplierPayment", StringComparison.OrdinalIgnoreCase))
                    {
                        return Result<SupplierPaymentResult>.Failure(
                            "idempotency.operation_type_mismatch",
                            $"Operation identity already belongs to another durable operation ({outcome.OperationType}).");
                    }

                    if (outcome.ActorId.HasValue && command.ActorId != Guid.Empty && outcome.ActorId.Value != command.ActorId)
                    {
                        return Result<SupplierPaymentResult>.Failure(
                            "idempotency.context_mismatch",
                            "Operation actor mismatch.");
                    }

                    if (!string.IsNullOrEmpty(outcome.PayloadFingerprint) &&
                        !FingerprintMatches(outcome.PayloadFingerprint))
                    {
                        return Result<SupplierPaymentResult>.Failure(
                            "idempotency.payload_mismatch",
                            "Operation was previously submitted with different supplier payment parameters.");
                    }
                }
            }
            var existing = await _accounts.GetPaymentByClientOperationIdAsync(command.ClientOperationId, ct);
            if (existing is not null)
            {
                if (existing.SupplierId != command.SupplierId ||
                    existing.Amount != command.Amount ||
                    existing.Purpose != command.Purpose ||
                    existing.Method != command.Method ||
                    existing.ActorId != command.ActorId ||
                    existing.ExternalReference != Normalize(command.ExternalReference) ||
                    existing.Note != Normalize(command.Note))
                {
                    return Result<SupplierPaymentResult>.Failure(
                        "idempotency.payload_mismatch",
                        "Operation was previously submitted with different supplier payment parameters.");
                }

                if (_outcomeLedger is not null)
                {
                    await _outcomeLedger.RecordSuccessAsync(
                        command.ClientOperationId,
                        "SupplierPayment",
                        existing.Id,
                        existing.PaymentNumber,
                        actorId: command.ActorId,
                        payloadFingerprint: versionedFingerprint,
                        cancellationToken: ct);
                }

                return Result<SupplierPaymentResult>.Success(
                    new(existing.Id, existing.PaymentNumber, true));
            }

            await _resourceLock.AcquireAsync("supplier-account", command.SupplierId, ct);
            var supplier = await _parties.GetSupplierForUpdateAsync(command.SupplierId, ct);
            if (supplier is null || !supplier.IsActive)
            {
                return Result<SupplierPaymentResult>.Failure(
                    "supplier.not_active",
                    "Supplier was not found or is inactive.");
            }

            var balance = await _accounts.GetCurrentBalanceAsync(command.SupplierId, ct);
            var outstanding = Math.Max(balance, 0m);

            if (command.Purpose == SupplierPaymentPurpose.Settlement && command.Amount > outstanding)
            {
                return Result<SupplierPaymentResult>.Failure(
                    "supplier.payment_exceeds_payable",
                    "Settlement cannot exceed the current outstanding payable.");
            }

            if (command.Purpose == SupplierPaymentPurpose.Advance && string.IsNullOrWhiteSpace(command.Note))
            {
                return Result<SupplierPaymentResult>.Failure(
                    "supplier.advance_reason_required",
                    "Supplier advance requires an explicit reason/note.");
            }

            var payment = new SupplierPayment
            {
                PaymentNumber = await _numbers.NextAsync("SP", ct),
                SupplierId = command.SupplierId,
                Amount = Money(command.Amount),
                Purpose = command.Purpose,
                Method = command.Method,
                ExternalReference = Normalize(command.ExternalReference),
                PaidAt = _clock.UtcNow,
                ActorId = command.ActorId,
                ClientOperationId = command.ClientOperationId,
                Note = Normalize(command.Note)
            };

            if (command.Method == SupplierSettlementMethod.CashDrawer)
            {
                var cashSession = await _cash.GetOpenSessionForUpdateAsync(ct);
                if (cashSession is null)
                {
                    return Result<SupplierPaymentResult>.Failure(
                        "cash.session_required",
                        "An open cash session is required for a cash-drawer supplier payment.");
                }

                payment.CashSessionId = cashSession.Id;
                _cash.AddMovement(new CashMovement
                {
                    CashSessionId = cashSession.Id,
                    MovementType = CashMovementType.SupplierPaymentCashOut,
                    Direction = CashMovementDirection.Out,
                    Amount = payment.Amount,
                    SourceType = "SUPPLIER_PAYMENT",
                    SourceId = payment.Id,
                    ActorId = command.ActorId,
                    OccurredAt = _clock.UtcNow,
                    Reason = payment.PaymentNumber
                });
            }

            _accounts.AddPayment(payment);
            await AddEntryAsync(
                SupplierAccountEntryType.SupplierPayment,
                SupplierAccountDirection.DecreasePayable,
                command.SupplierId,
                payment.Amount,
                "SupplierPayment",
                payment.Id,
                command.ActorId,
                command.ClientOperationId,
                command.Note,
                ct);

            _audit.Record(
                command.Purpose == SupplierPaymentPurpose.Advance
                    ? "SUPPLIER_ADVANCE_POSTED"
                    : "SUPPLIER_PAYMENT_POSTED",
                "SUPPLIER_PAYMENT",
                payment.Id,
                command.ActorId,
                command.ClientOperationId,
                $"{payment.PaymentNumber}; supplier={command.SupplierId:D}; amount={payment.Amount:0.00}; purpose={payment.Purpose}.");

            if (_outcomeLedger is not null)
            {
                await _outcomeLedger.RecordSuccessAsync(
                    command.ClientOperationId,
                    "SupplierPayment",
                    payment.Id,
                    payment.PaymentNumber,
                    actorId: command.ActorId,
                    payloadFingerprint: versionedFingerprint,
                    cancellationToken: ct);
            }

            await _unitOfWork.SaveChangesAsync(ct);
            return Result<SupplierPaymentResult>.Success(
                new(payment.Id, payment.PaymentNumber, false));
        }, cancellationToken);

        if (!result.IsSuccess && _outcomeLedger is not null && command.ClientOperationId != Guid.Empty)
        {
            await _outcomeLedger.RecordFailureAsync(
                command.ClientOperationId,
                "SupplierPayment",
                result.Error?.Code ?? "supplier.payment_failed",
                result.Error?.Message ?? "Supplier payment failed.",
                actorId: command.ActorId,
                cancellationToken: cancellationToken);
        }

        return result;
    }

    private async Task AddEntryAsync(
        SupplierAccountEntryType type,
        SupplierAccountDirection direction,
        Guid supplierId,
        decimal amount,
        string referenceType,
        Guid referenceId,
        Guid actorId,
        Guid? clientOperationId,
        string? note,
        CancellationToken ct)
    {
        var entry = new SupplierAccountEntry
        {
            EntryNumber = await _numbers.NextAsync("SAE", ct),
            SupplierId = supplierId,
            EntryType = type,
            Direction = direction,
            Amount = Money(amount),
            ReferenceType = referenceType,
            ReferenceId = referenceId,
            OccurredAt = _clock.UtcNow,
            ActorId = actorId,
            ClientOperationId = clientOperationId,
            Note = Normalize(note),
            CreatedAt = _clock.UtcNow
        };
        entry.ValidateDirection();
        _accounts.AddEntry(entry);
    }

    private static decimal Money(decimal value) =>
        decimal.Round(value, 2, MidpointRounding.AwayFromZero);

    private static string? Normalize(string? value)
    {
        var normalized = value?.Trim();
        return string.IsNullOrWhiteSpace(normalized) ? null : normalized;
    }
}

public sealed record ReverseSupplierPaymentCommand(
    Guid PaymentId,
    string Reason,
    Guid ActorId,
    Guid ClientOperationId);

public sealed class ReverseSupplierPaymentHandler
{
    private readonly ISupplierAccountRepository _accounts;
    private readonly ICashRepository _cash;
    private readonly IOperationLock _operationLock;
    private readonly IResourceLock _resourceLock;
    private readonly IApplicationPermissionAuthorizer _authorization;
    private readonly IDocumentNumberService _numbers;
    private readonly IClock _clock;
    private readonly IBusinessAuditWriter _audit;
    private readonly ITransactionRunner _transactions;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IOperationOutcomeLedger? _outcomeLedger;

    public ReverseSupplierPaymentHandler(
        ISupplierAccountRepository accounts,
        ICashRepository cash,
        IOperationLock operationLock,
        IResourceLock resourceLock,
        IApplicationPermissionAuthorizer authorization,
        IDocumentNumberService numbers,
        IClock clock,
        IBusinessAuditWriter audit,
        ITransactionRunner transactions,
        IUnitOfWork unitOfWork,
        IOperationOutcomeLedger? outcomeLedger = null)
    {
        _accounts = accounts;
        _cash = cash;
        _operationLock = operationLock;
        _resourceLock = resourceLock;
        _authorization = authorization;
        _numbers = numbers;
        _clock = clock;
        _audit = audit;
        _transactions = transactions;
        _unitOfWork = unitOfWork;
        _outcomeLedger = outcomeLedger;
    }

    public Task<Result> HandleAsync(ReverseSupplierPaymentCommand command, CancellationToken cancellationToken)
    {
        if (command.PaymentId == Guid.Empty || command.ClientOperationId == Guid.Empty || string.IsNullOrWhiteSpace(command.Reason))
        {
            return Task.FromResult(Result.Failure(
                "supplier.payment_reversal_invalid",
                "Payment, reason, and client operation id are required."));
        }

        return _transactions.ExecuteAsync(async ct =>
        {
            var authorization = await _authorization.AuthorizeAsync(
                command.ActorId,
                PermissionKeys.SupplierPaymentReverse,
                ct);
            if (!authorization.IsSuccess)
            {
                return Result.Failure(authorization.Error!.Code, authorization.Error.Message);
            }

            await _operationLock.AcquireAsync(command.ClientOperationId, ct);
            var domainProjection = new
            {
                command.PaymentId,
                Reason = command.Reason.Trim(),
                command.ActorId
            };
            var versionedFingerprint = OperationPayloadFingerprint.ComputeVersionedFingerprint("SupplierPaymentReversal", domainProjection);
            var fingerprint = OperationPayloadFingerprint.ComputeSha256(
                "1",
                command.PaymentId.ToString("D"),
                command.Reason.Trim(),
                command.ActorId.ToString("D"));

            bool FingerprintMatches(string? fp) =>
                string.Equals(fp, versionedFingerprint, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(fp, fingerprint, StringComparison.OrdinalIgnoreCase);

            if (_outcomeLedger is not null)
            {
                var outcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, ct);
                if (outcome is not null)
                {
                    if (!string.Equals(outcome.OperationType, "SupplierPaymentReversal", StringComparison.OrdinalIgnoreCase))
                    {
                        return Result.Failure(
                            "idempotency.operation_type_mismatch",
                            $"Operation identity already belongs to another durable operation ({outcome.OperationType}).");
                    }

                    if (outcome.ActorId.HasValue && command.ActorId != Guid.Empty && outcome.ActorId.Value != command.ActorId)
                    {
                        return Result.Failure(
                            "idempotency.context_mismatch",
                            "Operation actor mismatch.");
                    }

                    if (!string.IsNullOrEmpty(outcome.PayloadFingerprint) &&
                        !FingerprintMatches(outcome.PayloadFingerprint))
                    {
                        return Result.Failure(
                            "idempotency.payload_mismatch",
                            "Operation was previously submitted with different reversal parameters.");
                    }
                }
            }
            var payment = await _accounts.GetPaymentForUpdateAsync(command.PaymentId, ct);
            if (payment is null)
            {
                return Result.Failure("supplier.payment_not_found", "Supplier payment was not found.");
            }

            await _resourceLock.AcquireAsync("supplier-account", payment.SupplierId, ct);

            var existingReversal = await _accounts.GetPaymentReversalByPaymentAsync(payment.Id, ct);
            if (existingReversal is not null)
            {
                if (existingReversal.ClientOperationId != command.ClientOperationId)
                {
                    return Result.Failure("supplier.already_reversed", "Supplier payment was already reversed by another operation.");
                }

                if (existingReversal.Reason != command.Reason.Trim() || existingReversal.ReversedBy != command.ActorId)
                {
                    return Result.Failure("idempotency.payload_mismatch", "Operation was previously submitted with different reversal parameters.");
                }

                if (_outcomeLedger is not null)
                {
                    await _outcomeLedger.RecordSuccessAsync(
                        command.ClientOperationId,
                        "SupplierPaymentReversal",
                        existingReversal.Id,
                        payment.PaymentNumber,
                        actorId: command.ActorId,
                        payloadFingerprint: versionedFingerprint,
                        cancellationToken: ct);
                }

                return Result.Success();
            }

            var reversal = new SupplierPaymentReversal
            {
                SupplierPaymentId = payment.Id,
                Reason = command.Reason.Trim(),
                ReversedBy = command.ActorId,
                ReversedAt = _clock.UtcNow,
                ClientOperationId = command.ClientOperationId
            };

            payment.Status = SupplierSettlementStatus.Reversed;
            _accounts.AddPaymentReversal(reversal);

            var entry = new SupplierAccountEntry
            {
                EntryNumber = await _numbers.NextAsync("SAE", ct),
                SupplierId = payment.SupplierId,
                EntryType = SupplierAccountEntryType.SupplierPaymentReversal,
                Direction = SupplierAccountDirection.IncreasePayable,
                Amount = payment.Amount,
                ReferenceType = "SupplierPaymentReversal",
                ReferenceId = reversal.Id,
                OccurredAt = _clock.UtcNow,
                ActorId = command.ActorId,
                ClientOperationId = command.ClientOperationId,
                Note = command.Reason.Trim(),
                CreatedAt = _clock.UtcNow
            };
            entry.ValidateDirection();
            _accounts.AddEntry(entry);

            if (payment.Method == SupplierSettlementMethod.CashDrawer)
            {
                var session = await _cash.GetOpenSessionForUpdateAsync(ct);
                if (session is null)
                {
                    return Result.Failure(
                        "cash.session_required",
                        "An active open cash session is required for cash drawer reversal.");
                }

                _cash.AddMovement(new CashMovement
                {
                    CashSessionId = session.Id,
                    MovementType = CashMovementType.SupplierPaymentReversalCashIn,
                    Direction = CashMovementDirection.In,
                    Amount = payment.Amount,
                    SourceType = "SUPPLIER_PAYMENT_REVERSAL",
                    SourceId = reversal.Id,
                    ActorId = command.ActorId,
                    OccurredAt = _clock.UtcNow,
                    Reason = command.Reason.Trim()
                });
            }

            _audit.Record(
                "SUPPLIER_PAYMENT_REVERSED",
                "SUPPLIER_PAYMENT",
                payment.Id,
                command.ActorId,
                command.ClientOperationId,
                command.Reason.Trim());

            await _unitOfWork.SaveChangesAsync(ct);

            if (_outcomeLedger is not null)
            {
                await _outcomeLedger.RecordSuccessAsync(
                    command.ClientOperationId,
                    "SupplierPaymentReversal",
                    reversal.Id,
                    payment.PaymentNumber,
                    actorId: command.ActorId,
                    payloadFingerprint: versionedFingerprint,
                    cancellationToken: ct);
            }

            return Result.Success();
        }, cancellationToken);
    }
}

public sealed record SupplierRefundResult(Guid RefundId, string RefundNumber, bool WasExisting);

public sealed record CreateSupplierRefundCommand(
    Guid SupplierId,
    decimal Amount,
    SupplierSettlementMethod Method,
    Guid ActorId,
    Guid ClientOperationId,
    string? ExternalReference = null,
    string? ReferenceType = null,
    Guid? ReferenceId = null,
    string? Note = null);

public sealed class CreateSupplierRefundHandler
{
    private readonly ISupplierAccountRepository _accounts;
    private readonly IPartyRepository _parties;
    private readonly ICashRepository _cash;
    private readonly IOperationLock _operationLock;
    private readonly IResourceLock _resourceLock;
    private readonly IApplicationPermissionAuthorizer _authorization;
    private readonly IDocumentNumberService _numbers;
    private readonly IClock _clock;
    private readonly IBusinessAuditWriter _audit;
    private readonly ITransactionRunner _transactions;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IOperationOutcomeLedger? _outcomeLedger;

    public CreateSupplierRefundHandler(
        ISupplierAccountRepository accounts,
        IPartyRepository parties,
        ICashRepository cash,
        IOperationLock operationLock,
        IResourceLock resourceLock,
        IApplicationPermissionAuthorizer authorization,
        IDocumentNumberService numbers,
        IClock clock,
        IBusinessAuditWriter audit,
        ITransactionRunner transactions,
        IUnitOfWork unitOfWork,
        IOperationOutcomeLedger? outcomeLedger = null)
    {
        _accounts = accounts;
        _parties = parties;
        _cash = cash;
        _operationLock = operationLock;
        _resourceLock = resourceLock;
        _authorization = authorization;
        _numbers = numbers;
        _clock = clock;
        _audit = audit;
        _transactions = transactions;
        _unitOfWork = unitOfWork;
        _outcomeLedger = outcomeLedger;
    }

    public Task<Result<SupplierRefundResult>> HandleAsync(
        CreateSupplierRefundCommand command,
        CancellationToken cancellationToken)
    {
        return _transactions.ExecuteAsync(async ct =>
        {
            var result = await PostInTransactionAsync(command, null, ct);
            if (result.IsSuccess && !result.Value!.WasExisting)
            {
                await _unitOfWork.SaveChangesAsync(ct);
            }
            return result;
        }, cancellationToken);
    }

    // The caller owns the transaction/save. Only PurchaseReturn supplies an
    // authoritative balance adjusted for its still-pending goods-return credit.
    internal async Task<Result<SupplierRefundResult>> PostInTransactionAsync(
        CreateSupplierRefundCommand command,
        decimal? authoritativeBalance,
        CancellationToken ct)
    {
        var amount = decimal.Round(command.Amount, 2, MidpointRounding.AwayFromZero);
        if (command.SupplierId == Guid.Empty || command.ClientOperationId == Guid.Empty ||
            amount <= 0 || !Enum.IsDefined(command.Method))
        {
            return Result<SupplierRefundResult>.Failure(
                "supplier.refund_invalid",
                "Supplier, positive monetary amount, valid method, and client operation id are required.");
        }
        var authorization = await _authorization.AuthorizeAsync(
            command.ActorId,
            PermissionKeys.SupplierRefundCreate,
            ct);
        if (!authorization.IsSuccess)
        {
            return Result<SupplierRefundResult>.Failure(
                authorization.Error!.Code,
                authorization.Error.Message);
        }

        var domainProjection = new
        {
            command.SupplierId,
            Amount = amount,
            Method = command.Method.ToString(),
            ExternalReference = Normalize(command.ExternalReference),
            ReferenceType = Normalize(command.ReferenceType),
            command.ReferenceId,
            Note = Normalize(command.Note),
            command.ActorId
        };
        var versionedFingerprint = OperationPayloadFingerprint.ComputeVersionedFingerprint("SupplierRefund", domainProjection);
        var fingerprint = OperationPayloadFingerprint.ComputeSha256(
            "1",
            command.SupplierId.ToString("D"),
            amount.ToString("0.00", CultureInfo.InvariantCulture),
            command.Method.ToString(),
            Normalize(command.ExternalReference),
            Normalize(command.ReferenceType),
            command.ReferenceId?.ToString("D"),
            Normalize(command.Note),
            command.ActorId.ToString("D"));

        bool FingerprintMatches(string? fp) =>
            string.Equals(fp, versionedFingerprint, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(fp, fingerprint, StringComparison.OrdinalIgnoreCase);

        await _operationLock.AcquireAsync(command.ClientOperationId, ct);
        if (_outcomeLedger is not null && authoritativeBalance is null)
        {
            var outcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, ct);
            if (outcome is not null)
            {
                if (!string.Equals(outcome.OperationType, "SupplierRefund", StringComparison.OrdinalIgnoreCase))
                {
                    return Result<SupplierRefundResult>.Failure(
                        "idempotency.operation_type_mismatch",
                        $"Operation identity already belongs to another durable operation ({outcome.OperationType}).");
                }

                if (outcome.ActorId.HasValue && command.ActorId != Guid.Empty && outcome.ActorId.Value != command.ActorId)
                {
                    return Result<SupplierRefundResult>.Failure(
                        "idempotency.context_mismatch",
                        "Operation actor mismatch.");
                }

                if (!string.IsNullOrEmpty(outcome.PayloadFingerprint) &&
                    !FingerprintMatches(outcome.PayloadFingerprint))
                {
                    return Result<SupplierRefundResult>.Failure(
                        "idempotency.payload_mismatch",
                        "Operation was previously submitted with different supplier refund parameters.");
                }
            }
        }
        var existing = await _accounts.GetRefundByClientOperationIdAsync(command.ClientOperationId, ct);
        if (existing is not null)
        {
            if (existing.SupplierId != command.SupplierId || existing.Amount != amount ||
                existing.Method != command.Method || existing.ActorId != command.ActorId ||
                existing.ReferenceType != Normalize(command.ReferenceType) || existing.ReferenceId != command.ReferenceId ||
                existing.ExternalReference != Normalize(command.ExternalReference) || existing.Note != Normalize(command.Note))
            {
                return Result<SupplierRefundResult>.Failure(
                    "idempotency.payload_mismatch", "The refund operation was previously posted with different parameters.");
            }

            if (_outcomeLedger is not null && authoritativeBalance is null)
            {
                await _outcomeLedger.RecordSuccessAsync(
                    command.ClientOperationId,
                    "SupplierRefund",
                    existing.Id,
                    existing.RefundNumber,
                    actorId: command.ActorId,
                    payloadFingerprint: versionedFingerprint,
                    cancellationToken: ct);
            }

            return Result<SupplierRefundResult>.Success(
                new(existing.Id, existing.RefundNumber, true));
        }

        await _resourceLock.AcquireAsync("supplier-account", command.SupplierId, ct);
        var supplier = await _parties.GetSupplierForUpdateAsync(command.SupplierId, ct);
        if (supplier is null)
        {
            return Result<SupplierRefundResult>.Failure(
                "supplier.not_found",
                "Supplier was not found.");
        }

        var balance = authoritativeBalance ?? await _accounts.GetCurrentBalanceAsync(command.SupplierId, ct);
        var credit = Math.Max(-balance, 0m);
        if (amount > credit)
        {
            return Result<SupplierRefundResult>.Failure(
                "supplier.refund_exceeds_credit",
                "Supplier refund cannot exceed the current supplier credit/advance.");
        }

        var refund = new SupplierRefund
        {
            RefundNumber = await _numbers.NextAsync("SR", ct),
            SupplierId = command.SupplierId,
            Amount = amount,
            Method = command.Method,
            ExternalReference = Normalize(command.ExternalReference),
            ReferenceType = Normalize(command.ReferenceType),
            ReferenceId = command.ReferenceId,
            ReceivedAt = _clock.UtcNow,
            ActorId = command.ActorId,
            ClientOperationId = command.ClientOperationId,
            Note = Normalize(command.Note)
        };

        if (command.Method == SupplierSettlementMethod.CashDrawer)
        {
            var cashSession = await _cash.GetOpenSessionForUpdateAsync(ct);
            if (cashSession is null)
            {
                return Result<SupplierRefundResult>.Failure(
                    "cash.session_required",
                    "An open cash session is required for a cash-drawer supplier refund.");
            }

            refund.CashSessionId = cashSession.Id;
            _cash.AddMovement(new CashMovement
            {
                CashSessionId = cashSession.Id,
                MovementType = CashMovementType.SupplierRefundCashIn,
                Direction = CashMovementDirection.In,
                Amount = refund.Amount,
                SourceType = "SUPPLIER_REFUND",
                SourceId = refund.Id,
                ActorId = command.ActorId,
                OccurredAt = _clock.UtcNow,
                Reason = refund.RefundNumber
            });
        }

        _accounts.AddRefund(refund);
        var entry = new SupplierAccountEntry
        {
            EntryNumber = await _numbers.NextAsync("SAE", ct),
            SupplierId = refund.SupplierId,
            EntryType = SupplierAccountEntryType.SupplierRefundReceived,
            Direction = SupplierAccountDirection.IncreasePayable,
            Amount = refund.Amount,
            ReferenceType = "SupplierRefund",
            ReferenceId = refund.Id,
            OccurredAt = _clock.UtcNow,
            ActorId = command.ActorId,
            ClientOperationId = command.ClientOperationId,
            Note = refund.Note,
            CreatedAt = _clock.UtcNow
        };
        entry.ValidateDirection();
        _accounts.AddEntry(entry);

        _audit.Record(
            "SUPPLIER_REFUND_POSTED",
            "SUPPLIER_REFUND",
            refund.Id,
            command.ActorId,
            command.ClientOperationId,
            $"{refund.RefundNumber}; supplier={command.SupplierId:D}; amount={refund.Amount:0.00}.");

        if (_outcomeLedger is not null && authoritativeBalance is null)
        {
            await _outcomeLedger.RecordSuccessAsync(
                command.ClientOperationId,
                "SupplierRefund",
                refund.Id,
                refund.RefundNumber,
                actorId: command.ActorId,
                payloadFingerprint: versionedFingerprint,
                cancellationToken: ct);
        }

        return Result<SupplierRefundResult>.Success(
            new(refund.Id, refund.RefundNumber, false));
    }

    private static string? Normalize(string? value)
    {
        var normalized = value?.Trim();
        return string.IsNullOrWhiteSpace(normalized) ? null : normalized;
    }
}

public sealed record ReverseSupplierRefundCommand(
    Guid RefundId,
    string Reason,
    Guid ActorId,
    Guid ClientOperationId);

public sealed class ReverseSupplierRefundHandler
{
    private readonly ISupplierAccountRepository _accounts;
    private readonly ICashRepository _cash;
    private readonly IOperationLock _operationLock;
    private readonly IResourceLock _resourceLock;
    private readonly IApplicationPermissionAuthorizer _authorization;
    private readonly IDocumentNumberService _numbers;
    private readonly IClock _clock;
    private readonly IBusinessAuditWriter _audit;
    private readonly ITransactionRunner _transactions;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IOperationOutcomeLedger? _outcomeLedger;

    public ReverseSupplierRefundHandler(
        ISupplierAccountRepository accounts,
        ICashRepository cash,
        IOperationLock operationLock,
        IResourceLock resourceLock,
        IApplicationPermissionAuthorizer authorization,
        IDocumentNumberService numbers,
        IClock clock,
        IBusinessAuditWriter audit,
        ITransactionRunner transactions,
        IUnitOfWork unitOfWork,
        IOperationOutcomeLedger? outcomeLedger = null)
    {
        _accounts = accounts;
        _cash = cash;
        _operationLock = operationLock;
        _resourceLock = resourceLock;
        _authorization = authorization;
        _numbers = numbers;
        _clock = clock;
        _audit = audit;
        _transactions = transactions;
        _unitOfWork = unitOfWork;
        _outcomeLedger = outcomeLedger;
    }

    public Task<Result> HandleAsync(ReverseSupplierRefundCommand command, CancellationToken cancellationToken)
    {
        if (command.RefundId == Guid.Empty || command.ClientOperationId == Guid.Empty || string.IsNullOrWhiteSpace(command.Reason))
        {
            return Task.FromResult(Result.Failure(
                "supplier.refund_reversal_invalid",
                "Refund, reason, and client operation id are required."));
        }

        return _transactions.ExecuteAsync(async ct =>
        {
            var authorization = await _authorization.AuthorizeAsync(
                command.ActorId,
                PermissionKeys.SupplierRefundReverse,
                ct);
            if (!authorization.IsSuccess)
            {
                return Result.Failure(authorization.Error!.Code, authorization.Error.Message);
            }

            await _operationLock.AcquireAsync(command.ClientOperationId, ct);
            var domainProjection = new
            {
                command.RefundId,
                Reason = command.Reason.Trim(),
                command.ActorId
            };
            var versionedFingerprint = OperationPayloadFingerprint.ComputeVersionedFingerprint("SupplierRefundReversal", domainProjection);
            var fingerprint = OperationPayloadFingerprint.ComputeSha256(
                "1",
                command.RefundId.ToString("D"),
                command.Reason.Trim(),
                command.ActorId.ToString("D"));

            bool FingerprintMatches(string? fp) =>
                string.Equals(fp, versionedFingerprint, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(fp, fingerprint, StringComparison.OrdinalIgnoreCase);

            if (_outcomeLedger is not null)
            {
                var outcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, ct);
                if (outcome is not null)
                {
                    if (!string.Equals(outcome.OperationType, "SupplierRefundReversal", StringComparison.OrdinalIgnoreCase))
                    {
                        return Result.Failure(
                            "idempotency.operation_type_mismatch",
                            $"Operation identity already belongs to another durable operation ({outcome.OperationType}).");
                    }

                    if (outcome.ActorId.HasValue && command.ActorId != Guid.Empty && outcome.ActorId.Value != command.ActorId)
                    {
                        return Result.Failure(
                            "idempotency.context_mismatch",
                            "Operation actor mismatch.");
                    }

                    if (!string.IsNullOrEmpty(outcome.PayloadFingerprint) &&
                        !FingerprintMatches(outcome.PayloadFingerprint))
                    {
                        return Result.Failure(
                            "idempotency.payload_mismatch",
                            "Operation was previously submitted with different reversal parameters.");
                    }
                }
            }
            var refund = await _accounts.GetRefundForUpdateAsync(command.RefundId, ct);
            if (refund is null)
            {
                return Result.Failure("supplier.refund_not_found", "Supplier refund was not found.");
            }

            await _resourceLock.AcquireAsync("supplier-account", refund.SupplierId, ct);

            var existingReversal = await _accounts.GetRefundReversalByRefundAsync(refund.Id, ct);
            if (existingReversal is not null)
            {
                if (existingReversal.ClientOperationId != command.ClientOperationId)
                {
                    return Result.Failure("supplier.already_reversed", "Supplier refund was already reversed by another operation.");
                }

                if (existingReversal.Reason != command.Reason.Trim() || existingReversal.ReversedBy != command.ActorId)
                {
                    return Result.Failure("idempotency.payload_mismatch", "Operation was previously submitted with different reversal parameters.");
                }

                if (_outcomeLedger is not null)
                {
                    await _outcomeLedger.RecordSuccessAsync(
                        command.ClientOperationId,
                        "SupplierRefundReversal",
                        existingReversal.Id,
                        refund.RefundNumber,
                        actorId: command.ActorId,
                        payloadFingerprint: versionedFingerprint,
                        cancellationToken: ct);
                }

                return Result.Success();
            }

            var reversal = new SupplierRefundReversal
            {
                SupplierRefundId = refund.Id,
                Reason = command.Reason.Trim(),
                ReversedBy = command.ActorId,
                ReversedAt = _clock.UtcNow,
                ClientOperationId = command.ClientOperationId
            };
            refund.Status = SupplierSettlementStatus.Reversed;
            _accounts.AddRefundReversal(reversal);

            var entry = new SupplierAccountEntry
            {
                EntryNumber = await _numbers.NextAsync("SAE", ct),
                SupplierId = refund.SupplierId,
                EntryType = SupplierAccountEntryType.SupplierRefundReversal,
                Direction = SupplierAccountDirection.DecreasePayable,
                Amount = refund.Amount,
                ReferenceType = "SupplierRefundReversal",
                ReferenceId = reversal.Id,
                OccurredAt = _clock.UtcNow,
                ActorId = command.ActorId,
                ClientOperationId = command.ClientOperationId,
                Note = command.Reason.Trim(),
                CreatedAt = _clock.UtcNow
            };
            entry.ValidateDirection();
            _accounts.AddEntry(entry);

            if (refund.Method == SupplierSettlementMethod.CashDrawer)
            {
                var session = await _cash.GetOpenSessionForUpdateAsync(ct);
                if (session is null)
                {
                    return Result.Failure(
                        "cash.session_required",
                        "An active open cash session is required for cash drawer reversal.");
                }

                _cash.AddMovement(new CashMovement
                {
                    CashSessionId = session.Id,
                    MovementType = CashMovementType.SupplierRefundReversalCashOut,
                    Direction = CashMovementDirection.Out,
                    Amount = refund.Amount,
                    SourceType = "SUPPLIER_REFUND_REVERSAL",
                    SourceId = reversal.Id,
                    ActorId = command.ActorId,
                    OccurredAt = _clock.UtcNow,
                    Reason = command.Reason.Trim()
                });
            }

            _audit.Record(
                "SUPPLIER_REFUND_REVERSED",
                "SUPPLIER_REFUND",
                refund.Id,
                command.ActorId,
                command.ClientOperationId,
                command.Reason.Trim());

            await _unitOfWork.SaveChangesAsync(ct);

            if (_outcomeLedger is not null)
            {
                await _outcomeLedger.RecordSuccessAsync(
                    command.ClientOperationId,
                    "SupplierRefundReversal",
                    reversal.Id,
                    refund.RefundNumber,
                    actorId: command.ActorId,
                    payloadFingerprint: versionedFingerprint,
                    cancellationToken: ct);
            }

            return Result.Success();
        }, cancellationToken);
    }
}

public sealed record SupplierAccountAdjustmentCommand(
    Guid SupplierId,
    decimal Amount,
    SupplierAccountDirection Direction,
    string Reason,
    Guid ActorId,
    Guid ClientOperationId);

public sealed class SupplierAccountAdjustmentHandler
{
    private readonly ISupplierAccountRepository _accounts;
    private readonly IOperationLock _operationLock;
    private readonly IResourceLock _resourceLock;
    private readonly IApplicationPermissionAuthorizer _authorization;
    private readonly IDocumentNumberService _numbers;
    private readonly IClock _clock;
    private readonly IBusinessAuditWriter _audit;
    private readonly ITransactionRunner _transactions;
    private readonly IUnitOfWork _unitOfWork;

    public SupplierAccountAdjustmentHandler(
        ISupplierAccountRepository accounts,
        IOperationLock operationLock,
        IResourceLock resourceLock,
        IApplicationPermissionAuthorizer authorization,
        IDocumentNumberService numbers,
        IClock clock,
        IBusinessAuditWriter audit,
        ITransactionRunner transactions,
        IUnitOfWork unitOfWork)
    {
        _accounts = accounts;
        _operationLock = operationLock;
        _resourceLock = resourceLock;
        _authorization = authorization;
        _numbers = numbers;
        _clock = clock;
        _audit = audit;
        _transactions = transactions;
        _unitOfWork = unitOfWork;
    }

    public Task<Result> HandleAsync(SupplierAccountAdjustmentCommand command, CancellationToken cancellationToken)
    {
        if (command.SupplierId == Guid.Empty || command.ClientOperationId == Guid.Empty ||
            command.Amount <= 0 || string.IsNullOrWhiteSpace(command.Reason) ||
            !Enum.IsDefined(command.Direction))
        {
            return Task.FromResult(Result.Failure(
                "supplier.adjustment_invalid",
                "Supplier, positive amount, valid direction, reason, and client operation id are required."));
        }

        return _transactions.ExecuteAsync(async ct =>
        {
            var authorization = await _authorization.AuthorizeAsync(
                command.ActorId,
                PermissionKeys.SupplierAccountAdjust,
                ct);
            if (!authorization.IsSuccess)
            {
                return Result.Failure(authorization.Error!.Code, authorization.Error.Message);
            }

            await _operationLock.AcquireAsync(command.ClientOperationId, ct);
            await _resourceLock.AcquireAsync("supplier-account", command.SupplierId, ct);

            if (await _accounts.HasSourceEntryAsync(
                    command.Direction == SupplierAccountDirection.IncreasePayable
                        ? SupplierAccountEntryType.AdjustmentIncrease
                        : SupplierAccountEntryType.AdjustmentDecrease,
                    "SupplierAccountAdjustment",
                    command.ClientOperationId,
                    ct))
            {
                return Result.Success();
            }

            var entry = new SupplierAccountEntry
            {
                EntryNumber = await _numbers.NextAsync("SAE", ct),
                SupplierId = command.SupplierId,
                EntryType = command.Direction == SupplierAccountDirection.IncreasePayable
                    ? SupplierAccountEntryType.AdjustmentIncrease
                    : SupplierAccountEntryType.AdjustmentDecrease,
                Direction = command.Direction,
                Amount = decimal.Round(command.Amount, 2, MidpointRounding.AwayFromZero),
                ReferenceType = "SupplierAccountAdjustment",
                ReferenceId = command.ClientOperationId,
                OccurredAt = _clock.UtcNow,
                ActorId = command.ActorId,
                ClientOperationId = command.ClientOperationId,
                Note = command.Reason.Trim(),
                CreatedAt = _clock.UtcNow
            };
            entry.ValidateDirection();
            _accounts.AddEntry(entry);

            _audit.Record(
                "SUPPLIER_ACCOUNT_ADJUSTED",
                "SUPPLIER_ACCOUNT",
                command.SupplierId,
                command.ActorId,
                command.ClientOperationId,
                $"{command.Direction}; amount={entry.Amount:0.00}; reason={command.Reason.Trim()}");

            await _unitOfWork.SaveChangesAsync(ct);
            return Result.Success();
        }, cancellationToken);
    }
}
