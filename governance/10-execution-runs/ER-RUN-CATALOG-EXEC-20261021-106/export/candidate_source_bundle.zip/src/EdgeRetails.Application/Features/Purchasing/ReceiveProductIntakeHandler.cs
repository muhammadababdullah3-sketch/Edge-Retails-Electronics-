using System.Globalization;
using System.Text;
using EdgeRetails.Application.Abstractions;
using EdgeRetails.Application.Common;
using EdgeRetails.Application.Features.Identity;
using EdgeRetails.Application.Features.Terminals;
using EdgeRetails.Domain.Catalog;
using EdgeRetails.Domain.Common;
using EdgeRetails.Domain.Inventory;
using EdgeRetails.Domain.Posting;
using EdgeRetails.Domain.Purchasing;

namespace EdgeRetails.Application.Features.Purchasing;

public sealed record ReceiveProductIntakeCommand(
    Guid PurchaseId,
    Guid ProductId,
    Guid ProductUnitId,
    decimal EnteredQuantity,
    decimal? EnteredUnitCost,
    IReadOnlyList<SerializedIdentityInput> SerializedUnits,
    Guid CreatedBy,
    Guid ClientOperationId,
    string? Note = null,
    DateOnly? PostingDate = null,
    SupervisorApprovalRequest? SupervisorApproval = null,
    bool? CallerSuppliedBooleanOverride = null);

public sealed record CommittedInventoryUnitDto(
    Guid Id,
    string TrackingCode,
    long ItemSequence,
    string? SerialNumber,
    string? Imei1,
    string? Imei2,
    decimal AcquisitionCost);

public sealed record ReceiveProductIntakeResult(
    Guid PurchaseId,
    Guid ProductId,
    string ProductName,
    string ProductCode,
    string? ModelCode,
    string? CompanyCode,
    string? CategorySymbol,
    string DealerCode,
    decimal ReceivedQuantity,
    decimal BaseQuantity,
    TrackingMode TrackingMode,
    IReadOnlyList<CommittedInventoryUnitDto> CommittedUnits,
    bool WasExisting);

public sealed class ReceiveProductIntakeHandler
{
    private readonly IPurchasingRepository _purchases;
    private readonly IPartyRepository _parties;
    private readonly ICatalogRepository _catalog;
    private readonly IInventoryRepository _inventory;
    private readonly IInventoryCostAllocator _costs;
    private readonly ITraceabilityRepository _traceability;
    private readonly IOperationLock _operationLock;
    private readonly IResourceLock _resourceLock;
    private readonly IBusinessAuditWriter _audit;
    private readonly IClock _clock;
    private readonly ITransactionRunner _transactions;
    private readonly IApplicationPermissionAuthorizer _authorization;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ISequenceHighWaterService _highWaterService;
    private readonly IPhysicalUnitCreationAuthority? _physicalUnits;
    private readonly IShopPostingValidationService? _postingValidation;

    public ReceiveProductIntakeHandler(
        IPurchasingRepository purchases,
        IPartyRepository parties,
        ICatalogRepository catalog,
        IInventoryRepository inventory,
        IInventoryCostAllocator costs,
        ITraceabilityRepository traceability,
        IOperationLock operationLock,
        IResourceLock resourceLock,
        IBusinessAuditWriter audit,
        IClock clock,
        ITransactionRunner transactions,
        IApplicationPermissionAuthorizer authorization,
        IUnitOfWork unitOfWork,
        ISequenceHighWaterService? highWaterService = null,
        IOperationOutcomeLedger? outcomeLedger = null,
        IPhysicalUnitCreationAuthority? physicalUnitCreationAuthority = null,
        IShopPostingValidationService? postingValidation = null)
    {
        _purchases = purchases;
        _parties = parties;
        _catalog = catalog;
        _inventory = inventory;
        _costs = costs;
        _traceability = traceability;
        _operationLock = operationLock;
        _resourceLock = resourceLock;
        _audit = audit;
        _clock = clock;
        _transactions = transactions;
        _authorization = authorization;
        _unitOfWork = unitOfWork;
        _highWaterService = highWaterService ?? NullSequenceHighWaterService.Instance;
        _outcomeLedger = outcomeLedger;
        _physicalUnits = physicalUnitCreationAuthority;
        _postingValidation = postingValidation;
    }

    private readonly IOperationOutcomeLedger? _outcomeLedger;

    public IOperationOutcomeLedger? OutcomeLedger => _outcomeLedger;

    public static string ComputePayloadFingerprint(
        Guid purchaseId,
        Guid purchaseItemId,
        Guid productId,
        Guid supplierId,
        Guid productUnitId,
        decimal enteredQuantity,
        decimal? enteredUnitCost,
        IReadOnlyList<SerializedIdentityInput>? serializedUnits,
        string? note = null)
    {
        var sb = new StringBuilder();
        sb.Append(purchaseId.ToString("D")).Append('|')
          .Append(purchaseItemId.ToString("D")).Append('|')
          .Append(productId.ToString("D")).Append('|')
          .Append(supplierId.ToString("D")).Append('|')
          .Append(productUnitId.ToString("D")).Append('|')
          .Append(enteredQuantity.ToString("0.####", CultureInfo.InvariantCulture)).Append('|')
          .Append(enteredUnitCost.HasValue ? enteredUnitCost.Value.ToString("0.####", CultureInfo.InvariantCulture) : "").Append('|')
          .Append(note?.Trim() ?? "").Append('|');

        if (serializedUnits != null && serializedUnits.Count > 0)
        {
            var normalized = serializedUnits
                .Select(u => $"{NormalizeSerial(u.SerialNumber) ?? ""}:{NormalizeImei(u.Imei1) ?? ""}:{NormalizeImei(u.Imei2) ?? ""}")
                .OrderBy(x => x, StringComparer.Ordinal);
            sb.Append(string.Join(";", normalized));
        }

        return OperationPayloadFingerprint.ComputeSha256(sb.ToString());
    }

    public static string ComputeFallbackFingerprint(ReceiveProductIntakeCommand command)
    {
        var sb = new StringBuilder();
        sb.Append(command.PurchaseId.ToString("D")).Append('|')
          .Append(command.ProductId.ToString("D")).Append('|')
          .Append(command.ProductUnitId.ToString("D")).Append('|')
          .Append(command.EnteredQuantity.ToString("0.####", CultureInfo.InvariantCulture)).Append('|')
          .Append(command.EnteredUnitCost.HasValue ? command.EnteredUnitCost.Value.ToString("0.####", CultureInfo.InvariantCulture) : "").Append('|')
          .Append(command.Note?.Trim() ?? "").Append('|');

        if (command.SerializedUnits != null && command.SerializedUnits.Count > 0)
        {
            var normalized = command.SerializedUnits
                .Select(u => $"{NormalizeSerial(u.SerialNumber) ?? ""}:{NormalizeImei(u.Imei1) ?? ""}:{NormalizeImei(u.Imei2) ?? ""}")
                .OrderBy(x => x, StringComparer.Ordinal);
            sb.Append(string.Join(";", normalized));
        }

        return OperationPayloadFingerprint.ComputeSha256(sb.ToString());
    }

    public async Task<Result<ReceiveProductIntakeResult>> HandleAsync(
        ReceiveProductIntakeCommand command,
        CancellationToken cancellationToken = default)
    {
        if (command.ClientOperationId == Guid.Empty)
        {
            return Result<ReceiveProductIntakeResult>.Failure(
                "receiving.operation_id_required", "Client operation id is required.");
        }

        var computedFingerprint = ComputeFallbackFingerprint(command);

        if (_outcomeLedger is not null)
        {
            var preLockOutcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, cancellationToken);
            if (preLockOutcome is not null)
            {
                var evaluated = await EvaluateGuardedOutcomeAsync(preLockOutcome, command, computedFingerprint, cancellationToken);
                if (evaluated.HasValue)
                {
                    return evaluated.Value;
                }
            }
        }

        if (command.PurchaseId == Guid.Empty)
        {
            var fail = Result<ReceiveProductIntakeResult>.Failure(
                "receiving.purchase_required", "Purchase id is required for physical intake.");
            if (_outcomeLedger is not null)
            {
                await _outcomeLedger.RecordFailureAsync(
                    command.ClientOperationId,
                    "InventoryMovement",
                    fail.Error!.Code,
                    fail.Error.Message,
                    actorId: command.CreatedBy,
                    payloadFingerprint: computedFingerprint,
                    cancellationToken: cancellationToken);
            }
            return fail;
        }

        if (command.ProductId == Guid.Empty)
        {
            var fail = Result<ReceiveProductIntakeResult>.Failure(
                "receiving.product_required", "Product id is required. Physical intake session is locked to exactly one product.");
            if (_outcomeLedger is not null)
            {
                await _outcomeLedger.RecordFailureAsync(
                    command.ClientOperationId,
                    "InventoryMovement",
                    fail.Error!.Code,
                    fail.Error.Message,
                    actorId: command.CreatedBy,
                    payloadFingerprint: computedFingerprint,
                    cancellationToken: cancellationToken);
            }
            return fail;
        }

        if (command.EnteredQuantity <= 0)
        {
            var fail = Result<ReceiveProductIntakeResult>.Failure(
                "receiving.quantity_positive", "Entered quantity must be greater than zero.");
            if (_outcomeLedger is not null)
            {
                await _outcomeLedger.RecordFailureAsync(
                    command.ClientOperationId,
                    "InventoryMovement",
                    fail.Error!.Code,
                    fail.Error.Message,
                    actorId: command.CreatedBy,
                    payloadFingerprint: computedFingerprint,
                    cancellationToken: cancellationToken);
            }
            return fail;
        }

        var result = await _transactions.ExecuteAsync(async ct =>
        {
            var authorization = await _authorization.AuthorizeAsync(
                command.CreatedBy,
                PermissionKeys.PurchasingManage,
                ct);
            if (!authorization.IsSuccess)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    authorization.Error!.Code,
                    authorization.Error.Message);
            }

            await _operationLock.AcquireAsync(command.ClientOperationId, ct);

            if (_outcomeLedger is not null)
            {
                var outcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, ct);
                if (outcome is not null)
                {
                    var evaluated = await EvaluateGuardedOutcomeAsync(outcome, command, computedFingerprint, ct);
                    if (evaluated.HasValue)
                    {
                        return evaluated.Value;
                    }
                }
            }

            // Discover resource IDs without row locks. Definitive reads below
            // revalidate after all command-wide logical locks are held.
            var discoveredPurchase = await _purchases.GetPurchaseAsync(command.PurchaseId, ct);
            var discoveredItems = await _purchases.GetPurchaseItemsForDiscoveryAsync(command.PurchaseId, ct);
            var discoveredMatches = discoveredItems.Where(x => x.ProductId == command.ProductId).ToArray();
            if (discoveredPurchase is null)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.purchase_not_found", $"Purchase '{command.PurchaseId}' was not found.");
            }
            if (discoveredMatches.Length != 1)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.product_not_on_purchase",
                    $"Product '{command.ProductId}' does not belong to purchase '{discoveredPurchase.PurchaseNumber}'. Receiving session is strictly locked to products on the selected purchase.");
            }
            await _resourceLock.AcquireAsync("purchase-item", discoveredMatches[0].Id, ct);
            await _resourceLock.AcquireAsync("product", command.ProductId, ct);
            await _resourceLock.AcquireAsync("supplier-product", $"{discoveredPurchase.SupplierId:D}:{command.ProductId:D}", ct);
            var discoveredProduct = await _catalog.GetProductAsync(command.ProductId, ct);
            var lockedIdentityKeys = new HashSet<string>(StringComparer.Ordinal);
            if (discoveredProduct is not null)
            {
                try
                {
                    foreach (var key in IntakeIdentityKeys(discoveredProduct, command.SerializedUnits))
                    {
                        await _resourceLock.AcquireAsync("inventory-identity", key, ct);
                        lockedIdentityKeys.Add(key);
                    }
                }
                catch (BusinessRuleException ex)
                {
                    return Result<ReceiveProductIntakeResult>.Failure(ex.Code, ex.Message);
                }
            }

            // Invariant check: Purchase existence and state
            var purchase = await _purchases.GetPurchaseForUpdateAsync(command.PurchaseId, ct);
            if (purchase is null)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.purchase_not_found", $"Purchase '{command.PurchaseId}' was not found.");
            }

            if (purchase.Status == PurchaseStatus.Voided)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.purchase_voided", "Cannot receive stock against a voided purchase.");
            }

            // Invariant check: Product must exist on this purchase
            if (purchase.SupplierId != discoveredPurchase.SupplierId)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.intake_authority_changed_retry", "Purchase supplier changed during preparation. Retry the complete intake.");
            }
            var purchaseItems = await _purchases.GetPurchaseItemsAsync(purchase.Id, ct);
            var matchingItems = purchaseItems.Where(x => x.ProductId == command.ProductId).ToArray();
            var purchaseItem = matchingItems.Length == 1 ? matchingItems[0] : null;
            if (purchaseItem is null)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.product_not_on_purchase",
                    $"Product '{command.ProductId}' does not belong to purchase '{purchase.PurchaseNumber}'. Receiving session is strictly locked to products on the selected purchase.");
            }

            if (purchaseItem.Id != discoveredMatches[0].Id)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.intake_authority_changed_retry", "Ordered item changed during preparation. Retry the complete intake.");
            }

            if (command.ProductUnitId != purchaseItem.ProductUnitId)
            {
                var mismatchedUnit = await _catalog.GetProductUnitAsync(command.ProductUnitId, ct);
                if (mismatchedUnit is null || mismatchedUnit.ProductId != command.ProductId)
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "purchasing.product_unit_not_allowed",
                        "Selected unit does not belong to the ordered product.");
                }

                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.intake_unit_mismatch",
                    $"Intake product unit '{command.ProductUnitId}' does not match ordered product unit '{purchaseItem.ProductUnitId}'.");
            }

            if (purchaseItem.FactorToBaseSnapshot <= 0 || purchaseItem.EnteredQuantity <= 0 ||
                purchaseItem.BaseQuantity <= 0 ||
                (purchaseItem.FactorToBaseSnapshot > 1m && purchaseItem.EnteredQuantity > decimal.MaxValue / purchaseItem.FactorToBaseSnapshot) ||
                QuantityMath.RoundQuantity(purchaseItem.EnteredQuantity * purchaseItem.FactorToBaseSnapshot) != purchaseItem.BaseQuantity)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.purchase_snapshot_invalid",
                    "Purchase item quantity and factor snapshot is invalid or inconsistent.");
            }

            if (command.EnteredUnitCost.HasValue &&
                command.EnteredUnitCost.Value != purchaseItem.EnteredUnitCost)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.receipt_cost_override_not_allowed",
                    "Physical intake does not allow arbitrary unit cost override. Unit cost is governed by purchase order.");
            }

            // Compute authoritative material payload fingerprint with resolved domain identities
            computedFingerprint = ComputePayloadFingerprint(
                command.PurchaseId,
                purchaseItem.Id,
                command.ProductId,
                purchase.SupplierId,
                command.ProductUnitId,
                command.EnteredQuantity,
                command.EnteredUnitCost,
                command.SerializedUnits,
                command.Note);

            // Check canonical outcome ledger for existing execution or payload mismatch
            if (_outcomeLedger is not null)
            {
                var existingOutcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, ct);
                if (existingOutcome is not null)
                {
                    if (!string.IsNullOrEmpty(existingOutcome.PayloadFingerprint) &&
                        !string.Equals(existingOutcome.PayloadFingerprint, computedFingerprint, StringComparison.Ordinal))
                    {
                        return Result<ReceiveProductIntakeResult>.Failure(
                            "idempotency.payload_mismatch",
                            "Operation was previously submitted with a different payload.");
                    }
                }
            }

            // Check if command.ClientOperationId was already executed (Crash-After-Commit / Idempotency Replay)
            var existingMovement = await _inventory.GetMovementByCorrelationIdAsync(command.ClientOperationId, ct);
            if (existingMovement is not null)
            {
                if (existingMovement.ReferenceId != purchase.Id || existingMovement.ProductId != command.ProductId)
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "idempotency.payload_mismatch",
                        "Operation was previously submitted with a different purchase or product.");
                }

                if (_outcomeLedger is not null)
                {
                    var existingOutcome = await _outcomeLedger.GetOutcomeAsync(command.ClientOperationId, ct);
                    if (existingOutcome is not null &&
                        !string.IsNullOrEmpty(existingOutcome.PayloadFingerprint) &&
                        !string.Equals(existingOutcome.PayloadFingerprint, computedFingerprint, StringComparison.Ordinal))
                    {
                        return Result<ReceiveProductIntakeResult>.Failure(
                            "idempotency.payload_mismatch",
                            "Operation was previously submitted with a different payload.");
                    }
                }

                var productExisting = await _catalog.GetProductAsync(command.ProductId, ct);
                var supplierExisting = await _parties.GetSupplierAsync(purchase.SupplierId, ct);
                var dealerCodeExisting = supplierExisting?.DealerCode ?? string.Empty;

                var existingUnits = await _inventory.GetUnitsForMovementAsync(existingMovement.Id, ct);
                if (existingUnits.Count == 0 && (productExisting?.TrackingMode == TrackingMode.Serialized || productExisting?.TrackingMode == TrackingMode.IndividualPiece || productExisting?.TrackingMode == TrackingMode.Container))
                {
                    existingUnits = await _inventory.GetUnitsByPurchaseItemAsync(purchaseItem.Id, ct);
                }

                // Check payload mismatch on quantity and serials
                if (existingUnits.Count > 0)
                {
                    var isContainerExisting = productExisting?.TrackingMode == TrackingMode.Container;
                    if (purchaseItem.FactorToBaseSnapshot > 1m && command.EnteredQuantity > decimal.MaxValue / purchaseItem.FactorToBaseSnapshot)
                    {
                        return Result<ReceiveProductIntakeResult>.Failure(
                            "idempotency.payload_mismatch", "Operation was previously submitted with a different quantity.");
                    }
                    var expectedCount = isContainerExisting
                        ? command.EnteredQuantity
                        : command.EnteredQuantity * purchaseItem.FactorToBaseSnapshot;
                    if (expectedCount <= 0 || expectedCount > 100_000 || !QuantityMath.IsWhole(expectedCount))
                    {
                        return Result<ReceiveProductIntakeResult>.Failure(
                            "idempotency.payload_mismatch", "Operation was previously submitted with a different quantity.");
                    }
                    var expectedUnitsCount = decimal.ToInt32(expectedCount);

                    if (existingUnits.Count != expectedUnitsCount)
                    {
                        return Result<ReceiveProductIntakeResult>.Failure(
                            "idempotency.payload_mismatch",
                            "Operation was previously submitted with a different quantity.");
                    }

                    if (command.SerializedUnits.Count > 0)
                    {
                        var existingSerials = existingUnits.Select(u => NormalizeSerial(u.SerialNumber)).Where(s => s != null).ToHashSet(StringComparer.OrdinalIgnoreCase);
                        var existingImeis = existingUnits.Select(u => NormalizeImei(u.Imei1)).Where(s => s != null).ToHashSet(StringComparer.OrdinalIgnoreCase);

                        foreach (var inputUnit in command.SerializedUnits)
                        {
                            var s = NormalizeSerial(inputUnit.SerialNumber);
                            var im1 = NormalizeImei(inputUnit.Imei1);
                            if (s != null && !existingSerials.Contains(s))
                            {
                                return Result<ReceiveProductIntakeResult>.Failure(
                                    "idempotency.payload_mismatch",
                                    "Operation was previously submitted with different serial numbers.");
                            }
                            if (im1 != null && !existingImeis.Contains(im1))
                            {
                                return Result<ReceiveProductIntakeResult>.Failure(
                                    "idempotency.payload_mismatch",
                                    "Operation was previously submitted with different IMEIs.");
                            }
                        }
                    }
                }

                if (_outcomeLedger is not null)
                {
                    await _outcomeLedger.RecordSuccessAsync(
                        command.ClientOperationId,
                        PostingOperationTypes.ProductIntake,
                        existingMovement.Id,
                        existingMovement.ReferenceId?.ToString("D"),
                        actorId: command.CreatedBy,
                        payloadFingerprint: computedFingerprint,
                        cancellationToken: ct);
                }

                var committedExistingUnits = existingUnits
                    .OrderBy(u => u.ItemSequence)
                    .ThenBy(u => u.CreatedAt)
                    .Select(u => new CommittedInventoryUnitDto(
                        u.Id,
                        u.TrackingCode ?? string.Empty,
                        u.ItemSequence ?? 0,
                        u.SerialNumber,
                        u.Imei1,
                        u.Imei2,
                        u.AcquisitionCost))
                    .ToList();

                if (purchaseItem.FactorToBaseSnapshot > 1m && command.EnteredQuantity > decimal.MaxValue / purchaseItem.FactorToBaseSnapshot)
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "idempotency.payload_mismatch", "Operation was previously submitted with a different quantity.");
                }
                // Replay reports the ordered conversion authority, never a later
                // catalog factor that could reinterpret the committed receipt.
                var baseQuantityExisting = QuantityMath.RoundQuantity(
                    command.EnteredQuantity * purchaseItem.FactorToBaseSnapshot);

                Company? companyExisting = null;
                if (productExisting?.CompanyId.HasValue == true)
                {
                    companyExisting = await _catalog.GetCompanyAsync(productExisting.CompanyId.Value, ct);
                }

                Category? categoryExisting = null;
                if (productExisting?.CategoryId.HasValue == true)
                {
                    categoryExisting = await _catalog.GetCategoryAsync(productExisting.CategoryId.Value, ct);
                }

                return Result<ReceiveProductIntakeResult>.Success(new ReceiveProductIntakeResult(
                    purchase.Id,
                    command.ProductId,
                    productExisting?.Name ?? string.Empty,
                    productExisting?.Sku ?? string.Empty,
                    productExisting?.ModelCode,
                    companyExisting?.Code,
                    categoryExisting?.IdentitySymbol,
                    dealerCodeExisting,
                    command.EnteredQuantity,
                    baseQuantityExisting,
                    productExisting?.TrackingMode ?? TrackingMode.Quantity,
                    committedExistingUnits,
                    WasExisting: true));
            }

            // Invariant check: Product master data
            await _resourceLock.AcquireAsync("product", command.ProductId, ct);
            var product = await _catalog.GetProductForUpdateAsync(command.ProductId, ct);
            if (product is null)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.product_not_found", "Product master was not found.");
            }

            if (!product.IsActive)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.product_inactive", $"Product '{product.Name}' is inactive.");
            }

            // Unit validation
            try
            {
                if (IntakeIdentityKeys(product, command.SerializedUnits).Any(x => !lockedIdentityKeys.Contains(x)))
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "inventory.physical_unit_policy_changed_retry", "Product requires additional identity locks. Retry the complete intake.");
                }
            }
            catch (BusinessRuleException ex)
            {
                return Result<ReceiveProductIntakeResult>.Failure(ex.Code, ex.Message);
            }
            var productUnit = await _catalog.GetProductUnitAsync(command.ProductUnitId, ct);
            if (productUnit is null || productUnit.ProductId != product.Id || !productUnit.IsActive || !productUnit.CanPurchase)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.product_unit_not_allowed",
                    $"Selected unit is not valid or not allowed for purchase on '{product.Name}'.");
            }

            // Supplier resolution
            var supplier = await _parties.GetSupplierAsync(purchase.SupplierId, ct);
            if (supplier is null)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.supplier_not_found", "Supplier was not found.");
            }

            var dealerCode = supplier.DealerCode;
            if (string.IsNullOrWhiteSpace(dealerCode))
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "parties.dealer_code_missing", "Supplier lacks an authoritative dealer code.");
            }

            // The product resource/row boundary is already held from master validation.
            // Stocktake check
            if (await _inventory.IsProductBlockedByCountingStocktakeAsync(product.Id, ct))
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "inventory.stocktake_blocks_product",
                    $"Product '{product.Name}' is locked by an active stocktake.");
            }

            if (command.EnteredQuantity <= 0)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "catalog.quantity_positive",
                    "Entered quantity must be greater than zero.");
            }

            var isPiece = product.TrackingMode == TrackingMode.Serialized || product.TrackingMode == TrackingMode.IndividualPiece;
            var isContainer = product.TrackingMode == TrackingMode.Container;
            var isBulk = product.TrackingMode == TrackingMode.Quantity || product.TrackingMode == TrackingMode.Length;

            if (isContainer)
            {
                if (!QuantityMath.IsWhole(command.EnteredQuantity))
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "catalog.container_quantity_whole",
                        "Container quantity must be an exact whole integer count.");
                }

                if (!QuantityMath.IsWhole(purchaseItem.FactorToBaseSnapshot))
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "catalog.container_conversion_whole",
                        "Container conversion factor must be an exact whole integer count.");
                }
            }

            if (purchaseItem.FactorToBaseSnapshot > 1m && command.EnteredQuantity > decimal.MaxValue / purchaseItem.FactorToBaseSnapshot)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.physical_unit_count_out_of_range", "Receipt quantity is outside the supported numeric range.");
            }
            var exactBaseQuantity = command.EnteredQuantity * purchaseItem.FactorToBaseSnapshot;

            if ((isPiece || isContainer) && !QuantityMath.IsWhole(exactBaseQuantity))
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "catalog.serialized_whole_quantity",
                    "Tracked product quantity must resolve to an exact whole base quantity before rounding.");
            }

            var baseQuantity = (isPiece || isContainer)
                ? exactBaseQuantity
                : QuantityMath.RoundQuantity(exactBaseQuantity);

            if (baseQuantity <= 0)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "catalog.quantity_positive", "Receipt quantity must resolve to positive base stock.");
            }

            var effectiveUnitCost = purchaseItem.EffectiveBaseUnitCost;
            var requiredUnitCountDecimal = isContainer ? command.EnteredQuantity : baseQuantity;
            if ((isPiece || isContainer) &&
                (requiredUnitCountDecimal <= 0 || requiredUnitCountDecimal > 100_000 || !QuantityMath.IsWhole(requiredUnitCountDecimal)))
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.physical_unit_count_out_of_range",
                    "Physical unit count must be a positive whole integer within valid range (1 - 100,000).");
            }

            // Tracking policy validation
            if (isBulk && command.SerializedUnits.Count > 0)
            {
                var label = product.TrackingMode == TrackingMode.Length ? "Length" : "Quantity";
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.serials_not_allowed",
                    $"{label} products update stock balances and lots only; they do not accept individual piece identities.");
            }

            // Enforce that receiving cannot exceed outstanding quantity
            var alreadyReceived = await _inventory.GetPurchaseItemReceivedBaseQuantityAsync(purchaseItem.Id, ct);
            var outstandingQuantity = QuantityMath.RoundQuantity(purchaseItem.BaseQuantity - alreadyReceived);
            if (baseQuantity > outstandingQuantity)
            {
                return Result<ReceiveProductIntakeResult>.Failure(
                    "purchasing.intake_exceeds_ordered",
                    $"Requested intake quantity ({baseQuantity}) exceeds outstanding quantity ({outstandingQuantity}) for product '{product.Name}'.");
            }

            // Purchase-item and supplier-product logical locks precede rows.

            var priorCarryingValue = await _inventory.GetPurchaseItemReceivedCarryingValueAsync(
                purchaseItem.Id, isPiece || isContainer, ct);
            var receiptValue = PurchaseReceiptCost.Allocate(purchaseItem.BaseQuantity,
                purchaseItem.EffectiveLineCost, alreadyReceived, baseQuantity, priorCarryingValue);
            var receiptUnitCost = PurchaseReceiptCost.Round(receiptValue / baseQuantity);
            var completesOrder = alreadyReceived + baseQuantity == purchaseItem.BaseQuantity;
            if (!completesOrder)
            {
                // Persist intermediate realized value in both the lot cost and
                // physical acquisition amounts, so future receipts can recover it.
                receiptValue = PurchaseReceiptCost.Round(baseQuantity * receiptUnitCost);
            }
            var stock = await _inventory.GetStockBalanceForUpdateAsync(product.Id, ct);
            if (stock is null)
            {
                stock = new StockBalance { ProductId = product.Id };
                _inventory.AddStockBalance(stock);
            }

            // Execute inventory movement
            var before = stock.SellableQty;
            stock.ApplyDelta(InventoryBucket.Sellable, baseQuantity);

            var movement = new InventoryMovement
            {
                ProductId = product.Id,
                MovementType = InventoryMovementType.PurchaseIn,
                ReferenceType = "PURCHASE",
                ReferenceId = purchase.Id,
                UnitCostSnapshot = effectiveUnitCost,
                ActorId = command.CreatedBy,
                OccurredAt = _clock.UtcNow,
                CorrelationId = command.ClientOperationId,
                Note = command.Note?.Trim() ?? $"Intake for {purchase.PurchaseNumber}"
            };
            _inventory.AddMovement(movement);
            _inventory.AddMovementEffect(new InventoryMovementEffect
            {
                MovementId = movement.Id,
                StockBucket = InventoryBucket.Sellable,
                QuantityDelta = baseQuantity,
                QuantityBefore = before,
                QuantityAfter = stock.SellableQty
            });

            var lotId = await _costs.AddCarryingValueAndLotWithIdAsync(
                product.Id,
                baseQuantity,
                receiptUnitCost,
                movement.Id,
                purchaseItem.Id,
                ct);

            var committedUnits = new List<CommittedInventoryUnitDto>();

            if (isPiece || isContainer)
            {
                if (string.IsNullOrWhiteSpace(product.Sku))
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "purchasing.sku_required_for_tracking",
                        $"Tracked product '{product.Name}' requires an authoritative ProductCode (SKU) before receipt.");
                }

                var requiredUnitCount = decimal.ToInt32(requiredUnitCountDecimal);

                var lineUnits = command.SerializedUnits;
                if (lineUnits.Count == 0 && !product.SerialTrackingEnabled && !product.ImeiTrackingEnabled)
                {
                    var autoList = new List<SerializedIdentityInput>(requiredUnitCount);
                    for (var i = 0; i < requiredUnitCount; i++)
                    {
                        autoList.Add(new SerializedIdentityInput(null, null, null));
                    }
                    lineUnits = autoList;
                }
                else if (lineUnits.Count != requiredUnitCount)
                {
                    var unitLabel = isContainer ? "container" : "individual piece";
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "purchasing.serial_count_mismatch",
                        $"{unitLabel} identities for '{product.Name}' must equal {unitLabel} count ({requiredUnitCount}), received {lineUnits.Count}.");
                }

                // Validate identities
                var validationError = ValidateIdentities(product, lineUnits);
                if (validationError != null)
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        validationError.Code,
                        validationError.Message);
                }

                // Check duplicates against DB
                foreach (var identity in lineUnits)
                {
                    var serial = NormalizeSerial(identity.SerialNumber);
                    var imei1 = NormalizeImei(identity.Imei1);
                    var imei2 = NormalizeImei(identity.Imei2);
                    if (serial is not null || imei1 is not null || imei2 is not null)
                    {
                        if (await _inventory.InventoryIdentityExistsAsync(serial, imei1, imei2, ct))
                        {
                            return Result<ReceiveProductIntakeResult>.Failure(
                                "purchasing.identity_already_exists",
                                "A received Serial or IMEI already exists in inventory history.");
                        }
                    }
                }

                if (_physicalUnits is null)
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        "inventory.physical_unit_authority_unavailable",
                        "Physical-unit creation authority is unavailable.");
                }

                var creation = await _physicalUnits.CreateAsync(
                    supplier.Id,
                    product.Id,
                    lineUnits.Select((identity, index) => new PhysicalUnitCreationEntry(
                        identity.SerialNumber,
                        identity.Imei1,
                        identity.Imei2,
                        InventoryUnitStatus.InStock,
                        PurchaseReceiptCost.PhysicalAcquisitionCost(receiptValue, lineUnits.Count, index),
                        lotId,
                        InventoryUnitOriginType.Purchase,
                        SourcePurchaseItemId: purchaseItem.Id,
                        InitialBaseQuantity: isContainer ? purchaseItem.FactorToBaseSnapshot : (decimal?)null,
                        RemainingBaseQuantity: isContainer ? purchaseItem.FactorToBaseSnapshot : (decimal?)null,
                        PackState: isContainer ? PackState.Sealed : (PackState?)null,
                        IsLooseStock: false)).ToArray(),
                    ct);
                if (!creation.IsSuccess || creation.Value is null)
                {
                    return Result<ReceiveProductIntakeResult>.Failure(
                        creation.Error!.Code,
                        creation.Error.Message);
                }

                foreach (var unit in creation.Value)
                {
                    _purchases.AddPurchaseItemUnit(new PurchaseItemUnit
                    {
                        PurchaseItemId = purchaseItem.Id,
                        InventoryUnitId = unit.Id
                    });
                    _inventory.AddMovementUnit(new InventoryMovementUnit
                    {
                        MovementId = movement.Id,
                        InventoryUnitId = unit.Id,
                        FromStatus = null,
                        ToStatus = InventoryUnitStatus.InStock
                    });
                    committedUnits.Add(new CommittedInventoryUnitDto(
                        unit.Id, unit.TrackingCode!, unit.ItemSequence!.Value,
                        unit.SerialNumber, unit.Imei1, unit.Imei2, unit.AcquisitionCost));
                }            }

            var costState = await _inventory.GetCostStateForUpdateAsync(product.Id, ct)
                ?? throw new BusinessRuleException(
                    "inventory.cost_state_missing",
                    "Inventory cost state was not created for the physical intake.");

            costState.LastPurchaseCost = effectiveUnitCost;
            costState.LastPurchaseAt = _clock.UtcNow;
            costState.TotalInventoryCost = PurchaseReceiptCost.Round(costState.TotalInventoryCost +
                receiptValue - PurchaseReceiptCost.Round(baseQuantity * receiptUnitCost));
            costState.MovingAverageCost = PurchaseReceiptCost.Round(costState.TotalInventoryCost / costState.CostedQty);
            var receivedLot = await _inventory.GetInventoryLotForUpdateAsync(lotId, ct);
            if (receivedLot is not null)
            {
                receivedLot.OriginalUnitCost = effectiveUnitCost;
            }

            if (_outcomeLedger is not null)
            {
                await _outcomeLedger.RecordSuccessAsync(
                    command.ClientOperationId,
                    PostingOperationTypes.ProductIntake,
                    movement.Id,
                    movement.ReferenceId?.ToString("D"),
                    actorId: command.CreatedBy,
                    payloadFingerprint: computedFingerprint,
                    cancellationToken: ct);
            }

                if (_postingValidation is not null)
                {
                    var postingDate = command.PostingDate ?? _clock.ShopDate;
                    var postingValidationResult = await _postingValidation.ValidateAndAuditPostingAsync(new PostingValidationCommand(
                        OperationType: PostingOperationTypes.Purchase,
                        EntityId: movement.Id,
                        EntityNumber: purchase.PurchaseNumber,
                        ActorId: command.CreatedBy,
                        PostingDate: postingDate,
                        SupplierDocumentDate: purchase.PurchaseDate,
                        SupervisorApproval: command.SupervisorApproval,
                        CallerSuppliedBooleanOverride: command.CallerSuppliedBooleanOverride), ct);

                    if (!postingValidationResult.IsSuccess)
                    {
                        return Result<ReceiveProductIntakeResult>.Failure(
                            postingValidationResult.Error!.Code,
                            postingValidationResult.Error.Message);
                    }
                }

                await _unitOfWork.SaveChangesAsync(ct);

            // Resolve company/category details for response
            Company? company = null;
            if (product.CompanyId.HasValue)
            {
                company = await _catalog.GetCompanyAsync(product.CompanyId.Value, ct);
            }

            Category? category = null;
            if (product.CategoryId.HasValue)
            {
                category = await _catalog.GetCategoryAsync(product.CategoryId.Value, ct);
            }

            return Result<ReceiveProductIntakeResult>.Success(new ReceiveProductIntakeResult(
                purchase.Id,
                product.Id,
                product.Name,
                product.Sku ?? string.Empty,
                product.ModelCode,
                company?.Code,
                category?.IdentitySymbol,
                dealerCode,
                command.EnteredQuantity,
                baseQuantity,
                product.TrackingMode,
                committedUnits,
                false));
        }, cancellationToken);

        if (!result.IsSuccess && _outcomeLedger is not null && command.ClientOperationId != Guid.Empty &&
            result.Error?.Code?.StartsWith("idempotency.") != true)
        {
            await _outcomeLedger.RecordFailureAsync(
                command.ClientOperationId,
                PostingOperationTypes.ProductIntake,
                result.Error?.Code ?? "receiving.failed",
                result.Error?.Message ?? "Physical receiving failed.",
                actorId: command.CreatedBy,
                payloadFingerprint: computedFingerprint,
                cancellationToken: cancellationToken);
        }

        return result;
    }

    private static Error? ValidateIdentities(
        Product product,
        IReadOnlyList<SerializedIdentityInput> identities)
    {
        var serials = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var imeis = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        for (var i = 0; i < identities.Count; i++)
        {
            var identity = identities[i];
            var serial = NormalizeSerial(identity.SerialNumber);
            var imei1 = NormalizeImei(identity.Imei1);
            var imei2 = NormalizeImei(identity.Imei2);

            if (product.SerialTrackingEnabled && string.IsNullOrWhiteSpace(serial))
            {
                return new("purchasing.serial_required", $"Unit #{i + 1} requires a Serial Number.");
            }

            if (product.ImeiTrackingEnabled && string.IsNullOrWhiteSpace(imei1))
            {
                return new("purchasing.imei_required", $"Unit #{i + 1} requires an IMEI 1.");
            }

            if (serial is not null)
            {
                if (!serials.Add(serial))
                {
                    return new("purchasing.duplicate_serial_in_batch", $"Duplicate serial '{serial}' in current intake batch.");
                }
            }

            if (imei1 is not null)
            {
                if (!imeis.Add(imei1))
                {
                    return new("purchasing.duplicate_imei_in_batch", $"Duplicate IMEI '{imei1}' in current intake batch.");
                }
            }

            if (imei2 is not null)
            {
                if (!imeis.Add(imei2))
                {
                    return new("purchasing.duplicate_imei_in_batch", $"Duplicate IMEI '{imei2}' in current intake batch.");
                }
            }

            if (imei1 is not null && imei2 is not null && string.Equals(imei1, imei2, StringComparison.OrdinalIgnoreCase))
            {
                return new("purchasing.same_imei_on_unit", $"Unit #{i + 1} has identical IMEI 1 and IMEI 2.");
            }
        }

        return null;
    }

    private static string? NormalizeSerial(string? value) =>
        IdentityNormalizationRules.NormalizeOptionalSerialNumber(value);

    private static string? NormalizeImei(string? value) =>
        IdentityNormalizationRules.NormalizeOptionalImei(value);

    private static IEnumerable<string> IntakeIdentityKeys(Product product, IReadOnlyList<SerializedIdentityInput> units) =>
        units.SelectMany(x => new[]
        {
            product.SerialTrackingEnabled && NormalizeSerial(x.SerialNumber) is string serial ? $"SERIAL:{serial}" : null,
            product.ImeiTrackingEnabled && NormalizeImei(x.Imei1) is string imei1 ? $"IMEI:{imei1}" : null,
            product.ImeiTrackingEnabled && NormalizeImei(x.Imei2) is string imei2 ? $"IMEI:{imei2}" : null
        }).Where(x => x is not null).Select(x => x!).Distinct(StringComparer.Ordinal).OrderBy(x => x, StringComparer.Ordinal);

    private static decimal Cost(decimal value) =>
        decimal.Round(value, 4, MidpointRounding.AwayFromZero);

    private async Task<Result<ReceiveProductIntakeResult>?> EvaluateGuardedOutcomeAsync(
        OperationOutcomeRecord outcome,
        ReceiveProductIntakeCommand command,
        string fallbackFingerprint,
        CancellationToken ct)
    {
        if (outcome.OperationType != "ProductIntake" && outcome.OperationType != "InventoryMovement")
        {
            return Result<ReceiveProductIntakeResult>.Failure(
                "idempotency.operation_type_mismatch",
                $"Operation was registered as '{outcome.OperationType}', not 'ProductIntake'.");
        }

        if (outcome.ActorId.HasValue && outcome.ActorId.Value != command.CreatedBy)
        {
            return Result<ReceiveProductIntakeResult>.Failure(
                "idempotency.context_mismatch",
                "Operation actor mismatch.");
        }

        string? authoritativeFingerprint = null;
        if (command.PurchaseId != Guid.Empty && command.ProductId != Guid.Empty)
        {
            var purchase = await _purchases.GetPurchaseAsync(command.PurchaseId, ct);
            if (purchase is not null)
            {
                var items = await _purchases.GetPurchaseItemsForDiscoveryAsync(command.PurchaseId, ct);
                var item = items.FirstOrDefault(x => x.ProductId == command.ProductId);
                if (item is not null)
                {
                    authoritativeFingerprint = ComputePayloadFingerprint(
                        command.PurchaseId,
                        item.Id,
                        command.ProductId,
                        purchase.SupplierId,
                        command.ProductUnitId,
                        command.EnteredQuantity,
                        command.EnteredUnitCost,
                        command.SerializedUnits,
                        command.Note);
                }
            }
        }

        var matchesFingerprint = string.IsNullOrEmpty(outcome.PayloadFingerprint) ||
            string.Equals(outcome.PayloadFingerprint, fallbackFingerprint, StringComparison.Ordinal) ||
            (authoritativeFingerprint is not null && string.Equals(outcome.PayloadFingerprint, authoritativeFingerprint, StringComparison.Ordinal));

        if (!matchesFingerprint)
        {
            return Result<ReceiveProductIntakeResult>.Failure(
                "idempotency.payload_mismatch",
                "Operation was previously submitted with a different payload.");
        }

        if (outcome.State == OperationOutcomeState.Succeeded && outcome.WasCommitted)
        {
            var movement = await _inventory.GetMovementByCorrelationIdAsync(command.ClientOperationId, ct);
            if (movement is null && outcome.EntityId.HasValue)
            {
                try
                {
                    var evidence = await _inventory.GetInventoryMovementEvidenceAsync(outcome.EntityId.Value, ct);
                    movement = evidence?.Movement;
                }
                catch (BusinessRuleException)
                {
                    // Fallback if test double does not support evidence read
                }
            }

            if (movement is not null)
            {
                var purchase = await _purchases.GetPurchaseAsync(command.PurchaseId, ct);
                if (purchase is null && movement.ReferenceId.HasValue)
                {
                    purchase = await _purchases.GetPurchaseAsync(movement.ReferenceId.Value, ct);
                }

                if (purchase is not null)
                {
                    var purchaseItems = await _purchases.GetPurchaseItemsAsync(purchase.Id, ct);
                    var purchaseItem = purchaseItems.FirstOrDefault(x => x.ProductId == command.ProductId);
                    if (purchaseItem is not null)
                    {
                        var productExisting = await _catalog.GetProductAsync(command.ProductId, ct);
                        var supplierExisting = await _parties.GetSupplierAsync(purchase.SupplierId, ct);
                        var dealerCodeExisting = supplierExisting?.DealerCode ?? string.Empty;

                        var existingUnits = await _inventory.GetUnitsForMovementAsync(movement.Id, ct);
                        if (existingUnits.Count == 0 && (productExisting?.TrackingMode == TrackingMode.Serialized || productExisting?.TrackingMode == TrackingMode.IndividualPiece || productExisting?.TrackingMode == TrackingMode.Container))
                        {
                            existingUnits = await _inventory.GetUnitsByPurchaseItemAsync(purchaseItem.Id, ct);
                        }

                        var committedExistingUnits = existingUnits
                            .OrderBy(u => u.ItemSequence)
                            .ThenBy(u => u.CreatedAt)
                            .Select(u => new CommittedInventoryUnitDto(
                                u.Id,
                                u.TrackingCode ?? string.Empty,
                                u.ItemSequence ?? 0,
                                u.SerialNumber,
                                u.Imei1,
                                u.Imei2,
                                u.AcquisitionCost))
                            .ToList();

                        var baseQuantityExisting = QuantityMath.RoundQuantity(
                            command.EnteredQuantity * purchaseItem.FactorToBaseSnapshot);

                        Company? companyExisting = null;
                        if (productExisting?.CompanyId.HasValue == true)
                        {
                            companyExisting = await _catalog.GetCompanyAsync(productExisting.CompanyId.Value, ct);
                        }

                        Category? categoryExisting = null;
                        if (productExisting?.CategoryId.HasValue == true)
                        {
                            categoryExisting = await _catalog.GetCategoryAsync(productExisting.CategoryId.Value, ct);
                        }

                        return Result<ReceiveProductIntakeResult>.Success(new ReceiveProductIntakeResult(
                            purchase.Id,
                            command.ProductId,
                            productExisting?.Name ?? string.Empty,
                            productExisting?.Sku ?? string.Empty,
                            productExisting?.ModelCode,
                            companyExisting?.Code,
                            categoryExisting?.IdentitySymbol,
                            dealerCodeExisting,
                            command.EnteredQuantity,
                            baseQuantityExisting,
                            productExisting?.TrackingMode ?? TrackingMode.Quantity,
                            committedExistingUnits,
                            WasExisting: true));
                    }
                }
            }

            return Result<ReceiveProductIntakeResult>.Failure(
                "idempotency.outcome_unknown",
                "Committed intake outcome has no matching inventory movement; reconciliation is required.");
        }

        if (outcome.State == OperationOutcomeState.Failed)
        {
            return Result<ReceiveProductIntakeResult>.Failure(
                outcome.ErrorCode ?? "idempotency.outcome_unknown",
                outcome.ErrorMessage ?? "Reconcile the previous intake outcome before another execution.");
        }

        return null;
    }
}
