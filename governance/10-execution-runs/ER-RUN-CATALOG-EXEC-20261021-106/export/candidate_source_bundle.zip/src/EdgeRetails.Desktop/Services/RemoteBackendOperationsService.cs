using System.Globalization;
using EdgeRetails.Application.Features.Finance;
using EdgeRetails.Application.Features.Warranty;
using EdgeRetails.Domain.Finance;
using EdgeRetails.Domain.Inventory;
using EdgeRetails.Domain.Warranty;

namespace EdgeRetails.Desktop.Services;

/// <summary>Warranty and supplier ledger adapter for the local Server HTTP boundary.</summary>
public sealed class RemoteBackendOperationsService(DesktopApiClient apiClient) : IBackendOperationsService
{
    public async Task<SupplierAccountWorkspaceDto> GetSupplierWorkspaceAsync(Guid supplierId, int pageSize = 200,
        DateTimeOffset? beforeOccurredAt = null, DateTimeOffset? beforeCreatedAt = null, Guid? beforeEntryId = null,
        CancellationToken cancellationToken = default)
    {
        if (beforeOccurredAt.HasValue || beforeCreatedAt.HasValue || beforeEntryId.HasValue)
        {
            return await GetSupplierHistoryPageAsync(supplierId, pageSize, new(beforeOccurredAt, beforeCreatedAt, beforeEntryId), cancellationToken);
        }

        var size = Math.Clamp(pageSize, 1, 200);
        var firstPage = await GetSupplierHistoryPageAsync(supplierId, size, new(null, null, null), cancellationToken);

        // When loading a full workspace with statement entries or when bounded to a specific page size < 200,
        // load only one bounded page without draining other lists (Phase3 contract).
        // Only paginate payments across requests when performing an unbounded payment history lookup
        // where other workspace lists are unpopulated and the initial page was full.
        var isPurePaymentHistory = size == 200 &&
                                   firstPage.Statement.Count == 0 &&
                                   firstPage.Refunds.Count == 0 &&
                                   firstPage.SuppliedProducts.Count == 0 &&
                                   firstPage.Payments.Count == size;

        if (!isPurePaymentHistory)
        {
            return firstPage;
        }

        var allPayments = new List<SupplierPaymentReadDto>(firstPage.Payments);
        var seenPaymentIds = new HashSet<Guid>(firstPage.Payments.Select(p => p.PaymentId));

        while (firstPage.Payments.Count == size && allPayments.Count % size == 0)
        {
            var lastPayment = allPayments[^1];
            var nextCursor = new SupplierHistoryCursor(
                PaymentAt: lastPayment.PaidAt,
                PaymentId: lastPayment.PaymentId);

            var nextPage = await GetSupplierHistoryPageAsync(supplierId, size, nextCursor, cancellationToken);
            if (nextPage.Payments.Count == 0)
            {
                break;
            }

            foreach (var p in nextPage.Payments)
            {
                if (p.PaymentId == Guid.Empty || !seenPaymentIds.Add(p.PaymentId))
                {
                    throw CursorFailure();
                }
                allPayments.Add(p);
            }

            if (nextPage.Payments.Count < size)
            {
                break;
            }
        }

        return firstPage with { Payments = allPayments };
    }

    public async Task<SupplierAccountWorkspaceDto> GetSupplierHistoryPageAsync(Guid supplierId, int pageSize,
        SupplierHistoryCursor cursor, CancellationToken cancellationToken = default)
    {
        ValidateCursor(cursor.OccurredAt.HasValue, cursor.CreatedAt.HasValue, cursor.EntryId.HasValue,
            "Statement cursor requires all three fields.");
        ValidateCursor(cursor.PaymentAt.HasValue, cursor.PaymentId.HasValue, cursor.PaymentId.HasValue,
            "Payment cursor requires date and identity.");
        ValidateCursor(cursor.RefundAt.HasValue, cursor.RefundId.HasValue, cursor.RefundId.HasValue,
            "Refund cursor requires date and identity.");
        ValidateCursor(cursor.ProductName is not null, cursor.ProductId.HasValue, cursor.ProductId.HasValue,
            "Product cursor requires name and identity.");
        var size = Math.Clamp(pageSize, 1, 200);
        var path = $"/api/suppliers/{supplierId:D}/workspace?pageSize={size}";
        if (cursor.OccurredAt.HasValue)
        {
            path += $"&beforeOccurredAt={EscapeDate(cursor.OccurredAt.Value)}&beforeCreatedAt={EscapeDate(cursor.CreatedAt!.Value)}&beforeEntryId={cursor.EntryId:D}";
        }
        if (cursor.PaymentAt.HasValue)
        {
            path += $"&beforePaymentPaidAt={EscapeDate(cursor.PaymentAt.Value)}&beforePaymentId={cursor.PaymentId:D}";
        }
        if (cursor.RefundAt.HasValue)
        {
            path += $"&beforeRefundReceivedAt={EscapeDate(cursor.RefundAt.Value)}&beforeRefundId={cursor.RefundId:D}";
        }
        if (cursor.ProductName is not null)
        {
            path += $"&beforeProductName={Uri.EscapeDataString(cursor.ProductName)}&beforeProductId={cursor.ProductId:D}";
        }
        var page = await apiClient.GetAsync<SupplierAccountWorkspaceDto>(path, cancellationToken);
        var statement = page.Statement.OrderByDescending(x => x.OccurredAt)
            .ThenByDescending(x => x.CreatedAt).ThenByDescending(x => x.EntryId).ToArray();
        ValidatePage(statement, size, [], x => x.EntryId);
        ValidatePage(page.Payments, size, [], x => x.PaymentId);
        ValidatePage(page.Refunds, size, [], x => x.RefundId);
        ValidatePage(page.SuppliedProducts, size, [], x => x.ProductId);
        if (cursor.OccurredAt.HasValue && statement.Any(x => (x.OccurredAt, x.CreatedAt, x.EntryId)
            .CompareTo((cursor.OccurredAt.Value, cursor.CreatedAt!.Value, cursor.EntryId!.Value)) >= 0) ||
            cursor.PaymentAt.HasValue && page.Payments.Any(x => (x.PaidAt, x.PaymentId).CompareTo((cursor.PaymentAt.Value, cursor.PaymentId!.Value)) >= 0) ||
            cursor.RefundAt.HasValue && page.Refunds.Any(x => (x.ReceivedAt, x.RefundId).CompareTo((cursor.RefundAt.Value, cursor.RefundId!.Value)) >= 0) ||
            cursor.ProductId.HasValue && page.SuppliedProducts.Any(x => x.ProductId == cursor.ProductId.Value))
        {
            throw CursorFailure();
        }
        return page with { Statement = statement };
    }

    private static string EscapeDate(DateTimeOffset value) => Uri.EscapeDataString(value.ToString("O", CultureInfo.InvariantCulture));

    public async Task CreateSupplierPaymentAsync(Guid supplierId, decimal amount, SupplierPaymentPurpose purpose,
        SupplierSettlementMethod method, Guid clientOperationId, string? externalReference, string? note,
        CancellationToken cancellationToken = default)
    {
        var command = new CreateSupplierPaymentCommand(supplierId, amount, purpose, method, Guid.Empty,
            RequireOperation(clientOperationId), externalReference, note);
        await apiClient.PostAsync<CreateSupplierPaymentCommand, SupplierPaymentResult>(
            "/api/finance/supplier-payment", command, cancellationToken);
    }

    public async Task ReverseSupplierPaymentAsync(Guid paymentId, string reason, Guid clientOperationId,
        CancellationToken cancellationToken = default) =>
        _ = await apiClient.PostAsync<ReverseRequest, bool>(
            $"/api/finance/supplier-payment/{paymentId:D}/reverse",
            new(clientOperationId, reason), cancellationToken);

    public async Task CreateSupplierRefundAsync(Guid supplierId, decimal amount, SupplierSettlementMethod method,
        Guid clientOperationId, string? externalReference, string? note, CancellationToken cancellationToken = default)
    {
        var command = new CreateSupplierRefundCommand(supplierId, amount, method, Guid.Empty,
            RequireOperation(clientOperationId), ExternalReference: externalReference, Note: note);
        await apiClient.PostAsync<CreateSupplierRefundCommand, SupplierRefundResult>(
            "/api/finance/supplier-refund", command, cancellationToken);
    }

    public async Task ReverseSupplierRefundAsync(Guid refundId, string reason, Guid clientOperationId,
        CancellationToken cancellationToken = default) =>
        _ = await apiClient.PostAsync<ReverseRequest, bool>(
            $"/api/finance/supplier-refund/{refundId:D}/reverse",
            new(clientOperationId, reason), cancellationToken);

    public Task<WarrantyDashboardDto> GetWarrantyDashboardAsync(string? search, int pageSize = 100,
        DateTimeOffset? beforeCreatedAt = null, Guid? beforeWorkId = null,
        CancellationToken cancellationToken = default, WarrantyWorkKind? beforeWorkKind = null)
    {
        ValidateCursor(beforeCreatedAt.HasValue, beforeWorkId.HasValue, beforeWorkKind.HasValue,
            "Warranty dashboard cursor requires beforeCreatedAt, beforeWorkKind, and beforeWorkId together.");
        var path = $"/api/warranty/dashboard?pageSize={Math.Clamp(pageSize, 1, 200)}&search={Uri.EscapeDataString(search ?? string.Empty)}";
        if (beforeCreatedAt.HasValue)
        {
            path += $"&beforeCreatedAt={Uri.EscapeDataString(beforeCreatedAt.Value.ToString("O", CultureInfo.InvariantCulture))}" +
                    $"&beforeWorkKind={beforeWorkKind}&beforeWorkId={beforeWorkId:D}";
        }
        return apiClient.GetAsync<WarrantyDashboardDto>(path, cancellationToken);
    }

    public Task<IReadOnlyList<WarrantyEventDto>> GetWarrantyClaimTimelineAsync(Guid claimId,
        CancellationToken cancellationToken = default) =>
        apiClient.GetAsync<IReadOnlyList<WarrantyEventDto>>($"/api/warranty/claims/{claimId:D}/timeline", cancellationToken);

    public Task<IReadOnlyList<WarrantyClaimIntakeRowDto>> SearchWarrantyClaimIntakeAsync(string search,
        CancellationToken cancellationToken = default) =>
        apiClient.GetAsync<IReadOnlyList<WarrantyClaimIntakeRowDto>>(
            $"/api/warranty/search?query={Uri.EscapeDataString(search)}", cancellationToken);

    public Task<Guid> CreateWarrantyClaimAsync(Guid customerId, Guid saleId, Guid? supplierId, Guid productId,
        decimal quantity, Guid saleItemId, string faultDescription, IReadOnlyList<WarrantyClaimUnitInput>? units,
        Guid clientOperationId, CancellationToken cancellationToken = default) =>
        apiClient.PostAsync<CreateWarrantyClaimCommand, Guid>("/api/warranty/claims",
            new(customerId, saleId, supplierId, Guid.Empty,
                [new WarrantyClaimItemInput(productId, quantity, faultDescription, saleItemId, units)],
                RequireOperation(clientOperationId)), cancellationToken);

    public Task BeginWarrantyClaimReviewAsync(Guid claimId, Guid clientOperationId, string? note,
        CancellationToken cancellationToken = default) => PostActionAsync($"/api/warranty/claims/{claimId:D}/review", clientOperationId, note, cancellationToken);
    public Task SendWarrantyClaimToSupplierAsync(Guid claimId, Guid clientOperationId, string? note,
        CancellationToken cancellationToken = default) => PostActionAsync($"/api/warranty/claims/{claimId:D}/send-to-supplier", clientOperationId, note, cancellationToken);
    public Task MarkWarrantySupplierProcessingAsync(Guid claimId, Guid clientOperationId, string? note,
        CancellationToken cancellationToken = default) => PostActionAsync($"/api/warranty/claims/{claimId:D}/supplier-processing", clientOperationId, note, cancellationToken);

    public async Task ResolveWarrantyClaimAsync(Guid claimId, WarrantyResolutionType resolution,
        Guid clientOperationId, string? note, CancellationToken cancellationToken = default) =>
        _ = await apiClient.PostAsync<ResolutionRequest, bool>($"/api/warranty/claims/{claimId:D}/resolution",
            new(clientOperationId, resolution, note), cancellationToken);

    public async Task ReceiveCustomerWarrantyReplacementAsync(Guid claimId,
        IReadOnlyList<CustomerWarrantyReplacementUnitInput> units, Guid clientOperationId, string? note,
        CancellationToken cancellationToken = default) =>
        _ = await apiClient.PostAsync<CustomerReplacementRequest, bool>($"/api/warranty/claims/{claimId:D}/replacement-receipt",
            new(clientOperationId, units, note), cancellationToken);

    public Task HandoverWarrantyClaimAsync(Guid claimId, Guid clientOperationId, string? note,
        CancellationToken cancellationToken = default) => PostActionAsync($"/api/warranty/claims/{claimId:D}/handover", clientOperationId, note, cancellationToken);
    public Task CancelWarrantyClaimAsync(Guid claimId, Guid clientOperationId, string? note,
        CancellationToken cancellationToken = default) => PostActionAsync($"/api/warranty/claims/{claimId:D}/cancel", clientOperationId, note, cancellationToken);

    public Task<Guid> SendShopStockWarrantyAsync(Guid productId, InventoryBucket sourceBucket, decimal quantity,
        Guid supplierId, Guid? sourcePurchaseItemId, string faultDescription, Guid clientOperationId,
        IReadOnlyCollection<Guid>? inventoryUnitIds, CancellationToken cancellationToken = default) =>
        apiClient.PostAsync<SendShopWarrantyRequest, Guid>("/api/warranty/shop-stock/send",
            new(productId, sourceBucket, quantity, supplierId, sourcePurchaseItemId, faultDescription,
                RequireOperation(clientOperationId), inventoryUnitIds), cancellationToken);

    public async Task ReceiveShopStockWarrantyAsync(Guid caseId, WarrantyResolutionType resolution,
        IReadOnlyCollection<Guid>? originalInventoryUnitIds, IReadOnlyList<ReplacementSerializedUnitInput>? replacementUnits,
        string? note, Guid clientOperationId, decimal? supplierCreditAmount, string? supplierReference,
        CancellationToken cancellationToken = default) =>
        _ = await apiClient.PostAsync<ReceiveShopWarrantyRequest, bool>($"/api/warranty/shop-stock/{caseId:D}/receive",
            new(resolution, RequireOperation(clientOperationId), originalInventoryUnitIds, replacementUnits,
                note, supplierCreditAmount, supplierReference), cancellationToken);

    private async Task PostActionAsync(string path, Guid operationId, string? note, CancellationToken cancellationToken) =>
        _ = await apiClient.PostAsync<ActionRequest, bool>(path, new(RequireOperation(operationId), note), cancellationToken);

    private static Guid RequireOperation(Guid operationId) => operationId == Guid.Empty
        ? throw new InvalidOperationException("ClientOperationId is required for this operation.")
        : operationId;

    private static void ValidatePage<T>(IReadOnlyList<T> rows, int size, HashSet<Guid> seen, Func<T, Guid> identity)
    {
        if (rows.Count > size)
        {
            throw CursorFailure();
        }
        foreach (var row in rows)
        {
            var id = identity(row);
            if (id == Guid.Empty || !seen.Add(id))
            {
                throw CursorFailure();
            }
        }
    }

    private static DesktopApiException CursorFailure() => new("gateway.cursor_invalid",
        "Supplier history pagination did not advance safely. Refresh the workspace; incomplete history was not displayed.");

    private static void ValidateCursor(bool first, bool second, bool third, string message)
    {
        if (first != second || second != third)
        {
            throw new ArgumentException(message);
        }
    }

    private sealed record ActionRequest(Guid ClientOperationId, string? Note);
    private sealed record ReverseRequest(Guid ClientOperationId, string Reason);
    private sealed record ResolutionRequest(Guid ClientOperationId, WarrantyResolutionType Resolution, string? Note);
    private sealed record CustomerReplacementRequest(Guid ClientOperationId, IReadOnlyList<CustomerWarrantyReplacementUnitInput> Units, string? Note);
    private sealed record SendShopWarrantyRequest(Guid ProductId, InventoryBucket SourceBucket, decimal BaseQuantity,
        Guid SupplierId, Guid? SourcePurchaseItemId, string FaultDescription, Guid ClientOperationId, IReadOnlyCollection<Guid>? InventoryUnitIds);
    private sealed record ReceiveShopWarrantyRequest(WarrantyResolutionType Resolution, Guid ClientOperationId,
        IReadOnlyCollection<Guid>? OriginalInventoryUnitIds, IReadOnlyList<ReplacementSerializedUnitInput>? ReplacementUnits,
        string? Note, decimal? SupplierCreditAmount, string? SupplierReference);
}
