# Edge Retails - Phase 11-13 Complete Architecture, Implementation Roadmap and Next-Chat Handoff

**Date:** 2026-09-28  
**Product:** Edge Retails / Edge Retails Electronics  
**Vertical:** Electrical / Electronics Retail POS  
**Target workspace:** `C:\Users\muham\OneDrive\Desktop\Point of Sale`  
**Purpose:** Standalone continuation document for the next ChatGPT / Antigravity session.  
**Status:** Planning and architecture handoff. Phase 11-13 architecture is frozen at design level, not implementation-certified.  

---

# 0. How to Use This File in the Next Chat

This file is intended to carry the current conversation forward when chat context is exhausted.

The next agent must:

1. Read this entire file before proposing implementation.
2. Read the current canonical architecture and roadmap files from the live workspace.
3. Verify the live code before treating any historical status as current fact.
4. Preserve Phases 1-10 and all previously closed work unless a concrete regression, authority conflict, security defect, or production blocker proves reopening is necessary.
5. Implement Phase 11 first, then Phase 12, then Phase 13 certification.
6. Never mark a gate PASS from documentation alone.
7. Never treat BLOCKED, NOT RUN, SKIPPED, ASSUMED, mock-only, or unit-only evidence as production certification.
8. Do not redesign Edge Retails V1 as multi-shop, LAN, multi-workstation, or cloud-business-authority software.
9. Do not reintroduce a direct Desktop-to-database production authority path.
10. Do not automatically start the next phase after closing the current one. Produce evidence and wait for explicit progression.

Recommended first instruction in the next chat:

```text
Read this handoff completely. Then perform a read-only live-workspace reconciliation against the current canonical architecture, roadmap, migrations, tests and source. Do not implement until you have produced a bounded Phase 11 delta list and confirmed that this handoff does not conflict with newer live authority.
```

---

# 1. Source Basis and Authority

This handoff is based on the following current project artifacts and forensic evidence discussed in the preceding session:

## 1.1 Current canonical / high-authority project sources

- `Edge_Retails_FINAL_FROZEN_CANONICAL_ARCHITECTURE_2026-09-25.md`
- `Edge_Retails_Consolidated_Final_Implementation_Roadmap_2026-09-25.md`
- `Edge_Retails_Final_Single_Machine_Architecture_and_Implementation_Handoff_2026-09-25.md`
- `docs\Architecture_Authority_Manifest.json`
- `docs\Edge_Retails_Final_Architecture_Report_v1.md`
- `docs\Frontend_Backend_Forensic_Verification_2026-09-22.md`
- `docs\Sprint9_Master_Implementation_Roadmap.md`

## 1.2 Supporting / historical architecture sources

These may contain valid domain details but must not override newer runtime authority:

- `Edge_Retails_Backend_Assembled_Final_v2.md`
- `Edge_Retails_Product_Inventory_Lifecycle_Audit_Roadmap_2026-09-25.md`
- historical sprint and certification documents

Important conflict already identified:

```text
OLDER BACKEND V2 RUNTIME
WPF / IApplicationGateway directly into Application
No local HTTP API

CURRENT AUTHORITATIVE RUNTIME
EdgeRetails.Desktop
    -> 127.0.0.1:7150
    -> EdgeRetails.Server
    -> Application / Domain
    -> Infrastructure
    -> PostgreSQL
```

The old direct-WPF runtime is historical and must not be reintroduced.

## 1.3 Forensic audits used to derive Phase 11-13

Two independent whole-project audits were reconciled:

1. Sol xhigh forensic audit, represented by the report `EDGE_RETAILS_ENTIRE_PROJECT_FORENSIC_AUDIT_2026-09-28.md` / associated pasted audit.
2. Gemini 3.8 High forensic audit, represented by the later whole-project forensic audit report.

The value of using both audits is convergence. Findings reproduced independently by both audits receive high confidence. Findings unique to one audit must be checked against canonical architecture and live code before implementation.

---

# 2. Naming and Roadmap Continuity

The 2026-09-25 consolidated canonical roadmap is written as six large macro program phases:

```text
Phase 1 - Authority, Runtime Rebase, Core Security + Product / Physical Identity
Phase 2 - Shop Server API Parity & Backend Hardening
Phase 3 - Desktop Cutover, POS UX & Local Production Operations
Phase 4 - Licensing V2, Vendor Backend & Protected Signer
Phase 5 - Admin Portal & Commercial Operations Cutover
Phase 6 - Hostile Production Certification & Release Closure
```

The current conversation also uses a longer planning sequence in which prior work is treated as Phases 1-10 and the new audit-driven extension is named Phases 11-13.

**Do not renumber or rewrite older source documents simply to make the labels match.** For continuity in this handoff:

```text
Phases 1-10
= protected prior roadmap / implementation scope

Phase 11
= new Business Integrity + Inventory Provenance architecture

Phase 12
= new Operation Identity + Replay / Recovery architecture

Phase 13
= final whole-system hostile re-certification and V1 authority closure
```

The Phase 11-13 labels are the user-approved continuation labels for the new work.

---

# 3. Permanent V1 Product Boundary

Edge Retails V1 is a **single-shop, single-primary-installation, single-machine commercial POS**.

Final shop runtime authority:

```text
EdgeRetails.Desktop
        |
        | loopback only
        v
127.0.0.1:7150
        |
        v
EdgeRetails.Server
        |
        v
Application / Domain
        |
        v
Infrastructure
        |
        v
PostgreSQL
```

Commercial/control-plane systems may exist separately for licensing, Vendor backend and Admin Portal, but they do not become the operational shop business database authority.

## 3.1 Explicitly out of V1

Do not reintroduce:

```text
multi-shop shared operational DB
ShopId tenant redesign for inventory tables
secondary shop workstation architecture
LAN workstation discovery
seat attach/detach
terminal quotas
MaxTerminals commercial limits
multi-machine cash drawer authority
remote workstation updater
secondary installer topology
cloud-authoritative shop sales/inventory
```

One Commercial License has one active approved shop installation.

### Gemini multi-shop F03 disposition

Gemini reported a multi-shop tenant-isolation concern for `inventory_item_balances`.

Disposition:

```text
NOT APPLICABLE TO EDGE RETAILS V1
```

Reason: V1 is not a shared multi-shop operational database product. Do not create a tenant-schema migration merely to satisfy this finding.

This does **not** remove Sol's separate F03, which concerns exact-unit quantity validation and selected-unit lot/cost provenance.

---

# 4. Frozen Product and Physical Identity Grammar

Preserve the deterministic identity chain:

```text
Supplier
    -> SupplierCode

Company
    -> CompanyCode

Category
    -> CategorySymbol

Model
    -> ModelCode

Product
    -> ProductCode

SupplierProduct
    -> Supplier-specific sequence authority

Physical item / tracked physical pack
    -> PhysicalSequence
    -> TrackingCode / Physical SKU
```

Canonical example:

```text
SupplierCode: AB1
CompanyCode:  PK
Category:     F
ModelCode:    DLX56
ProductCode:  PKF-DLX56
TrackingCode: AB1-PKF-DLX56-000027
```

Rules:

- Product remains supplier-independent.
- SupplierProduct owns supplier-product provenance and physical sequence authority.
- TrackingCode is human-readable physical identity, not relational truth.
- Relational IDs / foreign keys remain authoritative.
- Do not parse TrackingCode to reconstruct business relationships.
- Serial and IMEI remain manufacturer identity fields, separate from shop physical TrackingCode.
- Once committed, SupplierCode, CompanyCode, CategorySymbol, committed ProductCode, physical sequence and TrackingCode are never reused.
- Reprint always reuses committed identity.

---

# 5. Global No-Reopen Rules

Do not restart or broadly rewrite previously stable areas simply because Phase 11-13 exists.

Protected unless concrete evidence proves a defect:

```text
historical completed sprints
existing exact-unit relational provenance
existing sale/return unit links
Supplier Khata lifecycle
Warranty lifecycle
Thaka domain model
inventory movement model
business idempotency foundations
PostgreSQL lock strategy
stable purchasing provenance
stable Product / Inventory authority separation
```

Allowed reopening requires at least one of:

```text
specific reproducible regression
architecture contradiction
missing authority
security gap
production blocker
forensic defect with live-code evidence
```

Strategy:

```text
preserve stable domain
correct authority / integrity gaps
prove with real evidence
certify
```

Not:

```text
rewrite the POS again
```

---

# 6. No-False-Green Certification Policy

These meanings are frozen:

```text
BLOCKED_ENVIRONMENT != PASS
NOT RUN             != PASS
SKIPPED             != PASS
ASSUMED             != PASS
PARTIAL             != PASS
DOCUMENTED          != IMPLEMENTED
UNIT PASS           != POSTGRESQL PASS
MOCK DEVICE PASS    != REAL HARDWARE PASS
BACKUP CREATED      != RESTORE PASS
BUILD GREEN         != PRODUCTION CERTIFIED
PREVIOUS PASS       != CURRENT CHECKPOINT PASS
```

A roadmap item marked "covered" means planned or represented by scope. It does not mean implemented or certified.

A certification phase must record the provider and environment used. For database-sensitive correctness, real isolated PostgreSQL evidence is required.

Never run destructive integration tests against the operational shop database.

---

# 7. Reconciled Forensic Findings Register

The following register is the merged working truth from the two audits.

## F00 - Release build failure

**Confidence:** confirmed in Sol audit at that checkpoint.  
**Ownership:** prior runtime/build scope, Phase 13 final verification.  
**Issue:** `DesktopApiClient.cs` missing `System.Net.Http` caused Release compile failures at that audit time.  
**Rule:** verify current live tree. A later build may already have fixed it. Do not assume either state.

## F01 - Stock adjustment mode arithmetic

**Severity:** Critical.  
**Owner:** Phase 11.  
**Problem:** Physical/absolute count and relative delta are stored as different modes, but current arithmetic was reported to apply supplied quantity as delta in both cases. Target zero was rejected.

Required authority:

```text
RelativeDelta:
After = Before + RequestedDelta

AbsolutePhysicalCount:
AppliedDelta = ObservedCount - Before
After = ObservedCount
```

Zero physical count is valid.

## F02 - Exact-unit scrap valuation double multiplication

**Severity:** Critical.  
**Owner:** Phase 11.  
**Problem:** selected unit costs are summed and then an allocator multiplies by quantity again.

Required authority:

```text
ExactTotalCost = SUM(selected exact-unit carrying costs)
```

Remove the exact total once.

## Sol-F03 - Exact-unit quantity and source-lot provenance

**Severity:** High.  
**Owner:** Phase 11.  
**Problem:** quantity may be rounded before whole-number exact-unit validation, and generic FIFO lot transfer cannot target the actual selected exact units' source lots.

Required rules:

- validate original exact-unit quantity before rounding;
- exact-unit quantity must equal selected distinct physical unit count;
- selected exact physical units must mutate their actual source provenance / carrying-cost authority;
- an exact-unit mutation must not silently affect an unrelated generic FIFO lot.

## Gemini-F03 - Multi-shop tenant isolation

**Disposition:** NOT APPLICABLE to V1.  
**Do not implement ShopId inventory tenant redesign.**

## F04 - Thaka ProductUnit and duplicate exact-unit integrity

**Severity:** Critical.  
**Owner:** Phase 11.  
**Problem:** ProductUnit factor/price handling is inconsistent and exact-unit uniqueness was only enforced within each line, allowing the same InventoryUnit across different command lines.

Required rules:

- apply `ProductUnit.FactorToBaseUnit` consistently;
- build one command-wide set of exact InventoryUnit IDs before any mutation;
- reject duplicates across all lines;
- preserve price/quantity authority server-side;
- no partial mutation before all lines are validated.

## F05 - Cross-type ClientOperationId collision

**Severity:** High.  
**Owner:** Phase 12.  
**Problem:** business handlers check their own tables while the shared outcome ledger can encounter an existing succeeded operation without proving same type/payload/actor.

Required authority:

```text
ClientOperationId
+ OperationType
+ PayloadFingerprintVersion
+ PayloadHash
+ durable execution context
= immutable operation claim
```

## F06 - Committed sale recovery / terminal-context mismatch

**Severity:** High.  
**Owner:** Phase 12.  
**Problem:** committed outcome can be written without consistent terminal context, while status lookup validates terminal and may return 403 after response loss.

Required rule: trusted execution context captured at operation claim time must be used consistently for recovery.

## F07 - Draft conversion replay

**Severity:** High.  
**Owner:** Phase 12.  
**Problem:** after draft conversion commits, same operation replay may hit `draft_not_open` before recovering original sale.

Required order:

```text
check durable operation outcome first
then validate draft state for a genuinely new intent
```

## F08 - Session / PIN / loopback security gaps

**Owner:** existing security/runtime phase. Phase 13 verifies closure.  
**Do not dump into Phase 11/12.**

Verify:

- real session expiry / revocation behavior;
- durable PIN abuse control;
- LocalClient / installation binding;
- loopback-only production Shop Server;
- fail-closed permissions.

## F09 - Desktop dual authority

**Owner:** existing Desktop cutover/runtime phase. Phase 13 verifies closure.

Final production Desktop must not resolve DbContext, repositories, or direct DB-backed business mutation services.

## F10 - Commercial Exchange vs Warranty eligibility inconsistency

**Severity:** High.  
**Owner:** Phase 11.  
**Problem:** normal Sale Return applies warranty eligibility checks but Commercial Exchange alternate return path lacks equivalent protection.

Required design: one shared exact-unit return eligibility policy for the return side of both flows.

## F11 - Scheduled backup no-op

**Owner:** existing backup/operations phase. Phase 13 verifies closure.

The scheduled job must create and verify a real backup artifact rather than only logging and advancing timestamps.

## F12 - Net profit omits recognized inventory losses

**Owner:** Phase 11.

Canonical formula:

```text
Net Local Sales
= Gross Local Sales - Returns / Exchange Credits

Gross Profit
= Net Local Sales - Net Local COGS

Net Profit
= Gross Profit - Operating Expenses - Recognized Inventory Losses
```

Avoid double-counting normal Sale COGS as inventory loss.

## F13 - Host timezone / business date authority

**Owner:** Phase 11.

Use configured Shop Time Zone for business-day boundaries. System timestamps remain UTC. Host Windows timezone is not business authority.

## F14 - Purchase defaults to immediate stock intake

**Owner:** existing purchasing/receiving scope. Phase 13 verifies closure.

Purchase commercial record and physical receiving must remain distinct where the canonical workflow requires one-product-at-a-time receiving.

## F15 - Outbox producer / lease reliability

**Owner:** existing operations/printing reliability scope. Phase 13 verifies closure.

Required certification includes real producer wiring, lease/fencing behavior and crash recovery for post-commit physical effects.

## F16 - Backup key version / rotation restore

**Owner:** existing backup/security scope. Phase 13 verifies closure.

Backup manifest must support recovery after key rotation according to final architecture.

## F17 - API lifecycle parity gaps

**Owner:** existing Shop Server API parity phase. Phase 13 verifies closure.

Handlers existing in-process are not enough. Required Desktop production workflows need authoritative Server routes/contracts/auth/errors.

## F18 - LocalAppData / startup / maintenance authority split

**Owner:** existing runtime/operations phase. Phase 13 verifies closure.

Current target state root:

```text
%ProgramData%\EdgeRetails\
    Authority\
    Runtime\
    Recovery\
    Backups\
```

Startup / maintenance state must have one production authority.

## F19 - Legacy MaxTerminals

**Owner:** existing licensing/runtime cleanup. Phase 13 verifies closure.

V1 is single approved installation, not a seat/terminal-quota product.

---

# 8. Final Tracking Architecture for Phase 11

## 8.1 Core principle: tracking and selling unit are orthogonal

```text
Tracking behavior
= HOW physical inventory is represented and traced

ProductUnit
= WHAT unit is purchased / sold / issued
```

Do not encode selling units as tracking modes.

Examples:

```text
Electrical wire
Tracking behavior: Length
Units: Meter, Foot, Roll / Coil

Switch
Tracking behavior: Quantity or Container/Pack
Units: Piece, Box

Electrical tape
Tracking behavior: Quantity or Container/Pack
Units: Piece / Roll, Pack / Box

Fan
Tracking behavior: IndividualPiece
Units: Piece, Carton where configured

Serial-controlled electrical/electronic appliance
Tracking behavior: Serialized / exact physical item
Unit: Piece
```

"Cheap" is not a technical tracking mode. Tracking choice follows traceability requirement, physical handling, warranty/provenance need and operational cost.

## 8.2 Business tracking taxonomy

The current architecture recognizes these business behaviors:

```text
Quantity
Length
IndividualPiece
Container / Pack
Serialized manufacturer identity where retained
```

The live enum/type names must be inspected before any schema change. Do not rename a stable implementation only to make it visually match this document.

### Quantity

- base quantity / movement / lot authority;
- no fake exact unit per piece;
- decimal rules follow product/unit policy;
- stock truth is base quantity and movement ledger.

### Length

For wire/cable:

- no per-meter InventoryUnit;
- base quantity may be Meter, Foot, etc.;
- ProductUnit conversion handles full Roll / Coil;
- fractional quantity is allowed according to configured precision/step;
- cost remains non-exact-unit costing unless explicitly changed by accounting authority.

Example:

```text
BaseUnit = Meter
Roll FactorToBaseUnit = 100

Sell 1 Roll
=> deduct 100 base meters
```

The cashier should not manually type `100m` when the selected ProductUnit is Roll.

### IndividualPiece

- one shop physical identity per physical piece;
- one TrackingCode per InventoryUnit;
- Serial / IMEI may be null if not required;
- exact selection required before exact-unit mutation.

### Serialized

- exact physical unit tracking;
- manufacturer Serial and/or IMEI required by product policy;
- TrackingCode remains shop physical identity;
- manufacturer identity does not replace relational provenance.

### Container / Pack

This is the newly formalized physical sub-ledger behavior.

A tracked Box / Pack / Coil can receive one physical TrackingCode while contained pieces or length remain base quantity rather than child InventoryUnits.

Example:

```text
Switch Box A
TrackingCode = <physical pack identity>
InitialBaseQuantity = 50 pieces
RemainingBaseQuantity = 50

Sell 7 pieces
RemainingBaseQuantity = 43
```

Do **not** create 50 child exact InventoryUnits merely because the box itself is tracked.

---

# 9. Pack / Container Physical Sub-Ledger Authority

Historical backend design already contained `stock_packs` and `pack_allocations`. Phase 11 promotes the invariant into current authority while rejecting that old document's obsolete runtime topology.

## 9.1 Physical pack states

Conceptual states / kinds:

```text
SEALED
OPEN
CONSUMED
LOOSE_SEGMENT where required
QUARANTINED / non-sellable states only if consistent with live domain
```

Do not add states merely for aesthetics. Map to live domain conventions.

## 9.2 Conceptual entity

Exact names are not frozen until live code review, but the model must represent:

```text
TrackedPack
- Id
- ProductId
- SupplierProductId / source provenance
- TrackingCode where physically labelled
- InitialBaseQuantity
- RemainingBaseQuantity
- state / pack kind
- SourcePurchaseItemId
- source lot relationship where appropriate
- Version / concurrency token
```

## 9.3 Allocation ledger

A pack allocation must identify how much base quantity a business operation consumed or restored from a physical pack.

Conceptual fields:

```text
PackAllocation
- PackId
- BusinessReference / operation source
- AllocationType
- BaseQuantity
- CreatedAtUtc
```

Possible consumers:

```text
Sale
Sale Return
Thaka Issue
Thaka Reversal
Adjustment
Stocktake correction
Purchase Return
Condition / wastage where physically meaningful
```

## 9.4 Core invariant

```text
SUM(active pack RemainingBaseQuantity)
=
corresponding pack-tracked inventory BaseQuantity
```

This is a physical sub-ledger invariant.

It does not replace Inventory Movement truth.

## 9.5 Default consumption order

```text
existing OPEN / LOOSE stock first
then oldest eligible SEALED pack
then next eligible pack
```

If the operator scans a specific valid pack, backend may use that explicit selection according to business rules.

## 9.6 Cross-pack sale / issue

Example:

```text
Pack A remaining = 4
Pack B remaining = 50
Required sale = 10

Allocation:
A -> 4
B -> 6

Result:
A -> 0 / CONSUMED
B -> 44 / OPEN
```

One business line may therefore have multiple physical pack allocations.

## 9.7 Wire / cable tracked coil

Wire may remain Length stock while a physical coil is additionally tracked.

Example:

```text
Coil A = 100m
Remaining = 17m
Coil B = 100m sealed

Loose sale of 20m:
17m from open Coil A
3m from Coil B
```

A whole Roll / Coil sale may require an eligible sealed pack where configured.

A returned cut length may be represented as a loose segment rather than magically resealing a coil.

## 9.8 Costing is separate from pack provenance

Do not accidentally change accounting method merely because a physical pack is tracked.

Existing design intent:

```text
Quantity / Length
-> Moving Weighted Average

Exact / Serialized physical units
-> actual individual carrying cost
```

Therefore:

```text
Pack allocation
= physical provenance

Cost state / lot / exact-unit cost authority
= financial valuation authority
```

They must reconcile but are not automatically the same algorithm.

---

# 10. Phase 11 - Business Integrity + Inventory Provenance

## 10.1 Mission

Phase 11 permanently closes the business-integrity findings exposed by forensic audit and completes the new physical tracking architecture without rewriting stable business domains.

Phase 11 answers:

```text
WHAT should happen to stock, physical identity, cost, provenance and reporting?
```

It does not own global retry/recovery semantics. That is Phase 12.

## 10.2 Phase 11 owned findings

```text
F01
F02
Sol-F03
F04
F10
F12
F13
plus Container/Pack completion
```

## 10.3 Phase 11 internal workstreams

```text
11A - Authority & Live-Code Reconciliation
11B - Tracking Policy + ProductUnit Freeze
11C - Pack / Container Physical Sub-Ledger
11D - Stock Adjustment Semantics
11E - Exact-Unit Lot / Cost / Condition Integrity
11F - Thaka Material Integrity
11G - Return / Exchange Eligibility Authority
11H - Financial Reporting + Shop Time
11I - Cross-Domain Reconciliation & Real PostgreSQL Certification
```

These are workstreams inside Phase 11, not new macro phases.

---

# 11. Phase 11A - Authority & Live-Code Reconciliation

## Goal

Before editing, prove how the live implementation represents:

- TrackingMode / tracking policy;
- ProductUnit and FactorToBaseUnit;
- InventoryUnit;
- Inventory lots / balances / movements;
- current exact-unit costing;
- stock adjustment modes;
- condition / scrap handlers;
- Thaka issue lines;
- Sale Return and Commercial Exchange return side;
- reporting formulas;
- shop settings / timezone;
- any existing pack / container implementation.

## Mandatory read targets

At minimum inspect current live equivalents of:

```text
Domain/Catalog tracking models
Domain/Inventory models
CatalogModels / ProductUnit
InventoryUnit
stock balance / lot / movement entities
StockAdjustmentHandlers
InventoryConditionHandlers
InventoryCostAllocator
ThakaHandlers
SaleReturnHandler
CommercialExchangeHandler
BusinessOperationsReadServices
stocktake handlers
receiving handlers
EF configurations / migrations / snapshot
existing tests for exact-unit / inventory / Thaka / returns
```

## Deliverable

A bounded delta matrix:

```text
Requirement
Current implementation
Already correct?
Gap
Files affected
Migration required?
Test required?
Risk
```

No implementation before this delta matrix is produced.

---

# 12. Phase 11B - Tracking Policy + ProductUnit Freeze

## Goals

1. Freeze the live representation of Quantity, Length, IndividualPiece, Serialized and Container/Pack behaviors.
2. Preserve ProductUnit as a separate axis.
3. Preserve base quantity as stock truth.
4. Prevent fake exact identities for quantity/length contents.

## Required invariants

```text
EnteredQuantity * FactorToBaseUnit = BaseQuantity
```

subject to precision rules.

Exact-unit modes additionally require:

```text
BaseQuantity == count(distinct selected exact physical units)
```

Length may accept fractional base quantity according to ProductUnit precision / step.

Exact physical item count must be whole before any rounding.

## Tests

- Meter sale with fractional quantity.
- Full roll sale through ProductUnit factor.
- Different wire products with different roll factors.
- Quantity piece sale.
- exact-unit quantity mismatch.
- IndividualPiece without Serial/IMEI.
- Serialized with required Serial/IMEI.
- ProductUnit conversion in Purchase, Sale, Return, Thaka and Stocktake.

---

# 13. Phase 11C - Pack / Container Physical Sub-Ledger

## Goals

Implement or complete the physical sub-ledger for tracked boxes / packs / coils.

## Design requirements

- one physical pack identity where configured;
- contained base quantity without child exact units;
- initial and remaining base quantity;
- deterministic pack state;
- source purchase provenance;
- optimistic/pessimistic concurrency according to existing lock strategy;
- movement-backed stock remains canonical accounting truth;
- pack allocations reconcile to stock quantity.

## Required flows

### Receiving

```text
receive Product
-> resolve ProductUnit / BaseQuantity
-> create inventory movement / lot / cost state
-> create tracked physical pack(s) when policy requires
-> assign final physical TrackingCode after authority/sequence allocation
-> commit
-> label becomes printable after commit
```

### Partial sale

```text
open pack
-> decrement pack RemainingBaseQuantity
-> write pack allocation
-> write normal Sale / movement / cost effects
```

### Cross-pack sale

Consume remainder from current open pack, then next eligible pack in the same transaction.

### Whole-pack sale

Where configured, require eligible sealed pack.

### Return

Preserve original sale allocation provenance where physically meaningful. Do not blindly add quantity without reconciling pack state.

### Purchase Return

Whole-pack purchase return may require a sealed eligible source-purchase pack.

### Stocktake

Compare both total BaseQuantity and physical pack composition where pack tracking is enabled.

### Wastage / cut wire

Represent physical loss and recognized inventory loss. Do not invent a full sealed pack from loose quantity.

## Concurrency tests

- two concurrent sales consume same open pack;
- one sale spans two packs while another targets second pack;
- scanned pack vs auto-allocation race;
- stocktake vs pack sale;
- purchase return vs sale of same sealed pack.

---

# 14. Phase 11D - Stock Adjustment Semantics

## Canonical planner

Introduce or centralize a planner equivalent to:

```text
StockAdjustmentPlan
- BeforeQuantity
- RequestedValue
- Mode
- AppliedDelta
- AfterQuantity
- cost effect
- lot effect
- exact-unit / pack effect
- financial classification
```

Exact naming may differ.

## Modes

### Relative Delta

```text
Before 10
Delta -2
After 8
```

### Absolute Physical Count

```text
Before 10
Observed 7
AppliedDelta -3
After 7
```

### Target zero

```text
Before 5
Observed 0
AppliedDelta -5
After 0
```

## Exact-unit positive adjustment

Do not synthesize untraceable exact units. Positive exact-unit inventory requires explicit provenance / controlled intake according to live authority.

## Exact-unit negative adjustment

Select exact units. Do not arbitrarily remove serialized physical units via generic quantity reduction.

## Required tests

- target equals current;
- target zero;
- target increase;
- target decrease;
- relative positive/negative delta;
- concurrent adjustment;
- serialized selection mismatch;
- pack-tracked physical count correction;
- cost / loss reconciliation.

---

# 15. Phase 11E - Exact-Unit Lot, Cost and Condition Integrity

## Selected-unit mutation slice

A useful conceptual projection is:

```text
SelectedUnitMutationSlice
- InventoryUnitId
- ProductId
- SourcePurchaseItemId
- SourceLotId where applicable
- BaseQuantity
- CarryingCost
- CurrentCondition / status
```

The selected physical units drive selected provenance.

## Scrap cost rule

```text
ExactTotalCost = SUM(each selected unit carrying cost)
```

Do not pass aggregate total into an API that treats it as per-unit cost.

## Lot rule

If selected exact units originated from different lots, their mutation must not consume unrelated arbitrary FIFO lots.

## Quantity validation rule

Reject fractional exact-unit input before rounding.

## Condition transfer

Condition bucket transfer changes physical condition and inventory bucket, not Sale COGS.

Write-off / scrap removes carrying cost and creates recognized inventory loss.

## Tests

- two unequal-cost exact units scrapped together;
- insufficient generic pool must not hide wrong exact cost math;
- selected units from non-FIFO source lots;
- 1.2 exact-unit input rejection;
- duplicate selected unit rejection;
- concurrent scrap / sale race;
- condition transfer cost neutrality;
- write-off loss entry reconciliation.

---

# 16. Phase 11F - Thaka Material Integrity

## Pre-mutation normalization

Before touching inventory:

1. Resolve Product + ProductUnit.
2. Convert entered quantity to BaseQuantity.
3. Resolve exact units where required.
4. Build one command-wide exact-unit set.
5. Reject duplicate exact units across all lines.
6. Validate stock, status, permission, project state and pricing.
7. Only then mutate stock/cost/Thaka ledger.

## Required invariants

```text
no exact InventoryUnit appears twice in one Thaka command
```

and:

```text
ProductUnit factor is applied consistently
```

and:

```text
BaseQuantity / exact selected unit count reconcile
```

## Tests

- same unit twice on one line;
- same unit across two different lines;
- different ProductUnits for same product;
- factor > 1;
- exact unit wrong product;
- already issued unit;
- concurrent Thaka issue of same unit;
- Thaka reversal preserving provenance where supported.

---

# 17. Phase 11G - Shared Return / Exchange Eligibility

Create one backend policy / service / domain rule for physical return eligibility used by the return side of both:

```text
Sale Return
Commercial Exchange
```

It must evaluate at least:

- original SaleItem / exact-unit relationship;
- already-returned quantity / unit;
- prior exchange return;
- current physical status;
- active or terminal warranty state;
- custody;
- product relationship;
- stale/concurrent state.

Financial semantics remain operation-specific after eligibility.

## Tests

- active warranty unit cannot be accepted by Exchange if Return would reject it;
- terminal warranty resolution behavior matches policy;
- already returned unit;
- already exchanged unit;
- wrong SaleItem;
- concurrent Return vs Exchange;
- concurrent Exchange vs Warranty transition.

---

# 18. Phase 11H - Reporting and Shop-Time Authority

## Financial impact classification

Inventory effects should be classifiable so reporting does not infer economics from handler names.

Conceptual classes:

```text
Sale COGS
Recognized Inventory Loss
Inventory Gain
Neutral Transfer
```

Do not count normal Sale COGS again as inventory loss.

## Net profit

Canonical:

```text
Net Profit
= Gross Profit
- Operating Expenses
- Recognized Inventory Losses
```

## Shop time

Conceptual authority:

```text
IShopTimeAuthority
- CurrentUtc
- ShopTimeZone
- CurrentShopLocalTime
- CurrentBusinessDate
- UTC <-> shop-local conversion
```

Use actual project naming conventions when implementing.

## Tests

- host Windows timezone differs from shop timezone;
- transaction around midnight shop time;
- reporting range boundaries;
- DST-capable timezone if supported;
- scrap and operating expense in same period;
- stocktake shortage appears once in Net Profit;
- neutral condition transfer does not become loss.

---

# 19. Phase 11I - Real PostgreSQL Reconciliation and Certification

Phase 11 does not close on unit tests alone.

## Required real PostgreSQL scenarios

- F01 target/delta matrix;
- F02 unequal-cost scrap;
- Sol-F03 selected-unit / source-lot trace;
- fractional exact-unit rejection;
- F04 cross-line Thaka duplicate;
- ProductUnit factor in Thaka;
- F10 exchange under warranty state;
- F12 inventory-loss reporting;
- F13 shop-time boundaries;
- pack receive -> partial sale -> cross-pack sale -> return -> stocktake;
- wire length receive -> full roll sale -> loose sale -> return / wastage;
- concurrent exact-unit and pack mutations.

## Phase 11 exit gate

```text
Tracking policy authority                PASS
ProductUnit conversion                   PASS
Quantity tracking                        PASS
Length tracking                          PASS
Container / Pack tracking                PASS
IndividualPiece tracking                 PASS
Serialized tracking                      PASS
Pack/BaseQuantity reconciliation         PASS
Stock adjustment semantics               PASS
Exact-unit lot provenance                PASS
Exact-unit cost integrity                PASS
Thaka integrity                          PASS
Return/Exchange eligibility              PASS
Recognized loss reporting                PASS
Shop-time authority                      PASS
Real PostgreSQL hostile pack             PASS
Critical Phase 11 defects                0
High Phase 11 defects                    0
Blocked required Phase 11 gates          0
Unexecuted required Phase 11 gates       0
```

Do not automatically begin Phase 12. Produce Phase 11 closure evidence first.

---

# 20. Phase 12 - Operation Identity, Replay and Recovery Authority

## 20.1 Mission

Phase 12 answers:

```text
How does one user intent remain one business effect under retries, timeouts, crashes, response loss and process restart?
```

Phase 12 owns:

```text
F05
F06
F07
```

and the global operation identity architecture required to prevent similar defects elsewhere.

## 20.2 Golden law

```text
ONE USER INTENT
    = ONE ClientOperationId
    = ONE immutable OperationType
    = ONE immutable payload fingerprint
    = ONE business effect
    = ONE durable outcome
```

Same operation ID never changes meaning.

---

# 21. Phase 12A - Global Immutable Operation Claim

Strengthen the existing shared operation outcome authority rather than introducing a competing second idempotency system unless live code proves separation is required.

Conceptual durable fields:

```text
ClientOperationId
OperationType
FingerprintVersion
PayloadHash
ActorUserId
LocalClient / trusted installation context
Terminal context where genuinely applicable
Status
ResultType
ResultEntityId / reference
minimal recovery envelope
CanonicalErrorCode if final rejection is persisted
CreatedAtUtc
CompletedAtUtc
```

Exact schema names must follow live code.

## Global uniqueness

`ClientOperationId` is globally unique inside the operational shop database.

Same ID + different OperationType:

```text
REJECT operation.type_mismatch
```

Same ID + different PayloadHash:

```text
REJECT operation.payload_mismatch
```

before business side effects.

---

# 22. Phase 12B - Canonical Payload Fingerprint

Do not hash arbitrary serializer output.

Define a canonical intent payload per operation family.

Normalization rules:

- invariant decimal representation;
- canonical GUID representation;
- defined null/omitted semantics;
- deterministic ordering for unordered ID sets;
- preserve business-significant line ordering where required;
- exclude transport noise.

Fingerprint:

```text
SHA-256(
  FingerprintVersion
  + OperationType
  + CanonicalIntentPayload
)
```

Do not include:

```text
HTTP retry count
correlation log ID
random transport timestamp
bearer token
session secret
network metadata
```

`FingerprintVersion` is persisted so upgrades can still interpret older committed operations.

---

# 23. Phase 12C - Atomic Claim + Mutation + Outcome

Canonical transaction shape:

```text
request-shape validation
authentication
authorization
canonical intent + fingerprint

BEGIN PostgreSQL transaction

claim ClientOperationId globally
validate existing claim on collision
acquire deterministic business locks
execute business validation
perform mutation
write stock / financial / lifecycle / audit effects
write durable operation outcome

COMMIT
```

Critical invariant:

```text
Business Effect + Durable Outcome commit together
```

Never commit a Sale and then later "try" to save its operation outcome in a separate reliability boundary.

---

# 24. Phase 12D - Replay Semantics

## Same ID, same type, same payload, same valid authority

Return original durable result.

No second mutation.

## Same ID, different payload

Reject mismatch.

## Same ID, different operation type

Reject mismatch.

## Same ID, different actor/context

Reject unless an explicitly authorized recovery/support path exists.

Do not bind recovery to an ephemeral bearer token that may expire after the business operation committed.

---

# 25. Phase 12E - Operation Status Authority

Conceptual endpoint:

```text
GET /operations/{ClientOperationId}
```

Canonical externally useful states:

```text
NOT_FOUND
SUCCEEDED
REJECTED
```

A durable `IN_PROGRESS` state is not required if claim + mutation + outcome are one transaction. Live design may expose transient processing, but do not create stale durable executing rows without a proven need.

Important nuance:

```text
NOT_FOUND
```

means no committed outcome is visible at that moment. It does not justify generating a new operation identity.

Recovery may perform bounded status recheck and then safely resend the **same** ClientOperationId.

---

# 26. Phase 12F - Lost-Response Recovery

Scenario:

```text
Desktop creates Operation ABC
Sale commits
Outcome ABC -> Sale S100 commits
HTTP response is lost
```

Recovery:

```text
query ABC
-> SUCCEEDED
-> return S100
```

No second Sale, stock decrement, cash movement or invoice number.

F06-specific requirement: trusted operation context must be persisted consistently so the legitimate status query cannot fail because the original outcome omitted terminal metadata.

---

# 27. Phase 12G - POS Draft Conversion Replay

Same operation ID replay after successful conversion:

```text
check durable outcome first
-> original Sale exists
-> return original Sale
```

Do not reject first because Draft is no longer Open.

A **new** operation ID against an already-converted Draft is a new intent and may return `draft_already_converted` with original Sale reference where useful.

---

# 28. Phase 12H - Desktop Pending Operation Journal

To survive Desktop power/process loss, unresolved operation identity cannot exist only in RAM.

Use a minimal local recovery journal under the canonical machine state root.

Conceptual entry:

```text
ClientOperationId
OperationType
FingerprintVersion
PayloadHash
StartedAtUtc
minimal safe replay/recovery envelope
safe display context
```

Do not store:

```text
PIN
password
bearer/session token
license private secret
backup encryption key
signing secret
```

Server remains business authority.

## Journal ordering

```text
persist + flush pending entry
then send first request
```

On canonical SUCCEEDED / REJECTED:

```text
mark resolved / remove safely
```

Desktop restart:

```text
load unresolved entry
-> query Server outcome
-> if SUCCEEDED, recover canonical result
-> if REJECTED, show canonical rejection
-> if NOT_FOUND, bounded recheck then resend SAME ID
```

Never generate a new operation ID merely because the Desktop restarted.

---

# 29. Phase 12I - Retryable vs Final Failure

Do not persist infrastructure failure as final business rejection when the business transaction did not commit.

Examples of retryable infrastructure conditions:

```text
server unavailable before request accepted
DB unavailable before transaction
transaction deadlock rolled back
connection drop before commit
```

Retry with same ClientOperationId.

A final validated business rejection may be persisted against the original immutable intent. If the user edits the intent, use a new ClientOperationId.

---

# 30. Phase 12J - Coverage Boundary

Global operation identity applies to externally retryable mutations that affect stock, money, ledgers, exact physical state, or business lifecycle.

At minimum audit coverage for:

```text
Complete Sale
Draft conversion
Sale Return
Commercial Exchange
Purchase
Physical Receiving where retry-sensitive
Purchase Return / Void
Stock Adjustment
Stocktake Post
Condition / Scrap mutation
Thaka material issue / reversal
Thaka payment / reversal / settlement
Supplier payment / refund / reversal
financial or stock-significant Warranty operations
Warranty replacement
controlled cash mutations
other high-risk committed financial commands
```

Do not add ClientOperationId mechanically to pure reads or harmless UI interactions.

---

# 31. Phase 12K - Physical Side Effects Boundary

Database exactly-once semantics do not magically make printers, files, uploads, or devices exactly once.

Physical effects use a separate durable effect pattern:

```text
business DB commit
-> durable outbox/effect record
-> physical execution
-> effect settlement / retry
```

Printer / backup / external device unknown-outcome handling belongs to the relevant existing operations phase and Phase 13 certification.

---

# 32. Phase 12L - Real PostgreSQL Hostile Suite

Required cases:

```text
same Sale ID twice sequentially
same Sale ID twice concurrently
same ID with different Sale payload
same ID with different OperationType
same ID with unauthorized different actor
commit then lose response
server crash before commit
server crash after DB commit before response
Desktop crash after submit
Desktop restart with pending journal
session expiry after commit
DB deadlock and retry same ID
draft conversion response loss
draft conversion concurrent double submit
new ID against already-converted draft
Stock Adjustment duplicate submit
Thaka issue duplicate submit
Purchase duplicate submit
Supplier payment duplicate submit
```

Persisted assertions must inspect actual database truth:

```text
business row count
movement count
cash movement count
inventory quantity
InventoryUnit state
pack allocation state where applicable
ledger rows
operation outcome
```

## Phase 12 exit gate

```text
Global operation-ID uniqueness          PASS
OperationType immutability              PASS
Payload immutability                    PASS
Fingerprint versioning                  PASS
Actor / local-client context            PASS
Atomic mutation + outcome               PASS
Same-ID concurrency                     PASS
Different-type collision rejection      PASS
Different-payload collision rejection   PASS
Lost-response recovery                  PASS
Draft-conversion recovery               PASS
Desktop restart recovery                PASS
Server restart recovery                 PASS
Pending journal durability              PASS
Pending journal secret safety           PASS
Real PostgreSQL hostile suite           PASS
F05                                     CLOSED
F06                                     CLOSED
F07                                     CLOSED
Critical Phase 12 defects               0
High Phase 12 defects                   0
Blocked required Phase 12 gates         0
Unexecuted required Phase 12 gates      0
```

Do not automatically begin Phase 13. Produce closure evidence first.

---

# 33. Phase 13 - Ultimate Whole-System Hostile Certification and V1 Authority Closure

## 33.1 Mission

Phase 13 owns **proof**, not normal feature implementation.

It combines:

```text
existing hostile production certification requirements
+ closure of all roadmap-covered forensic findings
+ Phase 11 business-integrity proof
+ Phase 12 retry/recovery proof
= one current-checkpoint V1 verdict
```

Phase 13 must try to falsify production readiness.

If it discovers a defect, the gate fails and the defect returns to its owning implementation scope for correction. The certifier should not quietly mutate the system while certifying it.

---

# 34. Phase 13A - Final Certification Checkpoint

Before hostile certification:

```text
Phase 1-10 required implementation complete
Phase 11 implementation complete
Phase 12 implementation complete
```

Capture:

```text
FINAL_V1_CERTIFICATION_CHECKPOINT
```

Record at minimum:

```text
source/worktree fingerprint
branch / commit where meaningful
git status
migration list
EF model snapshot / pending-model-change result
.NET SDK/runtime version
PostgreSQL version
runtime configuration fingerprint
build artifact identity
test harness version
installer/package version
```

Any code/config/migration change after checkpoint invalidates affected certification evidence.

---

# 35. Phase 13B - Evidence Classes

Recommended evidence strength labels:

```text
L1 Static source / schema proof
L2 Unit behavior proof
L3 API / process integration proof
L4 Real isolated PostgreSQL proof
L5 Concurrency / crash / failure-injection proof
L6 Real hardware / installer / deployment proof
```

A Critical inventory mutation rule should not close at L2 if the failure mode depends on PostgreSQL transactions or concurrency.

---

# 36. Phase 13C - Five Tracking Golden Traces

## Quantity Golden Trace

```text
create Product
-> receive quantity stock
-> lot / MWA
-> Sale
-> Return
-> Adjustment
-> Stocktake
-> Report reconciliation
```

## Length / Wire Golden Trace

```text
create wire Product
-> configure Meter + Roll/Coil ProductUnits
-> receive length
-> full-roll sale
-> loose-length sale
-> partial return where allowed
-> wastage / short-end write-off
-> stocktake
-> accounting reconciliation
```

Assert no fake per-meter InventoryUnits.

## Container / Pack Golden Trace

```text
receive Pack A + Pack B
-> A sealed/open
-> partial consumption
-> cross-pack sale
-> A consumed
-> B open
-> return against original allocation
-> Thaka / adjustment scenario
-> stocktake
-> reconcile BaseQuantity + physical pack sub-ledger
```

## IndividualPiece Golden Trace

```text
receive exact physical item
-> TrackingCode
-> POS exact scan
-> Sale
-> Return
-> Warranty
-> supplier lifecycle / condition transition
```

## Serialized Golden Trace

```text
receive TrackingCode + manufacturer Serial/IMEI
-> Sale
-> Return / Warranty
-> replacement
```

Original physical identity remains linked to replacement. Replacement receives a new physical identity.

---

# 37. Phase 13D - Phase 11 Hostile Matrix

Attack at least:

```text
AbsoluteCount current=10 target=10
AbsoluteCount current=5 target=0
AbsoluteCount concurrent update
RelativeDelta positive/negative
unequal-cost exact-unit scrap
selected exact units from non-FIFO source lots
fractional exact-unit input
same exact unit twice in one Thaka command
same exact unit across two Thaka lines
ProductUnit factor > 1 in Thaka
Exchange of unit under active warranty
inventory loss + expense + Sale in same report period
host timezone != shop timezone
open pack + sealed pack consumption
cross-pack sale remaining=4 required=10
container/pack return provenance
pack sale vs stocktake race
```

---

# 38. Phase 13E - Phase 12 Recovery Hostile Matrix

Attack:

```text
same operation ID sequential retry
same ID concurrent retry
same ID different payload
same ID different OperationType
same ID wrong actor
response lost after commit
crash before commit
crash immediately after commit
Desktop power/process loss after submit
Desktop restart recovery
Server restart recovery
session expiry after commit
status lookup under reconnect
draft conversion response loss
double-click Complete Sale
DB deadlock + retry
network interruption during status lookup
```

For each scenario prove either:

```text
Business Effect Count = 1
Durable Outcome Count = 1
```

or:

```text
Business Effect Count = 0
Canonical Rejection = 1
```

as appropriate.

---

# 39. Phase 13F - Cross-Domain Master Golden Trace

Run one controlled end-to-end shop trace on isolated PostgreSQL:

```text
First Setup
-> Login
-> Supplier
-> Company
-> Category
-> Product / Model
-> ProductUnit / Barcode
-> Purchase
-> one-product physical Receiving
-> Inventory
-> physical label
-> scanner / POS Sale
-> receipt
-> Sale Return / Exchange scenario
-> Warranty lifecycle
-> supplier warranty / replacement where applicable
-> Supplier Khata
-> Thaka material issue / payment / reversal where applicable
-> Stock Adjustment
-> Stocktake
-> Reports
-> Backup
-> Restore rehearsal
-> restart restored system
-> re-verify identities, balances, costs, operation outcomes and high-water state
```

Capture at checkpoints:

```text
stock balances
inventory movements
InventoryUnit states
pack states / allocations
lots / cost states
cash movements
supplier ledger
Thaka ledger
warranty provenance
operation outcomes
audit entries
reports
```

---

# 40. Phase 13G - Accounting Reconciliation

For a controlled period independently calculate and compare:

```text
Net Local Sales
Gross Profit
Operating Expenses
Recognized Inventory Losses
Net Profit
```

Reconcile against persisted business rows and report output.

No unexplained reconciliation difference is acceptable.

Verify:

- returns / exchange credits;
- Sale COGS;
- scrap loss;
- stocktake shortage;
- negative adjustment loss;
- inventory gain classification if supported;
- no double counting of COGS as loss;
- warranty replacement does not create fake revenue.

---

# 41. Phase 13H - Stock and Physical Reconciliation

For every certified Product family:

```text
movement-derived stock
= StockBalance projection
```

For exact units:

```text
eligible physical unit states
= corresponding exact physical quantity
```

For tracked packs:

```text
SUM(active RemainingBaseQuantity)
= corresponding pack-tracked BaseQuantity
```

For stocktake:

```text
Expected
-> Counted
-> movement-backed correction
-> Final
```

No direct unexplained overwrite.

---

# 42. Phase 13I - Real PostgreSQL Concurrency Certification

Use barriers / synchronization so requests genuinely overlap.

Race pairs:

```text
Sale vs Sale
Sale vs Return
Sale vs Warranty
Sale vs Purchase Return
Sale vs Thaka Issue
Stock Adjustment vs Sale
Stocktake Post vs Sale
Thaka Issue vs Thaka Issue
Warranty replacement vs replacement
same OperationId vs same OperationId
same InventoryUnit vs same InventoryUnit
same open Pack vs same open Pack
pack sale vs purchase return of same sealed pack
```

Assert:

```text
no double consumption
no impossible negative stock
no duplicate physical state
no duplicate ledger effect
no false success after deadlock
no orphan operation outcome
```

---

# 43. Phase 13J - Runtime Crash / Failure Injection

## Desktop crash points

```text
before journal write
after journal flush
immediately after HTTP send
while awaiting response
after response before journal cleanup
```

## Server crash points

```text
before transaction
inside transaction
after business mutation before commit
after commit before response
```

## Worker crash points

```text
during outbox dispatch
during backup
during retention cleanup
```

## Machine / environment

```text
Windows reboot
DB outage
disk pressure
unwritable state root
maintenance-state corruption
ProgramData corruption scenario where safely testable
```

Recovery must be deterministic and fail closed.

---

# 44. Phase 13K - Security Certification

Test at least:

```text
actor spoof
SessionId-as-token misuse
expired/stale session
revoked user
revoked LocalClient
PIN brute force
bootstrap replay
permission downgrade
cashier attempts manager command
step-up expiry where applicable
certificate rollback
clock rollback
signed request replay
operation recovery by wrong actor
operation ID guessing
Admin CSRF / session fixation
```

Expected result: unauthorized mutation count = 0.

---

# 45. Phase 13L - Desktop API-Only Authority

Prove the production Desktop composition cannot mutate the database around the Shop Server.

Desktop production DI must not resolve:

```text
DbContext
business repositories for direct mutation
Infrastructure mutation handlers
direct Npgsql business mutation service
```

Required runtime path:

```text
Desktop
-> 127.0.0.1:7150 Shop Server
-> Application
-> Domain
-> Infrastructure
-> PostgreSQL
```

This closes F09.

---

# 46. Phase 13M - API Parity Certification

For every canonical Desktop production workflow prove:

- Server route exists;
- request/response contract is complete;
- authenticated actor is server-derived;
- permission check is authoritative;
- canonical error mapping exists;
- retry-sensitive mutation accepts the correct operation identity contract;
- Desktop uses the route rather than local DB service.

Pay special attention to previously reported gaps in:

```text
Warranty lifecycle
Inventory / Stocktake lifecycle
Finance / cash-session lifecycle
Sales lifecycle
```

This closes F17 only when the live client actually uses the routes.

---

# 47. Phase 13N - Backup / Restore and Key Rotation

Certification sequence:

```text
create representative live test state
-> perform real logical PostgreSQL backup
-> verify checksum / manifest
-> encrypt / protect
-> restore to staging DB
-> validate schema + data + identities
-> controlled cutover rehearsal
-> launch application against restored state
-> run post-restore business operation
```

Verify high-water protection for:

```text
SupplierCode
SupplierProduct.NextItemSequence
PhysicalSequence / TrackingCode
```

Hostile cases:

```text
wrong key
old rotated key
corrupt archive
partial archive
unsupported backup version
insufficient disk
worker crash during backup
restore verification failure
```

Scheduled backup must create a real artifact. This closes F11 and F16 only with actual restore evidence.

---

# 48. Phase 13O - Outbox / Physical Effect Reliability

For printing and other post-commit side effects prove:

```text
business commit
-> durable effect/outbox intent
-> Worker/Desktop physical effect executor
-> retry / fencing
-> settled state
```

Hostile cases:

- worker crash while effect is leased;
- lease expiration;
- long-running dispatch;
- duplicate worker attempt;
- physical outcome unknown after crash;
- no producer wiring;
- printer offline / paper out / jam.

No physical effect failure may repeat the underlying Sale or other business mutation.

---

# 49. Phase 13P - Real Scanner and Printing Hardware

Mandatory real-device verification:

```text
barcode scanner
tracking/physical label printer
58mm receipt
80mm receipt
A4 document
```

Scanner resolution precedence remains:

```text
1 TrackingCode / Physical SKU
2 Serial
3 IMEI
4 ProductUnit barcode
5 ProductCode / SKU according to current canonical naming
6 broad Product search
```

Test:

```text
rapid scans
duplicate scan
unknown barcode
already sold exact unit
scrapped exact unit
supplier-returned unit
wrong product
stale state
```

Printer hostile cases:

```text
printer offline
paper out
jam
partial physical print
crash after DB commit
reprint
```

Reprint never allocates a new physical identity.

---

# 50. Phase 13Q - Installer / Upgrade / Release Certification

## Clean-machine path

```text
install
-> first startup
-> bootstrap/setup
-> database readiness
-> normal login
-> representative business flow
```

## Upgrade path

```text
supported prior build
-> installer upgrade
-> migrations
-> restart
-> data retained
-> business flow continues
```

Required build/schema gates:

```text
Debug:   0 warnings / 0 errors
Release: 0 warnings / 0 errors
EF:      no pending model changes
Migration rehearsal: PASS
```

Installer smoke must use the produced release artifacts, not only `dotnet run`.

---

# 51. Phase 13R - Licensing, Vendor Backend and Admin Portal

Because the V1 final roadmap includes commercial licensing, Vendor backend and Admin Portal, final closure requires their real E2E gates where they are part of the release candidate.

Verify:

```text
activation
machine binding
license persistence
expiry / renewal
invalid or corrupt license handling
clock rollback / tamper rules
Vendor API authority
protected signing boundary
Admin authentication / authorization
commercial state transitions
audit
session security
```

Do not certify local POS while leaving mandatory commercial-control E2E unexecuted.

---

# 52. Phase 13S - Performance and Soak

Use representative production-scale fixtures rather than tiny toy data only.

Exercise:

```text
large product catalog
large Sale history
large InventoryUnit history
large Supplier ledger
large Warranty timeline
large Thaka history
```

Verify:

```text
bounded pagination
deterministic ordering
POS search / scanner resolution
dashboard startup
report generation
no UI-thread blocking production call
no runaway memory growth
no DB connection leakage
no stale locks
no accumulating unresolved outbox items
no accumulating unresolved Desktop operations
```

End the soak with full reconciliation.

---

# 53. Phase 13T - Documentation Authority Closure

Final state must satisfy:

```text
live code
= current canonical architecture
= implementation roadmap
= migration state
= API register
= runbooks
= release package
```

Obsolete authority must be clearly archived / marked historical.

Explicitly document:

```text
V1 is single-shop / single-primary-installation.
Multi-shop shared operational DB is not part of V1.
Old direct-WPF runtime topology is non-authoritative.
Desktop production database authority is forbidden.
```

---

# 54. Multi-Agent Execution Model

Use multiple agents to parallelize evidence collection and bounded implementation work, not to lower reasoning quality.

Principle:

```text
Parallelize workload, not thinking quality.
```

Never allow two implementation agents to edit the same authority boundary simultaneously without explicit ownership.

## Phase 11 suggested waves

### Wave 11-0 - Read-only authority recovery

Agents can inspect in parallel:

```text
A - Tracking / ProductUnit / receiving
B - Inventory adjustment / stocktake
C - Exact unit / cost / lot / condition
D - Thaka
E - Return / Exchange / Warranty interaction
F - Reporting / timezone
```

Outputs merge into one delta matrix.

### Wave 11-1 - Data model + invariants

One lead owner freezes schema/invariant changes after reconciling agent findings.

### Wave 11-2 - Business mutation fixes

Split by non-overlapping domains where practical:

```text
stock adjustment
exact unit / condition
Thaka
return/exchange policy
reporting/time
pack sub-ledger
```

### Wave 11-3 - Integration / PostgreSQL

Parallel test authors may cover distinct scenario families. One integrator owns final migrations and cross-domain reconciliation.

### Wave 11-CERT

Fresh read-only certifier after all implementation agents finish.

## Phase 12 suggested waves

### Wave 12-0

Audit every retry-sensitive command and current operation-outcome usage.

### Wave 12-1

One authority owner implements global operation claim + fingerprint contract.

### Wave 12-2

Domain-specific handlers migrate to the authority without inventing local variants.

### Wave 12-3

Desktop pending-operation journal + recovery UX.

### Wave 12-4

Real PostgreSQL concurrency / crash / replay tests.

### Wave 12-CERT

Fresh independent certifier.

## Phase 13 suggested waves

Evidence collection can be parallel:

```text
A - Inventory / tracking / provenance
B - Sales / return / warranty / accounting
C - Operation identity / concurrency / recovery
D - Runtime / API / Desktop authority / security
E - Backup / outbox / printing / deployment
F - Licensing / Vendor / Admin
```

Then one reconciliation agent merges contradictions and missing evidence.

Finally one fresh read-only `V1-FINAL-CERT` agent attempts to falsify closure.

---

# 55. Git and Workspace Safety

Unless a prompt explicitly authorizes Git mutation:

```text
Do not commit
Do not push
Do not reset
Do not clean
Do not checkout over local work
```

During implementation, use meaningful checkpoints rather than committing every few minutes.

Before any certification checkpoint capture:

```text
git status
git diff --stat
git diff --check
current branch / commit where applicable
```

Do not delete pre-existing user changes.

---

# 56. Database Safety

Never use the operational shop database for destructive integration tests.

Preferred:

```text
isolated PostgreSQL test database
or
ephemeral PostgreSQL harness
```

Environment variable historically used by project integration tests:

```text
EDGE_RETAILS_TEST_DB
```

If a required certification database cannot be provided:

```text
BLOCKED_ENVIRONMENT
```

is accurate for that gate, but Phase 13 final closure cannot claim PASS while a required database gate remains blocked.

---

# 57. Implementation Dependency Order

The execution sequence for the new extension is:

```text
1. Reconcile live code with this handoff

2. Phase 11A authority scan

3. Phase 11B tracking / ProductUnit freeze

4. Phase 11C pack/container sub-ledger
   because later stock/cost tests depend on knowing physical allocation semantics

5. Phase 11D stock adjustment semantics

6. Phase 11E exact-unit lot/cost/condition

7. Phase 11F Thaka integrity

8. Phase 11G return/exchange shared eligibility

9. Phase 11H reporting + shop time

10. Phase 11I PostgreSQL reconciliation + independent Phase 11 certification

11. STOP and review evidence

12. Phase 12A-C global operation claim / fingerprint / atomicity

13. Phase 12D-G replay, status and draft recovery

14. Phase 12H Desktop pending-operation journal

15. Phase 12I-K failure semantics / coverage / physical-effect boundary

16. Phase 12L PostgreSQL hostile suite + independent Phase 12 certification

17. STOP and review evidence

18. Close any remaining original-roadmap forensic findings owned outside Phase 11/12
    F08, F09, F11, F14-F19, F00 if still live

19. Freeze FINAL_V1_CERTIFICATION_CHECKPOINT

20. Phase 13 whole-system hostile certification

21. Fresh independent V1-FINAL-CERT

22. Only if every required exit gate is green: formal V1 production authority closure
```

---

# 58. Phase Ownership Matrix

| Finding / Topic | Implementation Owner | Final Verifier |
|---|---|---|
| F00 Release build | existing runtime/build scope | Phase 13 |
| F01 adjustment mode | Phase 11 | Phase 13 |
| F02 scrap cost | Phase 11 | Phase 13 |
| Sol-F03 exact lot/quantity | Phase 11 | Phase 13 |
| Gemini-F03 multi-shop | N/A to V1 | Phase 13 confirms exclusion |
| F04 Thaka | Phase 11 | Phase 13 |
| F05 operation collision | Phase 12 | Phase 13 |
| F06 recovery context | Phase 12 | Phase 13 |
| F07 draft replay | Phase 12 | Phase 13 |
| F08 sessions / PIN / loopback | existing security/runtime | Phase 13 |
| F09 Desktop dual authority | existing Desktop cutover | Phase 13 |
| F10 exchange/warranty | Phase 11 | Phase 13 |
| F11 scheduled backup | existing operations | Phase 13 |
| F12 net profit/loss | Phase 11 | Phase 13 |
| F13 shop timezone | Phase 11 | Phase 13 |
| F14 purchase vs receiving | existing purchasing | Phase 13 |
| F15 outbox | existing operations | Phase 13 |
| F16 backup key rotation | existing backup/security | Phase 13 |
| F17 API parity | existing API parity | Phase 13 |
| F18 ProgramData/startup | existing runtime/operations | Phase 13 |
| F19 MaxTerminals | existing licensing/runtime | Phase 13 |
| Container/Pack completion | Phase 11 | Phase 13 |
| Five tracking Golden Traces | test/certification | Phase 13 |

---

# 59. Phase Closure Rules

Each implementation phase must produce a closure artifact containing:

```text
scope implemented
files changed
migrations added
commands executed
test provider
focused test results
full regression relevant to phase
PostgreSQL test results
known remaining issues
blocked gates
worktree state
independent certification result
```

Closure is forbidden if:

```text
Critical > 0
High > 0 within phase ownership
required gate blocked
required gate skipped
required gate not executed
migration/model state uncertain
certifier did not run
```

Do not automatically roll into next phase.

---

# 60. Final Phase 13 Exit Matrix

Every required row must be green at the same current certification checkpoint.

| Gate | Required State |
|---|---|
| Critical findings | 0 |
| High findings | 0 |
| Required blocked gates | 0 |
| Required unexecuted gates | 0 |
| Debug build | PASS, 0 warnings/errors |
| Release build | PASS, 0 warnings/errors |
| EF pending model changes | NONE |
| Migration rehearsal | PASS |
| Full unit regression | PASS |
| Real PostgreSQL integration | PASS |
| Phase 11 independent certification | PASS |
| Phase 12 independent certification | PASS |
| Quantity Golden Trace | PASS |
| Length / Wire Golden Trace | PASS |
| Container / Pack Golden Trace | PASS |
| IndividualPiece Golden Trace | PASS |
| Serialized Golden Trace | PASS |
| Accounting reconciliation | PASS |
| Stock/physical reconciliation | PASS |
| Concurrency hostile pack | PASS |
| Crash/restart recovery pack | PASS |
| Security hostile pack | PASS |
| Desktop API-only authority | PASS |
| API lifecycle parity | PASS |
| Outbox / physical effect reliability | PASS |
| Backup / Restore / key rotation | PASS |
| Real scanner | PASS |
| Real label printing | PASS |
| 58mm | PASS |
| 80mm | PASS |
| A4 | PASS |
| Installer clean-machine smoke | PASS |
| Upgrade rehearsal | PASS |
| Licensing E2E | PASS |
| Vendor/Admin E2E | PASS |
| Documentation authority cleanup | PASS |
| Independent V1-FINAL-CERT | PASS |

Only then may the project state be declared:

```text
EDGE RETAILS V1
FINAL PRODUCTION AUTHORITY CLOSED
```

---

# 61. Immediate Next-Chat Work Plan

The next chat should **not** begin by rewriting this plan.

It should execute this exact sequence:

## Step 1 - Load authority

Read:

```text
Edge_Retails_FINAL_FROZEN_CANONICAL_ARCHITECTURE_2026-09-25.md
Edge_Retails_Consolidated_Final_Implementation_Roadmap_2026-09-25.md
Edge_Retails_Final_Single_Machine_Architecture_and_Implementation_Handoff_2026-09-25.md
docs\Architecture_Authority_Manifest.json
docs\Edge_Retails_Final_Architecture_Report_v1.md
latest whole-project forensic audit reports
this handoff
```

## Step 2 - Read-only current-state check

Inspect:

```text
git status
git diff --stat
current branch / checkpoint
Debug build
Release build
EF pending-model-changes
current migrations
current UnitTests / IntegrationTests inventory
```

Do not mutate Git during this scan.

## Step 3 - Phase 11 live delta matrix

Verify every Phase 11 assumption against source.

Pay special attention to whether any form of `stock_packs`, `pack_allocations`, container state or existing container tracking already exists. Do not create duplicate concepts.

## Step 4 - Produce bounded implementation plan

Map exact files / types / migrations / tests.

Only then start implementation.

---

# 62. Copy-Paste Master Prompt for the Next Chat

```text
We are continuing Edge Retails from the attached Phase 11-13 Complete Architecture, Implementation Roadmap and Next-Chat Handoff dated 2026-09-28.

Work directly against the live workspace:
C:\Users\muham\OneDrive\Desktop\Point of Sale

DO NOT restart the project.
DO NOT redesign Phases 1-10.
DO NOT reintroduce multi-shop, LAN, multi-workstation or seat/terminal-quota architecture.
DO NOT treat historical direct-WPF runtime documentation as current authority.
DO NOT modify Git during the initial forensic scan.

Current production runtime authority is:
EdgeRetails.Desktop
-> 127.0.0.1:7150
-> EdgeRetails.Server
-> Application / Domain
-> Infrastructure
-> PostgreSQL

First read the attached handoff completely, then deeply read the live canonical authority documents and current code.

Start in READ-ONLY mode.

Your first task is Phase 11A only:
1. Reconcile the handoff against the latest live authority.
2. Inspect the live tracking policy, ProductUnit conversion, InventoryUnit, stock balances, movements, lots, cost state, stock adjustment, condition/scrap, Thaka, return/exchange eligibility, reporting/timezone, receiving, stocktake and any existing pack/container implementation.
3. Produce a bounded Phase 11 delta matrix with exact files/types, what is already correct, what is missing, migration impact, tests required and risk.
4. Verify the audit findings F01, F02, Sol-F03, F04, F10, F12 and F13 against current live code rather than trusting historical line numbers.
5. Explicitly treat Gemini multi-shop F03 as NOT APPLICABLE to V1 unless the current canonical architecture has been intentionally changed.
6. Do not implement until the delta matrix is complete and conflicts with live authority are resolved.

No false green:
BLOCKED / NOT RUN / SKIPPED / ASSUMED / DOCUMENTED are not PASS.
Unit-only proof is not PostgreSQL proof.
Mock hardware is not real-device proof.

After Phase 11A, wait for explicit instruction before implementation.
```

---

# 63. Compact Continuity Snapshot

If the next agent needs a short mental model after reading the full document:

```text
EDGE RETAILS V1
Electrical / Electronics POS
Single shop
Single approved installation
Single machine operational architecture
Local PostgreSQL business truth
Desktop is client only
Loopback Shop Server is application authority

Identity:
SupplierCode -> CompanyCode -> CategorySymbol -> ModelCode
-> ProductCode -> SupplierProduct sequence -> TrackingCode

Phase 11:
Fix business integrity and complete tracking / pack provenance.

Phase 12:
Make one business intent exactly-once and recoverable under retry/crash.

Phase 13:
Try to break the entire release and certify it only with current real evidence.

Do not reopen stable earlier work without proof.
Do not add multi-shop architecture.
Do not accept false green.
```

---

# 64. Final Planning Status at Handoff

```text
Phase 11 architecture design: COMPLETE / FROZEN AT DESIGN LEVEL
Phase 12 architecture design: COMPLETE / FROZEN AT DESIGN LEVEL
Phase 13 architecture design: COMPLETE / FROZEN AT DESIGN LEVEL

Phase 11 implementation: NOT CERTIFIED BY THIS HANDOFF
Phase 12 implementation: NOT CERTIFIED BY THIS HANDOFF
Phase 13 certification: NOT RUN BY THIS HANDOFF

Next action:
READ-ONLY Phase 11A live-workspace reconciliation
```

This distinction is deliberate. The document is an execution authority and continuity artifact, not proof that the live source already implements the new Phase 11-13 design.

