# EDGE RETAILS — CITY CENTRAL ELECTRICAL, ELECTRONICS & HOME APPLIANCES SUPERSTORE
## Master Catalog & Unit Registry V3 • Corrected Design Baseline

**Date:** 2026-10-09  
**Scope:** One city-level central store, not six independent shop templates  
**Artifact status:** `TAXONOMY_V3_DESIGN_REVIEWED_REFERENCE_READY`  
**Operational status:** `NOT_SEEDED`, `NOT_LIVE_VERIFIED`, `PRODUCTION_HOLD`, `NO_IMPLEMENTATION_AUTHORIZATION`  
**Sources:** V2 standalone seven files + `EDGE_RETAILS_MASTER_TAXONOMY_V2_FINAL_DEEP_REVIEW.md` (C01–C05, I01–I04). Original V2 remains untouched.

## 1. Final bounded design decision

- Preserve 9 main divisions and 65 departments as the navigation/master-scope baseline, while allowing controlled future additions.
- Keep all 715 original V2 class references in traceable design history; **do not renumber** or use references as shop `CategorySymbol` or `ProductCode`.
- V3 holds **732 total reference rows**, with **687 active candidate leaf classes**, **42 deprecated-to-canonical redirects**, and **3 non-sellable navigation parents**. It introduces **17 separate product classes** to split genuinely distinct merchandise.
- Disallowed overlapping leaf classification axes moved to facets: smart/OLED/QLED, bifacial/flexible PV, DC/inverter fan, tablet OS, managed/PoE, battery chemistry/deep-cycle, projector lamp/application, LED strip color/addressability, fast-charge USB-C, SMT/high-power resistor, prepaid/smart/phase meter.
- For each redirect: keep its legacy `class_ref` and label as design evidence, map to exactly one active V3 canonical class, retain old search terms in scope. Existing seeded IDs (if any) must be reconciled first and are **never rewritten automatically**.
- Technical attributes are structured typed per department and bound to **every active class**; class-specific mutually independent facet rules appear separately. These profiles are reference suggestions, **not verified ETIM feature equivalence**, and currently do not force validation on existing product records.
- Global units use separate dimension and immutable local code; non-fixed boxes/rolls/packs/coils/sets require explicit ProductUnit/pack/BOM policy. `Mass`, `Volume`, and `Area` stock authority remains gated until backend verification.

## 2. Complete files and consumers

| File | Purpose | Rule |
|---|---|---|
| `departments.csv` | 9 divisions/65 departments + reconciled V3 active counts | Navigation only; never generates stock |
| `product_classes.csv` | All canonical/redirect/nav entries | Only `ACTIVE_PROPOSAL` may be selected as product class after approval |
| `class_redirects.csv` | Legacy-to-canonical mapping | No deletion or source identity rewrite |
| `catalog_change_log.csv` | Every proposed class change | Auditable reversible design changes |
| `unit_registry.csv` | Original 51 units with source codes intact | Reference library, not direct stock authority |
| `unit_conversion_policy.csv` | 51 unit safety contracts | ProductUnit dimension and conversion must be checked |
| `attribute_profiles.csv` | Typed attribute candidates for 65 departments | No automatic retroactive mandatory fields |
| `class_attribute_applicability.csv` | Explicit mapping for every class | Deprecations/parents cannot create products |
| `class_facet_rules.csv` | Typed class-specific overlapping facets | Independent variant axes, not duplicate leaves |
| `search_aliases.csv` | Department and class aliases (EN/Roman Urdu/Urdu draft) | Suggestions only, never silent product creation |
| `ambiguous_search_terms.csv` | Ambiguous queries | Show candidates, require selection |
| `design_acceptance_scenarios.csv` | Test cases, not executed tests | Execute only on approved isolated environment |
| `validation_report.json` | Structural validation | Does not establish production certification |

## 3. Classification decision logic

1. Classify by primary physical function/form; `Manufacturer/Brand`, `Model`, power, chemistry, display technology, network/OS capability and non-exclusive use cases are **typed attributes or filters**.
2. One real product has one canonical **primary product class**, and may have multiple *navigation tags* or search terms without duplicate product records.
3. Purchase intake, Sales, Customer/Supplier Khata, Warranty, Stocktakes and Thaka reference existing product and movement authority. Never derive identity from a label or `class_ref`.
4. Non-stock I-division services never mutate inventory, exact unit state or tracked pack allocation.
5. Stop and request controlled new class for non-classifiable products; navigation-only parents cannot be selected as sellable product leaves.

## 4. Unit, pack and tracking invariants

**Dimensions**: COUNT, LENGTH, MASS, VOLUME, AREA. Service work stays outside physical stock. External UN/CEFACT Recommendation 20 codes remain verified only where sourced in V2 (`PCS`→`H87`, `M`→`MTR`, `KG`→`KGM`). Do not guess remaining mappings. `W`, `V`, `A`, `Ah`, `BTU/h`, `GHz`, `mm²` etc are usually specification units, not default selling units.

**Fixed conversions**: numeric factor only inside the same dimension; reject cross-dimension ProductUnit. For example `1 FT = 0.3048 M` and `1 DOZ = 12 PCS`.

**Product-defined packaging**: Box, Pack, Carton, Roll, Coil, Reel, etc. have **no global FactorToBaseUnit**. A factor belongs to a verified ProductUnit or actual measured tracked pack. A 90m coil and 100m coil may share display unit `COIL` but not the same quantitative conversion.

**Tracked physical packs**: one physical pack code, InitialBaseQuantity and RemainingBaseQuantity, movement-backed allocations; no fake 50 child InventoryUnits for an opened 50-piece switch box. Cross-pack sale and return preserve source pack provenance.

**Exact-unit selection**: IndividualPiece/Serialized require deterministic physical selection and whole number validation *before* rounding; manufacturer Serial/IMEI must remain distinct from shop TrackingCode.

**Composite Kit**: sold standalone only with an explicit assembled-product identity and safe BOM/assembly/sale policy; never treat heterogeneous kit as product count multiplication.

**Mass/Volume/Area inventory**: registry labels available for planning; cannot activate stock flows until actual live quantity precision, valuation and movement support is independently verified.

**No auto-required retroactive attributes**: V3 attribute profiles suggest typed fields; per-class mandatory/variant enforcement requires explicit catalog owner policy and backward compatibility with existing products.

## 5. Scope protection

- **Phase 11A** must first reconcile current Shop Server DTOs, Category symbol grammar/uniqueness, ProductCode/ModelCode identity, Catalog/ProductUnit/TrackingMode boundaries, EF schema, existing seeded rows, GST/tax where applicable, permission and version guards, with this proposal.
- Do not modify `PhysicalUnitCreationAuthority`, identity high-water, inventory/cost mutations, or Phase 7 R6 protected source solely to adopt catalog names.
- Do not allow Desktop-to-PostgreSQL authority, multi-shop tenancy, LAN terminals or cloud-authoritative sales/inventory.
- Product Management is catalog authority; Inventory owns stock. No derived category status may overwrite an occupied category symbol.
- **No source code change, migration, seeding, Git write, PostgreSQL transaction or deployment was executed to produce this V3 file.**

## 6. Mandatory isolated-seed acceptance before future go-live

When Governance Body separately authorizes implementation:

1. Read-only live DTO/entity/migration/CategorySymbol/ProductUnit/tracking and actual prior seed mapping; capture immutable legacy IDs.
2. Approve which reference levels correspond to actual shop-owned Category and Subcategory, and ensure `class_ref` never becomes immutable ProductCode/TrackingCode authority.
3. Prepare versioned, reversible changes and idempotent seed diff, not an unbounded bulk overwrite.
4. Disposable PostgreSQL18 first-run, repeat-run, upgrade/conflict, rollback, multi-product selected-category identity preservation, stale actor/permission checks.
5. Test class redirects as **search/selection-level mappings**, not silent updates of historic products or CategorySymbol. Refuse unresolved collisions.
6. Test all U01–U23 scenarios in `design_acceptance_scenarios.csv`; compare real movements, lots, costing, physical units and pack allocations where supported.
7. Prove backend API filtering/pagination & Desktop product search compatibility; aliases must be collision/ambiguity safe.
8. Only after independently verified evidence and explicit approval consider release artifact. Operational production DB and services remain `HOLD` meanwhile.

## 7. Previous C01–C05 closeout (design level vs runtime)

| Issue | Design correction | Live certification |
|---|---|---|
| C01 leaf overlaps | 42 redirects and non-exclusive facets; stable references | NOT RUN |
| C02 composites/catchalls | Separate sellable leaves; non-sellable parents; documented synonyms | NOT RUN |
| C03 feature coverage | All 65 typed departmental profiles, 732 explicit class bindings, 68 class-specific rules | Class-level requiredness/ETIM parity not certified |
| C04 conversions | Separate per-unit enforceable design policy plus 23 acceptance scenarios | Backend ProductUnit/pack tests NOT RUN |
| C05 legacy/live seed safety | Immutable identity, isolated seed/rollback and compatibility runbook | Live system scan/seed NOT RUN |

## 8. Decision / handoff status

**Catalog reference design:** `V3_DESIGN_CONSOLIDATED`  
**All product classes technically identical to official GS1/ETIM:** `NO_CLAIM`  
**Structural and policy lint:** see `validation_report.json`  
**Production-seed readiness:** `GATED_ON_LIVE_COMPATIBILITY_AND_APPROVAL`  
**Phase 11 code execution:** `NOT_AUTHORIZED_BY_THIS_DOCUMENT`  
**Recommended next use:** Governance Body reviews V3 as input; no implementation command until it approves mapping and safe rollout plan.
