# EDGE RETAILS — PHASE 11 MASTER IMPLEMENTATION ROADMAP V2
## Business Integrity + Physical Pack/Container/Coil + City-Central Superstore Catalog V3

**Date:** 2026-10-10  
**Mode:** Planning / forensic reconciliation / work-order authority proposal  
**Project:** Edge Retails Electronics; one city-central Electrical, Electronics & Home Appliances superstore  
**Target live workspace:** `C:\Users\muham\OneDrive\Desktop\Point of Sale`  
**Target branch (user's audit):** `tracking-remediation-20261002`  
**Phase 7 candidate (user's audit):** `phase7-unified-final-r6`, *builder-reported CERTIFIED/CLOSED/LOCKED; independently reconcile candidate/hash evidence before inheritance*  
**This document's authority:** Owner-requested **additive Phase 11 roadmap proposal**; does not overwrite canonical architecture, the original 2026-09-28 Phase 11–13 handoff or older Git history.  
**Implementation status:** **NOT STARTED IN THIS CHAT**. No schema, seed, code, Git or production database modified.

---

## 0. Read first: canonical order and STOP gates

1. Read live `docs/Architecture_Authority_Manifest.json`, `docs/Edge_Retails_Final_Architecture_Report_v1.md` including relevant §§170–195 and 233.1, original Phase11 handoff, R6 Final21 source/harness fingerprint and all FOUR real `artifacts/phase11-preimplementation/` audit deliverables.
2. R6 Phase7 preservation first: prove same candidate fingerprint, no active authors/source races, protected tests, existing inventory/cash/Khata/Warranty semantics. No blanket reopening of closed phases.
3. This is **POS-FIRST** current execution. No automatic Phase4 licensing/Vendor/Admin Portal, no hidden Phase12/13 work, no multi-shop or secondary network terminal redesign.
4. **11A source reconciliation and 11C schema design approval must precede code.** Four nullable `inventory.units` fields proposed by the audit are **NOT preapproved**.
5. **Catalog V3 becomes Phase 11 scope** as `11B-CAT` (classification/UOM/attributes/search/seed planning) plus `11I-CAT` (isolated certification). It is not treated as already implemented just because the V3 files exist.
6. No destructive tests or migrations on operational PostgreSQL. No production changes, installer/deployment, commit/push/reset/clean unless owner expressly authorizes them.

## 1. Exact baseline: what's evidenced, reported, and pending

**Reported by owner-provided audit:** 9/9 11A–11I audited, 32 evidence requirements, 14 implementation tasks, 4 waves, zero code modifications, no open governance blockers, R6 baseline protected, 58 new tests / 10 claimed gates / target 1519. These are **audit report claims**, not independently executed tests in this session.

**Source-corroborated with GitHub branch read-only:** Container full-pack equality; `ConsumeSerializedAsync` whole-unit sold/cost behavior; Windows-Local reporting conversion; SetPhysicalCount math; selective exact-unit cost and lots, Thaka duplicate selection, warranty exchange gating, report loss deduction.

**Not independently confirmed:** actual local clean tree, 4 claimed preimplementation artifact files, R6 source/harness identity, EF migration/snapshot parity at live workspace, full 32-case evidence, tests and their numbers. The connected remote desktop device was offline. See companion forensic adjudication.

## 2. Workstream ownership (original 11A–11I preserved)

| Workstream | Original owned scope | Updated V2 scope / status |
|---|---|---|
| 11A | Authority/live-code/candidate reconciliation | Include catalog V3 mapping, 4 real audit deliverables, source fingerprints and DateOnly policy |
| 11B | TrackingMode, ProductUnit, physical behaviors | **Add 11B-CAT**: shop catalog hierarchy, product class, unit and attribute contract; no change to immutable identity grammar |
| 11C | Pack / container / coil physical subledger | Major unfinished core; durable allocation model and cost/status integration require design signoff |
| 11D | SetPhysicalCount and relative delta | Phase7 carry-forward per targeted code; regression-only unless reproducing fault |
| 11E | Exact-unit source lot, costs, condition | Phase7 carry-forward; test partial pack costing separately |
| 11F | Thaka UOM and global exact-unit uniqueness | Phase7 carry-forward; extend consumption for packs/coil, preserve old tests |
| 11G | Shared Sale Return / Commercial Exchange eligibility | Phase7 carry-forward; pack return provenance additional tests |
| 11H | Shop timezone, document dates, finance | F13 remains; preserve F12 loss and recovery gains; define document vs posting date semantics |
| 11I | Independent real PostgreSQL certification | **Add 11I-CAT**: idempotent catalog seed, search, attrs/UOM, U01–U23 and API/Desktop coverage |

No new macro phase number. Catalog tasks belong to Phase 11, with explicit scope and certification.

## 3. Formal adoption of the previous superstore discussion

### 3.1 Shop decision (final for planning)

- ONE city-central **Electrical, Electronics & Home Appliances SUPERSTORE**; all related technical goods available from the central catalog.
- Historical option C's six independent shop presets and mixed-store bundle selection are **superseded for this store**. They remain historical design only.
- Product Management owns catalog; Inventory owns stock; shop Server/backend owns business policy; Desktop is presentation/API client. No fake/demo Products, Brands, Suppliers, quantities, Serial/IMEI or TrackingCodes in seed.
- Master classifications preconfigured as definitions; products, supplier mappings, initial inventory and technical serials remain actual shop data entered via authorized flows.

### 3.2 Approved V3 reference ledger

| Reference collection | Verified file-based count | Status |
|---|---:|---|
| Divisions | 9 | Reference design |
| Departments | 65 | Reference design |
| Product class references | 732 | 687 proposed active; 42 redirects; 3 non-sellable parents |
| Unit registry / policy records | 51 / 51 | Physical Quantity dimension gates required |
| Typed departmental attribute entries | 337 | Attribute validation rules remain reviewed per class |
| Class-attribute applicability | 732 | Applies mapping, not complete manufacturer specs |
| Class facets | 68 | Filter/variant guidance |
| Aliases | 300 | Suggest-only; locale/collision review |
| Proposed catalog test scenarios | 23 | **NOT RUN** |

Class references are reference IDs, **not `CategorySymbol`, `ProductCode`, `ModelCode`, SKU, TrackingCode or live product IDs**. Original 715 V2 class refs remain represented, with 17 new V3 refs; do not auto-renumber or rewrite seeded identities.

### 3.3 All 65 departments under their nine divisions

### A. Electrical Wiring & Infrastructure (8 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| A01 | Building Wires & Power Cables | 12 |
| A02 | Wiring Devices & Outlets | 16 |
| A03 | Circuit Protection & Isolation | 13 |
| A04 | Distribution Boards & Panels | 14 |
| A05 | Conduits Trunking & Cable Support | 13 |
| A06 | Earthing Lightning & Grounding | 10 |
| A07 | Electrical Connection & Installation Supplies | 14 |
| A08 | Meters & Power Monitoring | 9 |

### B. Lighting Fans & Motors (6 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| B01 | Lamps & Light Sources | 7 |
| B02 | Indoor & Architectural Luminaires | 10 |
| B03 | Outdoor Decorative & Emergency Lighting | 12 |
| B04 | LED Strips Drivers & Lighting Controls | 11 |
| B05 | Fans & Ventilation | 11 |
| B06 | Motors Pumps & Their Parts | 12 |

### C. Energy Solar & Industrial Power (10 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| C01 | Solar PV Modules & Mounting | 7 |
| C02 | Solar DC Balance of System | 10 |
| C03 | Batteries & Energy Storage | 4 |
| C04 | Battery Management & Charging | 11 |
| C05 | Solar & General Inverters | 5 |
| C06 | UPS Generators & Transfer Systems | 11 |
| C07 | Power Conversion & Conditioning | 12 |
| C08 | Industrial Switchgear & Control Gear | 11 |
| C09 | Automation PLC Drives & Sensors | 12 |
| C10 | EV Charging & Portable Power | 9 |

### D. Major Home Appliances (7 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| D01 | Refrigerators & Freezers | 9 |
| D02 | Washing Laundry & Drying | 9 |
| D03 | Dishwashers | 4 |
| D04 | Air Conditioning & HVAC Appliances | 11 |
| D05 | Large Cooking & Kitchen Systems | 12 |
| D06 | Water Heating Dispensing & Purification | 9 |
| D07 | Commercial Appliance & HVAC Installation | 13 |

### E. Small Home & Personal Appliances (5 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| E01 | Kitchen Preparation Appliances | 10 |
| E02 | Countertop Cooking & Beverages | 12 |
| E03 | Home Cleaning & Care | 9 |
| E04 | Garment Care & Personal Grooming | 10 |
| E05 | Room Comfort & Household Devices | 9 |

### F. Consumer Electronics & Mobile (8 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| F01 | Televisions & Consumer Displays | 6 |
| F02 | Projection & Digital Signage | 7 |
| F03 | Audio Headphones & Home Theater | 11 |
| F04 | Television Reception & AV Accessories | 11 |
| F05 | Phones Tablets & Communication Devices | 7 |
| F06 | Mobile Power Accessories & Repair Parts | 11 |
| F07 | Wearables & Personal Tech | 7 |
| F08 | Gaming Photography & Digital Media | 11 |

### G. Computer IT Security & Smart Systems (8 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| G01 | Computers Workstations & Laptops | 8 |
| G02 | PC Internal Components | 10 |
| G03 | Computer Storage & Memory Media | 10 |
| G04 | Computer Peripherals & Accessories | 11 |
| G05 | Printing Scanning & POS Hardware | 12 |
| G06 | Networks Fiber & Data Infrastructure | 12 |
| G07 | CCTV & Surveillance Systems | 10 |
| G08 | Access Fire Security & Smart Home | 15 |

### H. Electronic Components Repair & Instruments (10 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| H01 | Passive Electronic Components | 10 |
| H02 | Discrete Semiconductors & Optoelectronics | 13 |
| H03 | Integrated Circuits & Memory | 11 |
| H04 | Board Connectors & Interconnect Components | 12 |
| H05 | Electronic Sensors RF Timing & Displays | 14 |
| H06 | PCBs Prototyping & Development Kits | 12 |
| H07 | Electromechanical Protection & Thermal Parts | 14 |
| H08 | Electrical Electronic Test & Measurement | 12 |
| H09 | Workshop Tools Soldering & ESD | 14 |
| H10 | Appliance Repair Parts & Consumables | 16 |

### I. Non-stock Technical Services (3 departments)

| Code | Department | Active proposed leaves |
|---|---|---:|
| I01 | Installation & Commissioning Services | 9 |
| I02 | Repair Diagnostics & Field Service | 9 |
| I03 | Maintenance Testing & Support Services | 9 |


The `product_classes.csv` provided in the companion ZIP contains the **full 732-row class directory**, including canonical/redirect/nav state. **No need to paste or manually reproduce every class as a migration.**

### 3.4 Classification policy

- One sellable product -> one **primary active canonical product class** plus optional discovery tags. Non-exclusive product axes (Smart, OLED, QLED, MPPT, battery chemistry, inverter, Wi-Fi, PoE, industrial variants) -> typed facets/specs, not duplicate canonical product rows.
- 42 redirects remain design-level search/selection guidance; never rewrite historic `CategorySymbol`, sales, SKU or ProductCode automatically. 3 navigation parents cannot be sold.
- Canonical class owner decided by primary physical function. Cross-domain discovery uses alias/tag links instead of copied products (e.g. solar cable visible in solar and wire searches).
- Approved store operator should validate EN, Roman Urdu and Urdu aliases before enabling fuzzy/unattended matching. Ambiguous terms show choices, never silently choose a product.
- English class names stable; local aliases nonauthoritative. Stop-and-review unclassifiable products.

### 3.5 Units, packaging and tracking contract

- **Dimension-aware stock units:** COUNT, LENGTH; MASS, VOLUME, AREA available as *reference labels* but **not operationally authorized** until backend quantity/cost/movement acceptance. SERVICE is separately non-stock.
- **Fixed within-dimension conversions:** Meter/Foot, KG/G etc; keep precision and exact rational or adequate decimal safety. Count/Dozen fixed where semantic single-kind pieces. Never mix dimensions.
- **Product-defined packages:** BOX, PACK, CTN, ROLL, COIL, REEL, DRUM, KIT, SET; **no universal conversion**. A specific ProductUnit has a defined FactorToBaseUnit or physical pack carries actual measured base quantity. A heterogeneous kit needs approved BOM/assembly lifecycle.
- Tracking behavior separate from selling unit: Quantity, Length, IndividualPiece, Serialized, physical Container/Pack. Exact physical selections must be whole/count-distinct before rounding; Serial/IMEI are manufacturer identity not shop TrackingCode; **no fake child physical units** for a box holding quantity.
- Examples: 100-meter roll sold as 100 base meters; coil with 17m remaining then 20m sale splits as 17+3 across coils; box of 50 switches may sell seven pieces without generating 50 unique switches.
- Pricing and COGS must respect both entered ProductUnit and selected physical pack allocations; partial tracked pack must not incur whole-pack acquisition cost or become fully `Sold` early.
- Technical `W`, `V`, `A`, `Ah`, `BTU/h`, `Hz`, `GB`, `mm²`, `Ω`, `µF` typically product attributes, not stock selling-unit choices.

### 3.6 Product attributes and variant rules

Class-specific typed templates for Electrical Wiring, Circuit Protection, Lighting, Solar/Inverters/Batteries, Refrigeration, AC, Washers/Dishwashers, Consumer TV/Mobile, Computers, Industrial Automation, Semiconductors, Sensors, Tools/Spare Parts. Typical variants: Voltage, current, wattage, color, capacity L/kg, phase, refrigeration type, chemistry, IEC ratings, connector/package, serial policy, installation compatibility.

**Known V3 limits:** 337 entries are department-wide baseline; per-class exact requiredness, enum permissible values, precision and numeric ranges are not fully certified. No retroactive mandatory-field enforcement or overwriting existing variants without owner-approved compatibility mapping. Store aliases need manual editorial validation. No claim to official ETIM/GS1 exhaustive feature parity or official classification code mapping.

### 3.7 Safe idempotent seed contract

1. First **read-only scan** real EF/entity definitions, existing seed data, categories, subcategories, codes/unique indices, Brands, Company, Model, ProductUnit, TrackingMode, read endpoints, permissions, migrations and current installed UI.
2. Approve matching between 9/65/687-level references and live Shop Category/Subcategory/attribute entities. One division/department product hierarchy must not break canonical CategorySymbol grammar.
3. Versioned `catalog_seed_manifest` and deterministic mapping stable across reruns. Skip/stop on collision; never guess or overwrite an occupied symbol or existing populated product history.
4. Accept no stock or fake product creation; master unit definitions must not secretly change any product's BaseUnit or tracking policy.
5. Plan dry-run -> first-run -> repeat-run -> upgrade with existing rows -> rollback rehearsal in disposable PostgreSQL18. Externally visible API/Desktop product management/search UI must remain bounded, paged and scanner-priority compatible.
6. Catalog seeding is **separately gated** by owner approval and independent evidence; in-scope design adoption does not itself authorize migration/seed/execution.

## 4. The core 11C architecture gate: physical packs and allocations

**Confirmed current source limitations** (read-only GitHub branch):

- `CompleteSaleHandler` Container requires original full-pack quantity per selected unit. Partial/cross-pack cannot work as defined.
- `ConsumeSerializedAsync` decrements whole `basePerUnit` from its lot and removes unit carrying cost, and sets its `InventoryUnitStatus.Sold`. This is **incompatible with a naive partial-pack-only columns patch** without corresponding mutation path revision.
- Below-cost override currently compares whole selected unit acquisition cost, requiring careful per-base/pack pricing rules.

**Do not approve** the audit's proposed only-four-nullable-column schema as sufficient until these proofs are produced:

| Required design proof | Acceptance requirement |
|---|---|
| Physical pack representation | Decide reuse of `inventory.units` vs a distinct existing pack table based on actual relational model; avoid competing stock authority |
| Remaining quantity/status | `0 <= RemainingBaseQuantity <= InitialBaseQuantity`, `Sealed/Open/Consumed` state machine, compatible physical InventoryUnit status |
| Durable allocation history | Per transaction line and physical pack: reference, delta base quantity, source/lot, cost allocation, timestamp, actor, reversal lineage as needed |
| Multi-pack sale | One SaleItem may allocate 4 units Pack A + 6 Pack B; sale unit references and unique constraints allow repeat partial draws legally |
| Correct cost/COGS | Only consumed portion charged, lot bucket matches selected pack's source, remaining value preserved, no double-removal |
| Pricing | Below-cost and selling price apply to selected quantity/ProductUnit, not automatically whole pack acquisition cost |
| Scan/label | One physical pack TrackingCode with deterministic sequence authority; reprint old identity; no 50 fake child InventoryUnits |
| Returns and reversals | Physical origin restored or recorded as safe loose segment; cannot magically reseal/open counterfeit pack |
| Locked concurrency | No double consumption under Sale/Sale, Sale/Stocktake, Sale/Thaka, Sale/PurchaseReturn races |
| Movement reconciliation | `SUM(active physical remaining) = movement-derived corresponding pack-tracked BaseQuantity` scoped by product/stock bucket and origin where needed |
| Legacy and migration | Non-container historical rows unaffected; migration/snapshot/check constraints/indexes/rollback rehearsed |
| Exact/Qty/Length behavior | Preserve IndividualPiece, Serialized, ordinary Quantity/Length and product-specific units without policy confusion |

A four-column implementation can be part of one accepted design, **not the entire invariant**. Schema owner must document whether append-only pack allocation facts are already expressible through existing movement/lot bridge entities or need their own persistence. No speculative `stock_packs` duplication.

### Example required golden pack trace

Receive Pack A 50PCS + Pack B 50PCS -> sell 46 from A -> sell 10 (A 4 + B 6) -> process return of 3 with preserved source lineage -> stocktake physical A/B -> reconcile lot qty, movement stock, COGS, recognized losses and tracked remaining. Repeat under adversarial concurrent requests; no stock goes negative, no duplicate physical sold state.

### Example required cable trace

Receive two coils of 100m each -> sale 83m from first -> sale 20m (17m first, 3m second) -> short-end wastage/partial return -> preserve physical segment + lot/COGS/profit and shop timezone report grouping.

## 5. 11H F13: shop-time implementation contract

**Confirmed:** Reporting service `ToOffset(local)` calls `TimeZoneInfo.Local.GetUtcOffset(local)`. Must use a configured Shop timezone authority, with UTC timestamps persisted and deterministic date boundaries.

**Guardrail:** Not all `DateOnly` input is fraudulent. Separate:

1. **Shop business date / posting date**: derived server-side using canonical Shop TimeZone; activity joins and report cutoffs must match one policy.
2. **Document issue/transaction date**: Purchase invoice `PurchaseDate`, supplier document effective date, approved backdate might be user-entered with permission and audit; do not mandate equals today's business day without policy.
3. **Original event timestamps**: UTC, immutable according to existing domain model. Convert only for grouping/presentation.
4. **DST/ambiguous local instants**: define handling if configured zone supports DST; IANA/Windows timezone mapping cross-platform tests.

**Mandatory tests:** Windows OS zone != shop zone, shop midnight UTC boundary, Month/Year cutoffs, DST where supported, backdated legitimate Purchase, unauthorized future-date, audit trail and cost/financial reporting consistency. Preserve F12 recognized loss plus recovery gains and existing historical reports.

## 6. 14 original implementation tasks + separately visible catalog tasks

Original audit supplied **14 tasks** in four waves. Preserve exact names and ownership but treat new catalog tasks as additional scoped work, not silently squeeze into 14.

| Wave | Task IDs and scopes | Prerequisites |
|---|---|---|
| W0: freeze/review (new mandatory gate) | W0-EVIDENCE: four real audit files, exact R6 candidate SHA, source/harness delta, schema + test arithmetic, temporary writer freeze | User authorization to execute implementation later |
| W1: foundations | 11C-01 physical model; 11C-02 EF persistence; 11H-01 `IShopTimeAuthority`; **CAT-01** map V3 to Shop Category/ProductUnit/identity; **CAT-02** unit/dimension/pack conversion contract | Design choices and existing schema review locked; CAT tasks can be read-only first |
| W2: business engines | 11C-03 intake/label; 11C-04 loose/open first; 11C-05 cross-pack sale + Thaka; 11C-06 cut-length/wastage/return; 11H-02 mutation business date; 11H-03 reporting day boundaries; **CAT-03** idempotent catalog manifest/seed code (not apply); **CAT-04** typed attributes/facets/aliases with review gates | W1 core/model approved; no cross-agent conflicting writes |
| W3: API / Desktop | 11C-07 pack query endpoints; 11C-08 Desktop scanning/open pack selection; **CAT-05** Product Management + API paging/search/category activation integration | Backend contract stable; no direct Desktop DB authority |
| W4: certification | 11I-01 pack unit tests22; 11I-02 PG concurrency14; 11I-03 golden traces10; **CAT-06** isolated first/repeat/upgrade/rollback + U01–U23; **CAT-07** catalog/pack/time whole-candidate independent certification | Final frozen candidate; all tests assigned by unique names; operation requires explicit approval |

**Catalog additive items:** CAT-01 .. CAT-07, with owner-approval gates. Exactly **14 original** + **7 catalog tasks**, plus W0 evidence gate and newly recognized architecture issues. No claiming '21 tasks already audited' in the original 32-item requirement matrix.

### Parallel agent ownership

Bounded multi-agent execution only after W0 signoff: one lead coordinating non-overlapping **Pack/Inventory**, **Shop Time/Reports**, **Catalog/Units/Search**, then an independent tester/certifier. Only one agent modifies shared EF migrations/snapshot at a time. One lead/zero subagents for final independent signoff. Protect immutable R6 files and commit ownership. Stop on conflicts rather than layering optimistic changes.

## 7. Test accounting and certification matrix (must reconcile)

- Original summary Wave 4: 22 pack unit + 14 PostgreSQL multi-pack concurrency + 10 golden traces = **46 explicit new tests**.
- Summary simultaneously says **58 mandatory new tests**: **12 tests are unallocated or not visible in pasted summary**. Locate named cases in real Test & Certification Matrix and fill gap before implementation. Time F13, catalog U01–U23 and unit-conversion may exceed 58; never undercount or count written scenarios as executed tests.
- Claimed target **1519 passing tests** lacks an independently proven same-candidate distinct-test baseline in pasted summary. R6 proof may report 1170 distinct unit cases plus overlapping suites; certify **unique tests versus cumulative executions** separately.
- Audit states 10 acceptance gates; original Phase11 exit gate includes at least the following **16 named capability gates**: TrackingPolicy, ProductUnit, Quantity, Length, ContainerPack, IndividualPiece, Serialized, Pack/BaseQty, StockAdjustment, ExactUnitLot, ExactUnitCost, Thaka, ReturnExchange, RecognizedLoss, ShopTime, RealPG. Plus zero Critical/High, zero BLOCKED, zero NOT_RUN. Preserve each named gate rather than treating '10' as replacement.
- Catalog adds independent gates: class/redirect reference integrity, existing code identity compatibility, dimensional conversions, product-specific packaging, typed attrs/variants, aliases/ambiguity, idempotent isolated seed and rollback, bounded API/Desktop search, no fake product/stock, **all 23 U01–U23 acceptance scenarios** (some may be subset of core tested flows, but record overlaps explicitly).
- DEBUG and RELEASE solution builds, EF snapshot alignment, migration inventory and permission negative-tests as applicable. Stable current fingerprints for every report, original tests stay green.

## 8. Unified readiness and stage exit criteria

| Gate | Start status in this chat | Pass evidence needed |
|---|---|---|
| G0 Phase 7 R6 freeze | USER AUDIT ASSERTED | source/harness identity and Final21 applicable cases in actual 4 files |
| G1 Phase 11A live/current differential | PARTIAL SOURCE-VERIFIED | full live EF/API/Domain scan, signed 32-requirement gap matrix plus catalog addendum |
| G2 Pack schema architecture | **NOT APPROVED** | schema + allocation/COGS/status/return/pricing/lot/locking proofs |
| G3 Shop-time date contract | **NOT APPROVED** | date-type policy and role permissions, timezone tests |
| G4 Catalog authority map | **NOT APPROVED** | V3-to-existing CategorySymbol/DTO/DB model mapping + conflicts |
| G5 Preservation and builds | NOT RUN IN THIS CHAT | same-candidate Debug/Release, original protected tests |
| G6 Core Pack/Time behavior | NOT RUN | tests and real PG disposal proof |
| G7 Catalog seed + 23 scenarios | NOT RUN | first/repeat/upgrade/rollback, negative tests on isolated PG |
| G8 Independent Phase11 11I cert | NOT RUN | final evidence matrix and independent reviewer verdict |
| G9 Operational deployment | **HOLD** | separate future explicit approval after complete release gates |

**Corrected Phase11 entry verdict:** `READY_FOR_ARCHITECTURE_RECONCILIATION_AND_ROADMAP_ADOPTION`, **not** verified `READY_FOR_UNCONDITIONAL_SINGLE_PASS_IMPLEMENTATION` yet. Proceed directly to bounded R01/R03/R04/R05/R06 closure, then request owner approval for the implementation master prompt. Do not restart broad audit for already-evidenced Phase7 fixes.

## 9. Documentation and evidence handoff

- This file is the **additive new roadmap**, not an update already written into the live Windows workspace.
- Companion review: `EDGE_RETAILS_PHASE11_PREIMPLEMENTATION_AUDIT_FORENSIC_ADJUDICATION_2026-10-10.md`.
- Companion package: all exact V3 reference CSVs, V3 design and independent QA; preserve original immutable V2 and V3 input files.
- Original historical authority copied into ZIP for comparison and exact Phase11 section snapshot below. Live canonical docs and four new preimplementation audit artifacts are still required before implementation.

## 10. Compact resume prompt for this same-chat Phase 11 execution

```text
Edge Retails Phase 11: use the approved POS-FIRST order. Read the NEW Phase11 Master Roadmap V2, its Forensic Adjudication, original Sep28 Phase11 authority, the four real `artifacts/phase11-preimplementation` files, and existing V3 CSVs. Current Git branch tracking-remediation-20261002, protected R6 candidate as asserted by owner. First perform BOUNDED READ-ONLY 11A reconciliation for R01 pack allocation/cost/status schema, R03 F13 document-vs-posting business dates, R04 missing test-case identities, R05 V3 catalog mapping, R06 real candidate artifacts. Do not duplicate Phase7 fixes. Do not implement, migrate, seed, push or modify production until a signed plan and explicit authorization. Report exact resolved decisions and stop gates; afterward prepare one bounded master implementation prompt for Wave1–Wave4 including 14 original + 7 catalog tasks.
```

## Appendix A. Original September 28 Phase11 sections 10–19 (historical design snapshot, not live code)

<details><summary>Exact preserved text of original Phase 11 scope and exit requirements</summary>

# 10. Phase 11 - Business Integrity + Inventory Provenance

## 10.1 Mission

Phase 11 permanently closes the business-integrity findings exposed by forensic audit and completes the new physical tracking architecture without rewriting stable business domains.

Phase 11 answers:

```text
WHAT should happen to stock, physical identity, cost, provenance and reporting?
```

It does not own global retry/recovery semantics. That is Phase 12.

## 10.2 Phase 11 owned findings

```text
F01
F02
Sol-F03
F04
F10
F12
F13
plus Container/Pack completion
```

## 10.3 Phase 11 internal workstreams

```text
11A - Authority & Live-Code Reconciliation
11B - Tracking Policy + ProductUnit Freeze
11C - Pack / Container Physical Sub-Ledger
11D - Stock Adjustment Semantics
11E - Exact-Unit Lot / Cost / Condition Integrity
11F - Thaka Material Integrity
11G - Return / Exchange Eligibility Authority
11H - Financial Reporting + Shop Time
11I - Cross-Domain Reconciliation & Real PostgreSQL Certification
```

These are workstreams inside Phase 11, not new macro phases.

---

# 11. Phase 11A - Authority & Live-Code Reconciliation

## Goal

Before editing, prove how the live implementation represents:

- TrackingMode / tracking policy;
- ProductUnit and FactorToBaseUnit;
- InventoryUnit;
- Inventory lots / balances / movements;
- current exact-unit costing;
- stock adjustment modes;
- condition / scrap handlers;
- Thaka issue lines;
- Sale Return and Commercial Exchange return side;
- reporting formulas;
- shop settings / timezone;
- any existing pack / container implementation.

## Mandatory read targets

At minimum inspect current live equivalents of:

```text
Domain/Catalog tracking models
Domain/Inventory models
CatalogModels / ProductUnit
InventoryUnit
stock balance / lot / movement entities
StockAdjustmentHandlers
InventoryConditionHandlers
InventoryCostAllocator
ThakaHandlers
SaleReturnHandler
CommercialExchangeHandler
BusinessOperationsReadServices
stocktake handlers
receiving handlers
EF configurations / migrations / snapshot
existing tests for exact-unit / inventory / Thaka / returns
```

## Deliverable

A bounded delta matrix:

```text
Requirement
Current implementation
Already correct?
Gap
Files affected
Migration required?
Test required?
Risk
```

No implementation before this delta matrix is produced.

---

# 12. Phase 11B - Tracking Policy + ProductUnit Freeze

## Goals

1. Freeze the live representation of Quantity, Length, IndividualPiece, Serialized and Container/Pack behaviors.
2. Preserve ProductUnit as a separate axis.
3. Preserve base quantity as stock truth.
4. Prevent fake exact identities for quantity/length contents.

## Required invariants

```text
EnteredQuantity * FactorToBaseUnit = BaseQuantity
```

subject to precision rules.

Exact-unit modes additionally require:

```text
BaseQuantity == count(distinct selected exact physical units)
```

Length may accept fractional base quantity according to ProductUnit precision / step.

Exact physical item count must be whole before any rounding.

## Tests

- Meter sale with fractional quantity.
- Full roll sale through ProductUnit factor.
- Different wire products with different roll factors.
- Quantity piece sale.
- exact-unit quantity mismatch.
- IndividualPiece without Serial/IMEI.
- Serialized with required Serial/IMEI.
- ProductUnit conversion in Purchase, Sale, Return, Thaka and Stocktake.

---

# 13. Phase 11C - Pack / Container Physical Sub-Ledger

## Goals

Implement or complete the physical sub-ledger for tracked boxes / packs / coils.

## Design requirements

- one physical pack identity where configured;
- contained base quantity without child exact units;
- initial and remaining base quantity;
- deterministic pack state;
- source purchase provenance;
- optimistic/pessimistic concurrency according to existing lock strategy;
- movement-backed stock remains canonical accounting truth;
- pack allocations reconcile to stock quantity.

## Required flows

### Receiving

```text
receive Product
-> resolve ProductUnit / BaseQuantity
-> create inventory movement / lot / cost state
-> create tracked physical pack(s) when policy requires
-> assign final physical TrackingCode after authority/sequence allocation
-> commit
-> label becomes printable after commit
```

### Partial sale

```text
open pack
-> decrement pack RemainingBaseQuantity
-> write pack allocation
-> write normal Sale / movement / cost effects
```

### Cross-pack sale

Consume remainder from current open pack, then next eligible pack in the same transaction.

### Whole-pack sale

Where configured, require eligible sealed pack.

### Return

Preserve original sale allocation provenance where physically meaningful. Do not blindly add quantity without reconciling pack state.

### Purchase Return

Whole-pack purchase return may require a sealed eligible source-purchase pack.

### Stocktake

Compare both total BaseQuantity and physical pack composition where pack tracking is enabled.

### Wastage / cut wire

Represent physical loss and recognized inventory loss. Do not invent a full sealed pack from loose quantity.

## Concurrency tests

- two concurrent sales consume same open pack;
- one sale spans two packs while another targets second pack;
- scanned pack vs auto-allocation race;
- stocktake vs pack sale;
- purchase return vs sale of same sealed pack.

---

# 14. Phase 11D - Stock Adjustment Semantics

## Canonical planner

Introduce or centralize a planner equivalent to:

```text
StockAdjustmentPlan
- BeforeQuantity
- RequestedValue
- Mode
- AppliedDelta
- AfterQuantity
- cost effect
- lot effect
- exact-unit / pack effect
- financial classification
```

Exact naming may differ.

## Modes

### Relative Delta

```text
Before 10
Delta -2
After 8
```

### Absolute Physical Count

```text
Before 10
Observed 7
AppliedDelta -3
After 7
```

### Target zero

```text
Before 5
Observed 0
AppliedDelta -5
After 0
```

## Exact-unit positive adjustment

Do not synthesize untraceable exact units. Positive exact-unit inventory requires explicit provenance / controlled intake according to live authority.

## Exact-unit negative adjustment

Select exact units. Do not arbitrarily remove serialized physical units via generic quantity reduction.

## Required tests

- target equals current;
- target zero;
- target increase;
- target decrease;
- relative positive/negative delta;
- concurrent adjustment;
- serialized selection mismatch;
- pack-tracked physical count correction;
- cost / loss reconciliation.

---

# 15. Phase 11E - Exact-Unit Lot, Cost and Condition Integrity

## Selected-unit mutation slice

A useful conceptual projection is:

```text
SelectedUnitMutationSlice
- InventoryUnitId
- ProductId
- SourcePurchaseItemId
- SourceLotId where applicable
- BaseQuantity
- CarryingCost
- CurrentCondition / status
```

The selected physical units drive selected provenance.

## Scrap cost rule

```text
ExactTotalCost = SUM(each selected unit carrying cost)
```

Do not pass aggregate total into an API that treats it as per-unit cost.

## Lot rule

If selected exact units originated from different lots, their mutation must not consume unrelated arbitrary FIFO lots.

## Quantity validation rule

Reject fractional exact-unit input before rounding.

## Condition transfer

Condition bucket transfer changes physical condition and inventory bucket, not Sale COGS.

Write-off / scrap removes carrying cost and creates recognized inventory loss.

## Tests

- two unequal-cost exact units scrapped together;
- insufficient generic pool must not hide wrong exact cost math;
- selected units from non-FIFO source lots;
- 1.2 exact-unit input rejection;
- duplicate selected unit rejection;
- concurrent scrap / sale race;
- condition transfer cost neutrality;
- write-off loss entry reconciliation.

---

# 16. Phase 11F - Thaka Material Integrity

## Pre-mutation normalization

Before touching inventory:

1. Resolve Product + ProductUnit.
2. Convert entered quantity to BaseQuantity.
3. Resolve exact units where required.
4. Build one command-wide exact-unit set.
5. Reject duplicate exact units across all lines.
6. Validate stock, status, permission, project state and pricing.
7. Only then mutate stock/cost/Thaka ledger.

## Required invariants

```text
no exact InventoryUnit appears twice in one Thaka command
```

and:

```text
ProductUnit factor is applied consistently
```

and:

```text
BaseQuantity / exact selected unit count reconcile
```

## Tests

- same unit twice on one line;
- same unit across two different lines;
- different ProductUnits for same product;
- factor > 1;
- exact unit wrong product;
- already issued unit;
- concurrent Thaka issue of same unit;
- Thaka reversal preserving provenance where supported.

---

# 17. Phase 11G - Shared Return / Exchange Eligibility

Create one backend policy / service / domain rule for physical return eligibility used by the return side of both:

```text
Sale Return
Commercial Exchange
```

It must evaluate at least:

- original SaleItem / exact-unit relationship;
- already-returned quantity / unit;
- prior exchange return;
- current physical status;
- active or terminal warranty state;
- custody;
- product relationship;
- stale/concurrent state.

Financial semantics remain operation-specific after eligibility.

## Tests

- active warranty unit cannot be accepted by Exchange if Return would reject it;
- terminal warranty resolution behavior matches policy;
- already returned unit;
- already exchanged unit;
- wrong SaleItem;
- concurrent Return vs Exchange;
- concurrent Exchange vs Warranty transition.

---

# 18. Phase 11H - Reporting and Shop-Time Authority

## Financial impact classification

Inventory effects should be classifiable so reporting does not infer economics from handler names.

Conceptual classes:

```text
Sale COGS
Recognized Inventory Loss
Inventory Gain
Neutral Transfer
```

Do not count normal Sale COGS again as inventory loss.

## Net profit

Canonical:

```text
Net Profit
= Gross Profit
- Operating Expenses
- Recognized Inventory Losses
```

## Shop time

Conceptual authority:

```text
IShopTimeAuthority
- CurrentUtc
- ShopTimeZone
- CurrentShopLocalTime
- CurrentBusinessDate
- UTC <-> shop-local conversion
```

Use actual project naming conventions when implementing.

## Tests

- host Windows timezone differs from shop timezone;
- transaction around midnight shop time;
- reporting range boundaries;
- DST-capable timezone if supported;
- scrap and operating expense in same period;
- stocktake shortage appears once in Net Profit;
- neutral condition transfer does not become loss.

---

# 19. Phase 11I - Real PostgreSQL Reconciliation and Certification

Phase 11 does not close on unit tests alone.

## Required real PostgreSQL scenarios

- F01 target/delta matrix;
- F02 unequal-cost scrap;
- Sol-F03 selected-unit / source-lot trace;
- fractional exact-unit rejection;
- F04 cross-line Thaka duplicate;
- ProductUnit factor in Thaka;
- F10 exchange under warranty state;
- F12 inventory-loss reporting;
- F13 shop-time boundaries;
- pack receive -> partial sale -> cross-pack sale -> return -> stocktake;
- wire length receive -> full roll sale -> loose sale -> return / wastage;
- concurrent exact-unit and pack mutations.

## Phase 11 exit gate

```text
Tracking policy authority                PASS
ProductUnit conversion                   PASS
Quantity tracking                        PASS
Length tracking                          PASS
Container / Pack tracking                PASS
IndividualPiece tracking                 PASS
Serialized tracking                      PASS
Pack/BaseQuantity reconciliation         PASS
Stock adjustment semantics               PASS
Exact-unit lot provenance                PASS
Exact-unit cost integrity                PASS
Thaka integrity                          PASS
Return/Exchange eligibility              PASS
Recognized loss reporting                PASS
Shop-time authority                      PASS
Real PostgreSQL hostile pack             PASS
Critical Phase 11 defects                0
High Phase 11 defects                    0
Blocked required Phase 11 gates          0
Unexecuted required Phase 11 gates       0
```

Do not automatically begin Phase 12. Produce Phase 11 closure evidence first.

---


</details>

## Appendix B. Evidence URLs (connected GitHub, read-only source)

- [CompleteSaleHandler: Container full-pack validation](https://github.com/muhammadababdullah3-sketch/Edge-Retails-Electronics-/blob/tracking-remediation-20261002/src/EdgeRetails.Application/Features/Sales/CompleteSaleHandler.cs#L796-L805)
- [CompleteSaleHandler: ConsumeSerializedAsync and cost/status](https://github.com/muhammadababdullah3-sketch/Edge-Retails-Electronics-/blob/tracking-remediation-20261002/src/EdgeRetails.Application/Features/Sales/CompleteSaleHandler.cs#L939-L1000)
- [BusinessOperationsReadServices: ToOffset Windows-local zone](https://github.com/muhammadababdullah3-sketch/Edge-Retails-Electronics-/blob/tracking-remediation-20261002/src/EdgeRetails.Infrastructure/Services/BusinessOperationsReadServices.cs#L751-L766)
- [ThakaHandlers: command-wide exact-unit uniqueness](https://github.com/muhammadababdullah3-sketch/Edge-Retails-Electronics-/blob/tracking-remediation-20261002/src/EdgeRetails.Application/Features/Thaka/ThakaHandlers.cs#L319-L334)
- [StockAdjustmentHandlers: physical target arithmetic](https://github.com/muhammadababdullah3-sketch/Edge-Retails-Electronics-/blob/tracking-remediation-20261002/src/EdgeRetails.Application/Features/Inventory/StockAdjustmentHandlers.cs#L245-L295)

**END: Phase 11 Master Roadmap V2 additive plan. No code or production changes authorized.**
